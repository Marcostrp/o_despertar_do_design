/**
 * Chroma & Grid: Design Odyssey
 * Main Game Application Controller
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  GameView,
  PlayerStats,
  InventoryItem,
  SpecialAttack,
  Enemy,
  DungeonRoom,
  Achievement,
  Quest,
  NPC,
  WorldTile,
  Position2D
} from './types/game';
import {
  INITIAL_PLAYER_STATS,
  INITIAL_SPECIAL_ATTACKS,
  INITIAL_ITEMS,
  DUNGEON_ROOMS,
  ENEMIES_DATABASE,
  NPCS,
  INITIAL_QUESTS,
  ACHIEVEMENTS,
  generateWorldMap
} from './data/gameData';
import { soundEngine } from './audio/soundEngine';

import { TitleScreen } from './components/TitleScreen';
import { IsometricCanvas } from './components/IsometricCanvas';
import { ModernDungeon } from './components/ModernDungeon';
import { TurnBasedBattle } from './components/TurnBasedBattle';
import { DynamicInventory } from './components/DynamicInventory';
import { DesignCodexModal } from './components/DesignCodexModal';
import { AchievementsModal } from './components/AchievementsModal';
import { QuestLogModal } from './components/QuestLogModal';
import { NPCModal } from './components/NPCModal';
import { HUD } from './components/HUD';
import { VirtualGamepad } from './components/VirtualGamepad';

export default function App() {
  // --- CORE GAME STATE ---
  const [gameView, setGameView] = useState<GameView>('TITLE');
  const [isCrtEnabled, setIsCrtEnabled] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Player State
  const [playerStats, setPlayerStats] = useState<PlayerStats>(INITIAL_PLAYER_STATS);
  const [playerPosition, setPlayerPosition] = useState<Position2D>({ x: 6, y: 7 });
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_ITEMS);
  const [attacks, setAttacks] = useState<SpecialAttack[]>(INITIAL_SPECIAL_ATTACKS);

  // World & Quests State
  const [worldTiles, setWorldTiles] = useState<WorldTile[]>(() => generateWorldMap());
  const [dungeonRooms, setDungeonRooms] = useState<DungeonRoom[]>(DUNGEON_ROOMS);
  const [activeDungeonRoom, setActiveDungeonRoom] = useState<DungeonRoom | null>(null);
  const [activeEnemy, setActiveEnemy] = useState<Enemy | null>(null);
  const [quests, setQuests] = useState<Quest[]>(INITIAL_QUESTS);
  const [achievements, setAchievements] = useState<Achievement[]>(ACHIEVEMENTS);

  // Active Modals & Dialogs
  const [isInventoryOpen, setIsInventoryOpen] = useState<boolean>(false);
  const [isCodexOpen, setIsCodexOpen] = useState<boolean>(false);
  const [isAchievementsOpen, setIsAchievementsOpen] = useState<boolean>(false);
  const [isQuestLogOpen, setIsQuestLogOpen] = useState<boolean>(false);
  const [activeNpcModal, setActiveNpcModal] = useState<NPC | null>(null);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();

      if (key === 'escape') {
        setIsInventoryOpen(false);
        setIsCodexOpen(false);
        setIsAchievementsOpen(false);
        setIsQuestLogOpen(false);
        setActiveNpcModal(null);
      } else if (key === 'i') {
        soundEngine.playInteract();
        setIsInventoryOpen(prev => !prev);
      } else if (key === 'c') {
        soundEngine.playInteract();
        setIsCodexOpen(prev => !prev);
      } else if (key === 't') {
        soundEngine.playInteract();
        setIsAchievementsOpen(prev => !prev);
      } else if (key === 'q') {
        soundEngine.playInteract();
        setIsQuestLogOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // --- XP & LEVEL UP HELPER ---
  const awardXp = useCallback((amount: number) => {
    setPlayerStats(prev => {
      let newXp = prev.xp + amount;
      let newLevel = prev.level;
      let nextXp = prev.nextLevelXp;
      let newMaxHp = prev.maxHp;
      let newMaxInsp = prev.maxInspiration;
      let newHierarchy = prev.hierarchy;
      let newContrast = prev.contrast;
      let newHarmony = prev.harmony;
      let newTitle = prev.title;

      while (newXp >= nextXp) {
        newXp -= nextXp;
        newLevel++;
        nextXp = Math.round(nextXp * 1.5);
        newMaxHp += 20;
        newMaxInsp += 15;
        newHierarchy += 5;
        newContrast += 4;
        newHarmony += 3;
        soundEngine.playLevelUp();

        // Level titles
        if (newLevel === 2) newTitle = 'Trainee de Vetor';
        else if (newLevel === 3) newTitle = 'Designer Júnior';
        else if (newLevel === 4) newTitle = 'Diretor de Arte';
        else if (newLevel === 5) newTitle = 'Mestre Bauhaus';
        else if (newLevel >= 6) newTitle = 'Divindade do Design';
      }

      // Unlock attacks by level
      setAttacks(currentAttacks =>
        currentAttacks.map(atk => (atk.levelReq <= newLevel ? { ...atk, unlocked: true } : atk))
      );

      return {
        ...prev,
        level: newLevel,
        xp: newXp,
        nextLevelXp: nextXp,
        maxHp: newMaxHp,
        hp: newMaxHp,
        maxInspiration: newMaxInsp,
        inspiration: newMaxInsp,
        hierarchy: newHierarchy,
        contrast: newContrast,
        harmony: newHarmony,
        title: newTitle,
      };
    });
  }, []);

  // --- UNLOCK ACHIEVEMENT HELPER ---
  const unlockAchievement = useCallback((id: string) => {
    setAchievements(prev =>
      prev.map(ach => {
        if (ach.id === id && !ach.unlocked) {
          soundEngine.playPuzzleSolve();
          return { ...ach, unlocked: true, unlockedAt: new Date().toLocaleTimeString() };
        }
        return ach;
      })
    );
  }, []);

  // --- ITEM MANAGEMENT ---
  const handleUseInventoryItem = (item: InventoryItem) => {
    if (item.quantity <= 0) return;

    setInventory(prev =>
      prev
        .map(i => (i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i))
        .filter(i => i.quantity > 0)
    );

    if (item.statsEffect) {
      setPlayerStats(prev => ({
        ...prev,
        hp: Math.min(prev.maxHp, prev.hp + (item.statsEffect?.healHp || 0)),
        inspiration: Math.min(prev.maxInspiration, prev.inspiration + (item.statsEffect?.healInspiration || 0)),
      }));
    }
  };

  const handleCombineItems = (itemA: InventoryItem, itemB: InventoryItem) => {
    soundEngine.playPuzzleSolve();

    // Remove 1 from each
    setInventory(prev =>
      prev
        .map(i => {
          if (i.id === itemA.id || i.id === itemB.id) {
            return { ...i, quantity: i.quantity - 1 };
          }
          return i;
        })
        .filter(i => i.quantity > 0)
    );

    // Create synthesized result
    const craftedItem: InventoryItem = {
      id: `crafted_${Date.now()}`,
      name: `Composição Harmonizada (${itemA.name.slice(0, 8)} + ${itemB.name.slice(0, 8)})`,
      category: 'tool',
      description: 'Uma ferramenta refinada gerada pela união de dois princípios visuais complementares.',
      principle: 'Síntese Visual e Harmonia',
      icon: '✨',
      quantity: 1,
      usableInBattle: true,
      rarity: 'epic',
      statsEffect: { healHp: 100, healInspiration: 50 },
    };

    setInventory(prev => [...prev, craftedItem]);
    awardXp(30);
  };

  // --- DUNGEON LOGIC ---
  const handleEnterDungeon = (dungeonId: string) => {
    const room = dungeonRooms.find(r => r.dungeonId === dungeonId);
    if (room) {
      soundEngine.playWarp();
      setActiveDungeonRoom(room);
      setGameView('DUNGEON');
    }
  };

  const handleSolveDungeonPuzzle = (rewardItem: InventoryItem, rewardAttackId?: string) => {
    if (!activeDungeonRoom) return;

    // Mark room as completed
    setDungeonRooms(prev =>
      prev.map(r => (r.id === activeDungeonRoom.id ? { ...r, isCompleted: true } : r))
    );

    // Add reward item to inventory
    setInventory(prev => {
      const existing = prev.find(i => i.id === rewardItem.id);
      if (existing) {
        return prev.map(i => (i.id === rewardItem.id ? { ...i, quantity: i.quantity + rewardItem.quantity } : i));
      }
      return [...prev, rewardItem];
    });

    // Unlock special attack if applicable
    if (rewardAttackId) {
      setAttacks(prev =>
        prev.map(atk => (atk.id === rewardAttackId ? { ...atk, unlocked: true } : atk))
      );
    }

    // Award XP
    awardXp(120);

    // Update quest progress
    setQuests(prev =>
      prev.map(q => {
        if (q.id === 'quest_main') {
          const newProgress = Math.min(q.maxProgress, q.progress + 1);
          return { ...q, progress: newProgress, completed: newProgress >= q.maxProgress };
        }
        return q;
      })
    );

    // Unlock achievements based on room
    unlockAchievement('ach_first_dungeon');
    if (activeDungeonRoom.theme === 'color_theory') unlockAchievement('ach_color_master');
    if (activeDungeonRoom.theme === 'typography_kerning') unlockAchievement('ach_kerning_god');
    if (activeDungeonRoom.theme === 'gestalt_negative_space') unlockAchievement('ach_gestalt_vision');
    if (activeDungeonRoom.theme === 'swiss_grid') unlockAchievement('ach_swiss_grid');
  };

  // --- BATTLE LOGIC ---
  const handleTriggerWildBattle = () => {
    if (gameView !== 'OVERWORLD') return;
    const randomEnemy = ENEMIES_DATABASE[Math.floor(Math.random() * (ENEMIES_DATABASE.length - 1))];
    setActiveEnemy(randomEnemy);
    setGameView('BATTLE');
  };

  const handleBattleEnd = (
    result: 'win' | 'lose',
    updatedPlayerStats: PlayerStats,
    rewardItems: InventoryItem[],
    earnedXp: number
  ) => {
    setPlayerStats(updatedPlayerStats);

    if (result === 'win') {
      unlockAchievement('ach_first_battle');
      if (activeEnemy?.id === 'comic_sans_behemoth') {
        setQuests(prev =>
          prev.map(q => (q.id === 'quest_comic_sans' ? { ...q, progress: 1, completed: true } : q))
        );
      }
      if (activeEnemy?.id === 'boss_logo_tyrant') {
        unlockAchievement('ach_boss_defeat');
      }

      // Add loot to inventory
      if (rewardItems.length > 0) {
        rewardItems.forEach(newItem => {
          setInventory(prev => {
            const existing = prev.find(i => i.id === newItem.id);
            if (existing) {
              return prev.map(i => (i.id === newItem.id ? { ...i, quantity: i.quantity + newItem.quantity } : i));
            }
            return [...prev, newItem];
          });
        });
      }

      awardXp(earnedXp);
    }

    setActiveEnemy(null);
    setGameView('OVERWORLD');
  };

  // --- CHEST & NPC INTERACTIONS ---
  const handleOpenChest = (chestId: string) => {
    soundEngine.playItemPickup();
    setWorldTiles(prev =>
      prev.map(t => (t.chestId === chestId ? { ...t, isOpened: true } : t))
    );

    // Add treasure item
    const treasure: InventoryItem = {
      id: `chest_reward_${Date.now()}`,
      name: 'Régua de Tipometria Dourada',
      category: 'tool',
      description: 'Instrumento ancestral capaz de medir pontos e picas com absoluta fidelidade.',
      principle: 'Sistemas Métricos de Tipografia',
      icon: '📏',
      quantity: 1,
      rarity: 'epic',
      usableInDungeon: true,
    };

    setInventory(prev => [...prev, treasure]);
    awardXp(40);
  };

  const handleVirtualDirection = (dir: 'up' | 'down' | 'left' | 'right') => {
    let dx = 0;
    let dy = 0;
    if (dir === 'up') { dx = -1; dy = -1; }
    if (dir === 'down') { dx = 1; dy = 1; }
    if (dir === 'left') { dx = -1; dy = 1; }
    if (dir === 'right') { dx = 1; dy = -1; }

    const nextX = Math.max(1, Math.min(24, playerPosition.x + dx));
    const nextY = Math.max(1, Math.min(24, playerPosition.y + dy));
    setPlayerPosition({ x: nextX, y: nextY });
    soundEngine.playStep();
  };

  const activeQuest = quests.find(q => !q.completed) || quests[0] || null;

  return (
    <div className={`relative w-screen h-screen bg-[#050811] text-slate-100 overflow-hidden font-sans ${isCrtEnabled ? 'crt-overlay' : ''}`}>
      {/* TITLE VIEW */}
      {gameView === 'TITLE' && (
        <TitleScreen onStartGame={() => setGameView('OVERWORLD')} />
      )}

      {/* OVERWORLD ISOMETRIC CANVAS VIEW */}
      {gameView === 'OVERWORLD' && (
        <>
          <IsometricCanvas
            worldTiles={worldTiles}
            npcs={NPCS}
            playerPosition={playerPosition}
            onMove={setPlayerPosition}
            onInteractNPC={setActiveNpcModal}
            onEnterDungeon={handleEnterDungeon}
            onOpenChest={handleOpenChest}
            onTriggerWildBattle={handleTriggerWildBattle}
            isPaused={isInventoryOpen || isCodexOpen || isAchievementsOpen || isQuestLogOpen || activeNpcModal !== null}
          />

          {/* Top HUD */}
          <HUD
            playerStats={playerStats}
            activeQuest={activeQuest}
            playerPosition={playerPosition}
            isMuted={isMuted}
            isCrtEnabled={isCrtEnabled}
            onToggleMute={() => setIsMuted(soundEngine.toggleMute())}
            onToggleCrt={() => setIsCrtEnabled(prev => !prev)}
            onOpenInventory={() => setIsInventoryOpen(true)}
            onOpenCodex={() => setIsCodexOpen(true)}
            onOpenAchievements={() => setIsAchievementsOpen(true)}
            onOpenQuestLog={() => setIsQuestLogOpen(true)}
            onTriggerWildBattle={handleTriggerWildBattle}
          />

          {/* Virtual On-Screen Gamepad for Mobile/Touch */}
          <VirtualGamepad
            onDirectionPress={handleVirtualDirection}
            onActionA={() => {
              // Quick interact proximity check
              const nearbyNpc = NPCS.find(npc => Math.abs(npc.isoX - playerPosition.x) <= 1.5 && Math.abs(npc.isoY - playerPosition.y) <= 1.5);
              if (nearbyNpc) setActiveNpcModal(nearbyNpc);
            }}
            onActionB={() => soundEngine.playDash()}
            onActionX={() => setIsInventoryOpen(true)}
            onActionY={() => setIsCodexOpen(true)}
          />
        </>
      )}

      {/* MODERN DUNGEON PUZZLE VIEW */}
      {gameView === 'DUNGEON' && activeDungeonRoom && (
        <ModernDungeon
          room={activeDungeonRoom}
          inventory={inventory}
          onSolvePuzzle={handleSolveDungeonPuzzle}
          onExitDungeon={() => setGameView('OVERWORLD')}
          unlockedAttacks={attacks}
        />
      )}

      {/* TURN-BASED BATTLE VIEW */}
      {gameView === 'BATTLE' && activeEnemy && (
        <TurnBasedBattle
          playerStats={playerStats}
          enemy={activeEnemy}
          attacks={attacks}
          inventory={inventory}
          onBattleEnd={handleBattleEnd}
        />
      )}

      {/* MODALS */}
      {isInventoryOpen && (
        <DynamicInventory
          inventory={inventory}
          playerStats={playerStats}
          onUseItem={handleUseInventoryItem}
          onCombineItems={handleCombineItems}
          onClose={() => setIsInventoryOpen(false)}
        />
      )}

      {isCodexOpen && (
        <DesignCodexModal onClose={() => setIsCodexOpen(false)} />
      )}

      {isAchievementsOpen && (
        <AchievementsModal
          achievements={achievements}
          playerStats={playerStats}
          onClose={() => setIsAchievementsOpen(false)}
        />
      )}

      {isQuestLogOpen && (
        <QuestLogModal
          quests={quests}
          onClose={() => setIsQuestLogOpen(false)}
        />
      )}

      {activeNpcModal && (
        <NPCModal
          npc={activeNpcModal}
          onClose={() => setActiveNpcModal(null)}
          onAcceptQuest={(qId) => {
            soundEngine.playItemPickup();
          }}
        />
      )}
    </div>
  );
}
