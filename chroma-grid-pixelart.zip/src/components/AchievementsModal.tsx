/**
 * Achievements & Progression Track - Dungeon of Design
 */

import React from 'react';
import { Achievement, PlayerStats } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import { Award, X, CheckCircle2 } from 'lucide-react';

interface AchievementsModalProps {
  achievements: Achievement[];
  playerStats: PlayerStats;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  achievements,
  playerStats,
  onClose
}) => {
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const progressPercent = Math.round((unlockedCount / achievements.length) * 100);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#120D15] border-2 border-amber-600/80 rounded-2xl max-w-2xl w-full h-[540px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b-2 border-amber-900/80 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/40">
              <Award size={18} />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-pixel font-bold text-amber-300">Sala de Troféus & Maestria</h2>
              <p className="text-[10px] text-amber-200/70 font-mono-code">Progresso de desafios e relíquias do design gráfico</p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playInteract();
              onClose();
            }}
            className="p-1.5 text-amber-200/60 hover:text-white bg-slate-900 border border-amber-900/60 rounded-lg"
          >
            <X size={18} />
          </button>
        </div>

        {/* Progress Bar Summary */}
        <div className="px-6 py-3 border-b border-amber-900/60 bg-slate-950/40 flex items-center justify-between gap-4">
          <div className="flex-1">
            <div className="flex justify-between text-[11px] font-mono-code text-amber-200/80 mb-1">
              <span>Título: <strong className="text-cyan-400 font-pixel">{playerStats.title}</strong></span>
              <span>{unlockedCount} / {achievements.length} Desbloqueados</span>
            </div>
            <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Achievements Grid */}
        <div className="flex-1 p-5 overflow-y-auto space-y-2.5 bg-[#0e0a11]">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`p-3 rounded-xl border-2 flex items-center justify-between transition-colors ${
                ach.unlocked
                  ? 'bg-emerald-950/30 border-emerald-500/50 text-slate-100'
                  : 'bg-slate-950/60 border-amber-900/40 text-slate-500 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl border-2 ${
                  ach.unlocked ? 'bg-emerald-500/20 border-emerald-400' : 'bg-slate-900 border-slate-800'
                }`}>
                  {ach.icon}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-pixel font-bold text-amber-100">{ach.title}</h4>
                    {ach.unlocked && <CheckCircle2 size={12} className="text-emerald-400" />}
                  </div>
                  <p className="text-[11px] text-amber-200/70 mt-0.5 font-sans">{ach.description}</p>
                  <span className="text-[9px] font-mono-code text-cyan-400">Princípio: {ach.principle}</span>
                </div>
              </div>

              <div className="text-right">
                <span className={`text-[9px] font-pixel px-2 py-0.5 rounded ${
                  ach.unlocked ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-900 text-slate-500'
                }`}>
                  {ach.unlocked ? 'CONQUISTADO' : 'TRANCADO'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
