/**
 * Design Principles Codex Modal - Dungeon of Design
 */

import React, { useState } from 'react';
import { DESIGN_CODEX } from '../data/gameData';
import { soundEngine } from '../audio/soundEngine';
import { BookOpen, X, Sparkles, Check } from 'lucide-react';

interface DesignCodexModalProps {
  onClose: () => void;
}

export const DesignCodexModal: React.FC<DesignCodexModalProps> = ({ onClose }) => {
  const [selectedEntry, setSelectedEntry] = useState(DESIGN_CODEX[0]);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#120D15] border-2 border-amber-600/80 rounded-2xl max-w-4xl w-full h-[580px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b-2 border-amber-900/80 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/40">
              <BookOpen size={18} />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-pixel font-bold text-amber-300">Grimório Sagrado do Design</h2>
              <p className="text-[10px] text-amber-200/70 font-mono-code">Tratado dos mestres antigos sobre Kerning, Cor, Gestalt e Grids</p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playInteract();
              onClose();
            }}
            className="p-1.5 text-amber-200/60 hover:text-white bg-slate-900 border border-amber-900/60 rounded-lg"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Layout */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 overflow-hidden">
          {/* Index Sidebar */}
          <div className="p-4 border-r border-amber-900/60 bg-slate-950/50 space-y-2 overflow-y-auto">
            {DESIGN_CODEX.map((item, idx) => (
              <button
                key={idx}
                onClick={() => {
                  soundEngine.playInteract();
                  setSelectedEntry(item);
                }}
                className={`w-full text-left p-3 rounded-xl border-2 transition-all cursor-pointer ${
                  selectedEntry.title === item.title
                    ? 'bg-amber-950/40 border-amber-400 text-white shadow'
                    : 'bg-slate-950/70 border-amber-900/60 text-amber-200/70 hover:text-white hover:border-amber-700'
                }`}
              >
                <div className="text-[9px] font-mono-code text-cyan-400 uppercase">{item.category}</div>
                <div className="text-xs font-pixel font-bold mt-1 text-amber-100">{item.title}</div>
              </button>
            ))}
          </div>

          {/* Detailed Read Panel */}
          <div className="md:col-span-2 p-6 overflow-y-auto space-y-5 bg-[#0e0a11]">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono-code text-cyan-400 uppercase tracking-wider">
                <Sparkles size={14} />
                <span>{selectedEntry.category}</span>
              </div>
              <h3 className="text-sm sm:text-base font-pixel font-bold text-amber-300 mt-1">{selectedEntry.title}</h3>
              <p className="text-[11px] text-amber-200/70 mt-0.5 font-mono-code">{selectedEntry.subtitle}</p>
            </div>

            <div className="p-4 bg-slate-950/80 border border-amber-900/60 rounded-xl space-y-2">
              <h4 className="text-[10px] font-pixel text-amber-400 uppercase">Conceito Fundamental:</h4>
              <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed font-sans">{selectedEntry.summary}</p>
            </div>

            <div className="p-4 bg-amber-950/30 border-2 border-amber-600/50 rounded-xl flex items-start gap-3">
              <div className="p-1 bg-amber-500/20 text-amber-400 rounded mt-0.5">
                <Check size={14} />
              </div>
              <div>
                <h4 className="text-[10px] font-pixel text-amber-300 uppercase">Regra dos Mestres:</h4>
                <p className="text-xs text-amber-100/90 mt-1 font-sans">{selectedEntry.ruleOfThumb}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
