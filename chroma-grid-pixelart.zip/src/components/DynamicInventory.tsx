/**
 * Dynamic Inventory - Dungeon of Design
 * Medieval designer's chest with parchment detail inspections and tool combinations.
 */

import React, { useState } from 'react';
import { InventoryItem, PlayerStats, ItemCategory } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import { X, Sparkles, Layers, Coffee, Palette, Compass, Combine } from 'lucide-react';

interface DynamicInventoryProps {
  inventory: InventoryItem[];
  playerStats: PlayerStats;
  onUseItem: (item: InventoryItem) => void;
  onCombineItems: (itemA: InventoryItem, itemB: InventoryItem) => void;
  onClose: () => void;
}

export const DynamicInventory: React.FC<DynamicInventoryProps> = ({
  inventory,
  playerStats,
  onUseItem,
  onCombineItems,
  onClose
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ItemCategory | 'all'>('all');
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(inventory[0] || null);
  const [combineSlotA, setCombineSlotA] = useState<InventoryItem | null>(null);

  const filteredItems = inventory.filter(item => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  const handleSelect = (item: InventoryItem) => {
    soundEngine.playInteract();
    setSelectedItem(item);
  };

  const handleUse = (item: InventoryItem) => {
    soundEngine.playItemPickup();
    onUseItem(item);
  };

  const handleAddToCombine = (item: InventoryItem) => {
    if (!combineSlotA) {
      soundEngine.playInteract();
      setCombineSlotA(item);
    } else if (combineSlotA.id === item.id) {
      setCombineSlotA(null);
    } else {
      soundEngine.playPuzzleSolve();
      onCombineItems(combineSlotA, item);
      setCombineSlotA(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#120D15] border-2 border-amber-600/80 rounded-2xl max-w-4xl w-full h-[580px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b-2 border-amber-900/80 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/40">
              <Layers size={18} />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-pixel font-bold text-amber-300">Baú de Ferramentas & Amostras</h2>
              <p className="text-[10px] text-amber-200/70 font-mono-code">Gerencie artefatos, amostras cromáticas e instrumentos de desenho</p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playInteract();
              onClose();
            }}
            className="p-1.5 text-amber-200/60 hover:text-white bg-slate-900 border border-amber-900/60 rounded-lg"
          >
            <X size={18} />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 border-b border-amber-900/60 bg-slate-950/40 overflow-x-auto">
          {[
            { id: 'all', label: 'Tudo', icon: <Layers size={12} /> },
            { id: 'puzzle_piece', label: 'Puzzles', icon: <Sparkles size={12} /> },
            { id: 'color_swatch', label: 'Cores', icon: <Palette size={12} /> },
            { id: 'tool', label: 'Ferramentas', icon: <Compass size={12} /> },
            { id: 'consumable', label: 'Consumíveis', icon: <Coffee size={12} /> },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                soundEngine.playInteract();
                setSelectedCategory(cat.id as ItemCategory | 'all');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-pixel rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow'
                  : 'text-amber-200/70 hover:text-white hover:bg-slate-900'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Inventory Workspace */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 overflow-hidden">
          {/* Items Grid */}
          <div className="md:col-span-2 p-5 overflow-y-auto border-r border-amber-900/60">
            {filteredItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-amber-200/50 text-xs font-pixel">
                <span>Nenhum item guardado.</span>
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {filteredItems.map((item) => {
                  const isSelected = selectedItem?.id === item.id;
                  const isCombining = combineSlotA?.id === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelect(item)}
                      className={`relative aspect-square p-2.5 rounded-xl border-2 text-left flex flex-col justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-950/40 border-amber-400 shadow-lg shadow-amber-500/20'
                          : 'bg-slate-950/80 border-amber-900/60 hover:border-amber-700'
                      } ${isCombining ? 'ring-2 ring-cyan-400' : ''}`}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-2xl">{item.icon}</span>
                        {item.quantity > 1 && (
                          <span className="text-[10px] font-mono-code font-bold bg-slate-900 text-amber-300 px-1.5 py-0.5 rounded border border-amber-900/60">
                            ×{item.quantity}
                          </span>
                        )}
                      </div>

                      <div>
                        <div className="text-[11px] font-bold text-amber-100 truncate">{item.name}</div>
                        <div className="text-[9px] text-amber-300/70 font-mono-code capitalize">{item.rarity}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Item Details */}
          <div className="p-5 bg-slate-950/60 flex flex-col justify-between overflow-y-auto">
            {selectedItem ? (
              <div className="space-y-3">
                <div className="text-center pb-3 border-b border-amber-900/60">
                  <div className="w-14 h-14 mx-auto bg-slate-900 rounded-2xl flex items-center justify-center text-3xl shadow-inner border-2 border-amber-500/60">
                    {selectedItem.icon}
                  </div>
                  <h3 className="text-xs font-pixel font-bold text-amber-300 mt-2.5">{selectedItem.name}</h3>
                  <span className="text-[9px] font-mono-code text-cyan-400 uppercase tracking-wider block mt-0.5">
                    {selectedItem.principle}
                  </span>
                </div>

                <div className="space-y-2">
                  <p className="text-xs text-amber-100/90 leading-relaxed font-sans">{selectedItem.description}</p>

                  {selectedItem.statsEffect && (
                    <div className="p-2 bg-slate-900 border border-amber-900/60 rounded-lg space-y-0.5">
                      {selectedItem.statsEffect.healHp && (
                        <div className="text-xs font-semibold text-emerald-400">+{selectedItem.statsEffect.healHp} Pontos de Vida (HP)</div>
                      )}
                      {selectedItem.statsEffect.healInspiration && (
                        <div className="text-xs font-semibold text-cyan-400">+{selectedItem.statsEffect.healInspiration} Inspiração Criativa</div>
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-2 pt-2">
                  {selectedItem.category === 'consumable' && (
                    <button
                      onClick={() => handleUse(selectedItem)}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-pixel font-bold text-[10px] rounded-lg cursor-pointer"
                    >
                      Consumir Item
                    </button>
                  )}

                  <button
                    onClick={() => handleAddToCombine(selectedItem)}
                    className={`w-full py-2 border text-[10px] font-pixel rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      combineSlotA?.id === selectedItem.id
                        ? 'bg-amber-500/30 border-amber-400 text-amber-200'
                        : 'bg-slate-900 hover:bg-slate-800 border-amber-900/80 text-amber-200'
                    }`}
                  >
                    <Combine size={12} />
                    <span>{combineSlotA ? 'Fundir Alquimia' : 'Preparar Combinação'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-amber-200/50 text-[10px] font-pixel text-center">
                Selecione um item para examinar.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
