/**
 * HUD & Exploration UI Overlay - Dungeon of Design
 */

import React from 'react';
import { PlayerStats, Quest, Position2D } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import { Heart, Zap, BookOpen, Award, Compass, Volume2, VolumeX, Tv, ShieldAlert, Layers, MapPin } from 'lucide-react';

interface HUDProps {
  playerStats: PlayerStats;
  activeQuest: Quest | null;
  playerPosition: Position2D;
  isMuted: boolean;
  isCrtEnabled: boolean;
  onToggleMute: () => void;
  onToggleCrt: () => void;
  onOpenInventory: () => void;
  onOpenCodex: () => void;
  onOpenAchievements: () => void;
  onOpenQuestLog: () => void;
  onTriggerWildBattle: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  playerStats,
  activeQuest,
  playerPosition,
  isMuted,
  isCrtEnabled,
  onToggleMute,
  onToggleCrt,
  onOpenInventory,
  onOpenCodex,
  onOpenAchievements,
  onOpenQuestLog,
  onTriggerWildBattle
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-3 sm:p-4 select-none">
      {/* Top Header Bar */}
      <div className="flex justify-between items-start gap-4">
        {/* Player Status Card */}
        <div className="pointer-events-auto bg-[#120D15]/90 border-2 border-amber-900/80 rounded-xl p-3 shadow-2xl backdrop-blur-md min-w-[210px]">
          <div className="flex items-center justify-between border-b border-amber-900/60 pb-1.5 mb-2">
            <div>
              <div className="text-xs font-pixel font-bold text-amber-300 flex items-center gap-1.5">
                <span className="text-cyan-400 text-[9px]">LV.{playerStats.level}</span>
                <span>{playerStats.title}</span>
              </div>
              <div className="text-[9px] font-mono-code text-amber-200/60">
                XP: {playerStats.xp} / {playerStats.nextLevelXp}
              </div>
            </div>
          </div>

          {/* Health Gauge */}
          <div className="space-y-0.5">
            <div className="flex justify-between text-[9px] font-mono-code text-slate-300">
              <span className="flex items-center gap-1 text-emerald-400 font-pixel text-[8px]"><Heart size={8} /> HP</span>
              <span>{playerStats.hp}/{playerStats.maxHp}</span>
            </div>
            <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                style={{ width: `${(playerStats.hp / playerStats.maxHp) * 100}%` }}
              />
            </div>
          </div>

          {/* Inspiration (MP) Gauge */}
          <div className="space-y-0.5 mt-1.5">
            <div className="flex justify-between text-[9px] font-mono-code text-slate-300">
              <span className="flex items-center gap-1 text-cyan-400 font-pixel text-[8px]"><Zap size={8} /> MP</span>
              <span>{playerStats.inspiration}/{playerStats.maxInspiration}</span>
            </div>
            <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all duration-300 rounded-full"
                style={{ width: `${(playerStats.inspiration / playerStats.maxInspiration) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Top-Right Controls & Radar */}
        <div className="flex items-start gap-2.5">
          {/* Active Quest Box */}
          {activeQuest && (
            <div
              onClick={() => {
                soundEngine.playInteract();
                onOpenQuestLog();
              }}
              className="pointer-events-auto hidden sm:flex flex-col bg-[#120D15]/90 border-2 border-amber-900/80 hover:border-amber-500 p-2 rounded-xl shadow-2xl backdrop-blur-md cursor-pointer transition-colors max-w-xs"
            >
              <div className="flex items-center gap-1 text-amber-400 text-[9px] font-pixel font-bold">
                <Compass size={10} />
                <span>MISSÃO</span>
              </div>
              <div className="text-[11px] font-pixel text-amber-100 truncate mt-0.5">{activeQuest.title}</div>
              <div className="text-[10px] text-amber-200/70 truncate font-mono-code">{activeQuest.objective}</div>
            </div>
          )}

          {/* Mini-Radar Map */}
          <div className="pointer-events-auto w-24 h-24 bg-[#120D15]/90 border-2 border-amber-900/80 rounded-xl p-1.5 flex flex-col justify-between shadow-2xl backdrop-blur-md relative overflow-hidden">
            <div className="flex justify-between items-center text-[8px] font-pixel text-amber-300">
              <span>MAPA</span>
              <MapPin size={10} className="text-amber-400" />
            </div>

            <div className="relative w-full h-14 bg-slate-950 rounded border border-amber-900/60 flex items-center justify-center">
              <div
                className="absolute w-2.5 h-2.5 rounded-full bg-cyan-400 border border-white shadow-sm"
                style={{
                  left: `${(playerPosition.x / 26) * 100}%`,
                  top: `${(playerPosition.y / 26) * 100}%`
                }}
              />
              <div className="absolute top-1 left-2 w-1.5 h-1.5 rounded-full bg-amber-400" />
              <div className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-pink-400" />
              <div className="absolute bottom-1 left-2 w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <div className="absolute bottom-1 right-2 w-1.5 h-1.5 rounded-full bg-indigo-400" />
            </div>
          </div>

          {/* Quick Controls */}
          <div className="pointer-events-auto flex flex-col gap-1.5">
            <button
              onClick={() => {
                soundEngine.playInteract();
                onToggleMute();
              }}
              className="p-2 bg-[#120D15]/90 hover:bg-slate-900 text-amber-300 border-2 border-amber-900/80 rounded-lg shadow-xl"
              title="Alternar Áudio"
            >
              {isMuted ? <VolumeX size={15} className="text-rose-400" /> : <Volume2 size={15} className="text-amber-400" />}
            </button>

            <button
              onClick={() => {
                soundEngine.playInteract();
                onToggleCrt();
              }}
              className={`p-2 bg-[#120D15]/90 hover:bg-slate-900 border-2 border-amber-900/80 rounded-lg shadow-xl ${
                isCrtEnabled ? 'text-amber-400 border-amber-500' : 'text-slate-500'
              }`}
              title="Monitor CRT Arcade"
            >
              <Tv size={15} />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Center Action Strip */}
      <div className="flex justify-center items-center">
        <div className="pointer-events-auto flex items-center gap-2 p-1.5 bg-[#120D15]/95 border-2 border-amber-900/80 rounded-xl shadow-2xl backdrop-blur-md">
          <button
            onClick={() => {
              soundEngine.playInteract();
              onOpenInventory();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-pixel font-bold text-amber-200 hover:text-white hover:bg-slate-900 rounded-lg cursor-pointer"
          >
            <Layers size={12} className="text-amber-400" />
            <span>[I] Baú</span>
          </button>

          <div className="h-4 w-px bg-amber-900/60" />

          <button
            onClick={() => {
              soundEngine.playInteract();
              onOpenCodex();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-pixel font-bold text-amber-200 hover:text-white hover:bg-slate-900 rounded-lg cursor-pointer"
          >
            <BookOpen size={12} className="text-amber-400" />
            <span>[C] Codex</span>
          </button>

          <div className="h-4 w-px bg-amber-900/60" />

          <button
            onClick={() => {
              soundEngine.playInteract();
              onOpenAchievements();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-pixel font-bold text-amber-200 hover:text-white hover:bg-slate-900 rounded-lg cursor-pointer"
          >
            <Award size={12} className="text-emerald-400" />
            <span>[T] Troféus</span>
          </button>

          <div className="h-4 w-px bg-amber-900/60" />

          <button
            onClick={() => {
              soundEngine.playHit();
              onTriggerWildBattle();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-pixel font-bold text-rose-300 hover:text-rose-100 hover:bg-rose-950/50 rounded-lg cursor-pointer"
          >
            <ShieldAlert size={12} className="text-rose-400" />
            <span>Batalhar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
