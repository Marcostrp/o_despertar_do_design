/**
 * Tabuleiro Isométrico em Pixel Art
 * - Cenário 100% pixel art gerado em código (pisos por bioma, paredes de tijolo, pilares, portais animados, baús)
 * - Sprites com quadros de animação reais: idle, andar (4 quadros), dash, golpe (4 quadros)
 * - Ordenação de profundidade: paredes, pilares, props, NPCs e herói passam pelo mesmo "Y-sort"
 * - Iluminação: brilho das tochas, luz ao redor do herói e vinheta
 */

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { WorldTile, NPC, Position2D } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import {
  getFloorSprite, getNeonGlow, getWallBlock, getPillar, getPortalArch, getChest, getChalkboard, getDraftingTable,
  PILLAR_FLOOR_Y
} from '../utils/pixelTiles';
import { getHeroFrame, getNpcFrame, drawSlashFx, drawTorchFlame, HeroAction, HeroView } from '../utils/pixelCharacters';

interface IsometricCanvasProps {
  worldTiles: WorldTile[];
  npcs: NPC[];
  playerPosition: Position2D;
  onMove: (newPos: Position2D) => void;
  onInteractNPC: (npc: NPC) => void;
  onEnterDungeon: (dungeonId: string) => void;
  onOpenChest: (chestId: string) => void;
  onTriggerWildBattle: () => void;
  isPaused: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
  /** altura em pixels de tela acima do chão (padrão 0) */
  z?: number;
  vz?: number;
}

interface DashGhost {
  x: number;
  y: number;
  view: HeroView;
  frame: number;
  isFlipped: boolean;
  alpha: number;
}

export const IsometricCanvas: React.FC<IsometricCanvasProps> = ({
  worldTiles,
  npcs,
  playerPosition,
  onMove,
  onInteractNPC,
  onEnterDungeon,
  onOpenChest,
  onTriggerWildBattle,
  isPaused
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Position & Movement
  const posRef = useRef<{ x: number; y: number }>({ x: playerPosition.x, y: playerPosition.y });
  const isMovingRef = useRef<boolean>(false);
  const isDashingRef = useRef<boolean>(false);
  const isAttackingRef = useRef<boolean>(false);
  const attackTimerRef = useRef<number>(0);
  const dashCooldownRef = useRef<number>(0);
  const animFrameRef = useRef<number>(0);

  // Direção do herói no espaço da tela: 'back' = andando para cima (de costas), 'front' = para baixo
  const viewRef = useRef<HeroView>('front');
  const isFlippedRef = useRef<boolean>(false);

  const keysPressedRef = useRef<{ [key: string]: boolean }>({});
  const particlesRef = useRef<Particle[]>([]);
  const ambientMotesRef = useRef<Particle[]>([]);
  const dashGhostsRef = useRef<DashGhost[]>([]);
  const stepDistanceCounter = useRef<number>(0);
  const autoTriggerCooldownRef = useRef<{ [key: string]: number }>({});

  const [nearbyInteraction, setNearbyInteraction] = useState<{
    type: 'npc' | 'dungeon' | 'chest';
    data: NPC | string;
    label: string;
  } | null>(null);

  // Índice rápido de tiles (vizinhos, água, paredes)
  const tileMap = useMemo(() => {
    const m = new Map<string, WorldTile>();
    worldTiles.forEach(t => m.set(`${t.x},${t.y}`, t));
    return m;
  }, [worldTiles]);

  // TABULEIRO ISOMÉTRICO (Proporção Padrão 2:1 - Largura: 120px, Altura: 60px)
  const tileWidth = 120;
  const tileHeight = 60;

  const worldToIso = useCallback((x: number, y: number, height = 0) => {
    return {
      x: (x - y) * (tileWidth / 2),
      y: (x + y) * (tileHeight / 2) - height * 36
    };
  }, [tileWidth, tileHeight]);

  // Ambient Dungeon Motes
  useEffect(() => {
    ambientMotesRef.current = Array.from({ length: 45 }).map(() => ({
      x: Math.random() * 26,
      y: Math.random() * 26,
      vx: (Math.random() - 0.5) * 0.005,
      vy: (Math.random() - 0.5) * 0.005,
      color: Math.random() > 0.5 ? '#FBBF24' : '#38BDF8',
      size: Math.random() * 3 + 1.5,
      alpha: Math.random() * 0.7 + 0.3,
      decay: 0
    }));
  }, []);

  // Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isPaused) return;
      keysPressedRef.current[e.key.toLowerCase()] = true;

      // Staff Swing Action (Key F or J)
      if ((e.key.toLowerCase() === 'f' || e.key.toLowerCase() === 'j') && !isAttackingRef.current) {
        isAttackingRef.current = true;
        attackTimerRef.current = 24;
        soundEngine.playDesignAttack('kerning');

        for (let i = 0; i < 12; i++) {
          particlesRef.current.push({
            x: posRef.current.x + (Math.random() - 0.5) * 0.4,
            y: posRef.current.y + (Math.random() - 0.5) * 0.4,
            vx: (Math.random() - 0.5) * 0.14,
            vy: (Math.random() - 0.5) * 0.14,
            color: i % 2 ? '#FFFFFF' : '#38BDF8',
            size: Math.random() * 3.5 + 2,
            alpha: 1,
            decay: 0.06,
            z: 40 + Math.random() * 20,
            vz: 0.4
          });
        }
      }

      // Interaction Key (E or Enter or Space)
      if (e.key.toLowerCase() === 'e' || e.key === 'Enter') {
        if (nearbyInteraction) {
          if (nearbyInteraction.type === 'npc') {
            onInteractNPC(nearbyInteraction.data as NPC);
          } else if (nearbyInteraction.type === 'dungeon') {
            onEnterDungeon(nearbyInteraction.data as string);
          } else if (nearbyInteraction.type === 'chest') {
            onOpenChest(nearbyInteraction.data as string);
          }
        }
      }

      // Dash Key (Space)
      if (e.key === ' ' && dashCooldownRef.current <= 0) {
        isDashingRef.current = true;
        dashCooldownRef.current = 30;
        soundEngine.playDash();

        for (let i = 0; i < 16; i++) {
          particlesRef.current.push({
            x: posRef.current.x,
            y: posRef.current.y,
            vx: (Math.random() - 0.5) * 0.18,
            vy: (Math.random() - 0.5) * 0.18,
            color: '#38BDF8',
            size: Math.random() * 3.5 + 2,
            alpha: 0.9,
            decay: 0.05,
            z: 8 + Math.random() * 30,
            vz: 0.2
          });
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressedRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isPaused, nearbyInteraction, onInteractNPC, onEnterDungeon, onOpenChest]);

  // Main 60 FPS Render Loop
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const render = () => {
      tick++;

      // Canvas auto-size
      if (containerRef.current) {
        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight;
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
      }

      const w = canvas.width;
      const h = canvas.height;

      // Update Attack Animation
      if (attackTimerRef.current > 0) {
        attackTimerRef.current--;
        if (attackTimerRef.current <= 0) {
          isAttackingRef.current = false;
        }
      }

      // Decrement auto-trigger cooldowns
      Object.keys(autoTriggerCooldownRef.current).forEach(key => {
        if (autoTriggerCooldownRef.current[key] > 0) {
          autoTriggerCooldownRef.current[key]--;
        }
      });

      // Update Movement & Direction
      if (!isPaused) {
        let dx = 0;
        let dy = 0;
        const keys = keysPressedRef.current;

        // Diagonal & 4-Way Controls
        if (keys['arrowup'] || keys['w']) dy -= 1;
        if (keys['arrowdown'] || keys['s']) dy += 1;
        if (keys['arrowleft'] || keys['a']) dx -= 1;
        if (keys['arrowright'] || keys['d']) dx += 1;

        if (dx !== 0 && dy !== 0) {
          dx *= 0.7071;
          dy *= 0.7071;
        }

        const isMoving = dx !== 0 || dy !== 0;
        isMovingRef.current = isMoving;

        if (isMoving) {
          // Direção na tela (isométrico): screenDx > 0 = direita, screenDy < 0 = para cima (de costas)
          const screenDx = (dx - dy);
          const screenDy = (dx + dy);

          if (screenDy < -0.05) viewRef.current = 'back';
          else if (screenDy > 0.05) viewRef.current = 'front';
          if (screenDx > 0.05) isFlippedRef.current = false;
          else if (screenDx < -0.05) isFlippedRef.current = true;

          const moveSpeed = isDashingRef.current ? 0.095 : 0.044;
          const nextX = Math.max(0.5, Math.min(24.5, posRef.current.x + dx * moveSpeed));
          const nextY = Math.max(0.5, Math.min(24.5, posRef.current.y + dy * moveSpeed));

          // Check Walkable Tile Collision
          const currentTile = worldTiles.find(
            t => Math.floor(t.x) === Math.floor(nextX) && Math.floor(t.y) === Math.floor(nextY)
          );

          const isWalkable = !currentTile || (currentTile.type !== 'stone_wall' && currentTile.type !== 'pillar');

          if (isWalkable) {
            posRef.current.x = nextX;
            posRef.current.y = nextY;
            onMove({ x: nextX, y: nextY });

            // Cycle animated walk frames (4 frames per cycle)
            animFrameRef.current += isDashingRef.current ? 0.28 : 0.16;

            // Spawn Dash Ghost
            if (isDashingRef.current && tick % 2 === 0) {
              dashGhostsRef.current.push({
                x: nextX,
                y: nextY,
                view: viewRef.current,
                frame: Math.floor(animFrameRef.current) % 2,
                isFlipped: isFlippedRef.current,
                alpha: 0.65
              });
            }

            // Poeira dos passos
            if (!isDashingRef.current && tick % 10 === 0) {
              particlesRef.current.push({
                x: nextX, y: nextY,
                vx: (Math.random() - 0.5) * 0.01, vy: (Math.random() - 0.5) * 0.01,
                color: '#8B7FA0', size: 4, alpha: 0.55, decay: 0.045, z: 0, vz: 0.5
              });
            }

            // Step audio
            stepDistanceCounter.current += 1;
            if (stepDistanceCounter.current > (isDashingRef.current ? 12 : 20)) {
              soundEngine.playStep();
              stepDistanceCounter.current = 0;

              if (currentTile && (currentTile.type === 'ink_water' || currentTile.type === 'marble')) {
                if (Math.random() < 0.012) {
                  onTriggerWildBattle();
                }
              }
            }
          }
        }

        if (dashCooldownRef.current > 0) {
          dashCooldownRef.current--;
          if (dashCooldownRef.current <= 18) {
            isDashingRef.current = false;
          }
        }
      }

      // FLUID TOUCH & PROXIMITY INTERACTIONS (Seamless stepping onto portals / touching NPCs)
      let foundInteraction: typeof nearbyInteraction = null;
      const px = posRef.current.x;
      const py = posRef.current.y;

      // 1. Dungeon Portal Proximity & Step-on auto-trigger
      for (const tile of worldTiles) {
        if (tile.type === 'dungeon_portal' && tile.dungeonId) {
          const dist = Math.hypot(px - tile.x, py - tile.y);
          if (dist < 1.0 && (!autoTriggerCooldownRef.current[tile.dungeonId] || autoTriggerCooldownRef.current[tile.dungeonId] <= 0)) {
            // Instant seamless step-in trigger!
            autoTriggerCooldownRef.current[tile.dungeonId] = 120;
            onEnterDungeon(tile.dungeonId);
            return;
          } else if (dist < 1.8) {
            foundInteraction = {
              type: 'dungeon',
              data: tile.dungeonId,
              label: `[E] Entrar na Câmara de Design`
            };
            break;
          }
        }
      }

      // 2. Chest Touch Proximity & Auto-open
      if (!foundInteraction) {
        for (const tile of worldTiles) {
          if (tile.type === 'chest' && tile.chestId && !tile.isOpened) {
            const dist = Math.hypot(px - tile.x, py - tile.y);
            if (dist < 1.1) {
              onOpenChest(tile.chestId);
              break;
            } else if (dist < 1.6) {
              foundInteraction = {
                type: 'chest',
                data: tile.chestId,
                label: `[E] Abrir Baú de Glifos`
              };
              break;
            }
          }
        }
      }

      // 3. NPC Proximity
      if (!foundInteraction) {
        for (const npc of npcs) {
          const dist = Math.hypot(px - npc.isoX, py - npc.isoY);
          if (dist < 1.6) {
            foundInteraction = {
              type: 'npc',
              data: npc,
              label: `[E] Conversar com ${npc.name}`
            };
            break;
          }
        }
      }

      setNearbyInteraction(foundInteraction);

      // Camera Smooth Tracking (Player Centered with tight zoom)
      const playerIso = worldToIso(posRef.current.x, posRef.current.y);
      const cameraX = Math.round(w / 2 - playerIso.x);
      const cameraY = Math.round(h / 2 - playerIso.y);

      ctx.imageSmoothingEnabled = false;

      // Fundo (vazio escuro além do tabuleiro)
      ctx.fillStyle = '#08050B';
      ctx.fillRect(0, 0, w, h);

      const isWaterAt = (tx: number, ty: number) => tileMap.get(`${tx},${ty}`)?.type === 'ink_water';
      const isWallAt = (tx: number, ty: number) => {
        const t = tileMap.get(`${tx},${ty}`);
        return !!t && t.type === 'stone_wall';
      };
      const floorCtx = { isWater: isWaterAt };
      const halfTW = tileWidth / 2;
      const WALL_PX = 48; // altura visual do bloco de parede

      const glows: Array<{ x: number; y: number; r: number; color: string }> = [];

      // --- 1. PISO DO TABULEIRO (tiles planos em pixel art) ---
      worldTiles.forEach(tile => {
        if (tile.type === 'stone_wall') return;
        const iso = worldToIso(tile.x, tile.y);
        const sx = iso.x + cameraX;
        const sy = iso.y + cameraY;
        if (sx < -tileWidth || sx > w + tileWidth || sy < -tileHeight * 2 || sy > h + tileHeight) return;

        ctx.drawImage(getFloorSprite(tile, tick, floorCtx), sx - halfTW, sy);

        if (tile.type === 'grid_neon') {
          ctx.globalAlpha = 0.3 + 0.35 * Math.sin(tick * 0.05 + (tile.x + tile.y) * 0.4);
          ctx.drawImage(getNeonGlow(), sx - halfTW, sy);
          ctx.globalAlpha = 1;
        }
        if (tile.type === 'dungeon_portal') {
          glows.push({ x: sx, y: sy + tileHeight / 2, r: 90, color: 'rgba(34, 211, 238, 0.22)' });
        }
      });

      // --- 2. OBJETOS ORDENADOS POR PROFUNDIDADE (Y-sort) ---
      interface RenderableEntity {
        yOrder: number;
        render: () => void;
      }
      const renderables: RenderableEntity[] = [];
      const shadow = (rx: number, ry: number, alpha = 0.5) => {
        ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
        ctx.fill();
      };

      // Paredes, pilares, portais, baús
      worldTiles.forEach(tile => {
        if (!['stone_wall', 'pillar', 'dungeon_portal', 'chest'].includes(tile.type)) return;
        const iso = worldToIso(tile.x, tile.y);
        const sx = Math.round(iso.x + cameraX);
        const sy = Math.round(iso.y + cameraY);
        if (sx < -tileWidth * 2 || sx > w + tileWidth * 2 || sy < -260 || sy > h + 120) return;

        if (tile.type === 'stone_wall') {
          // tocha na face que está visível (esquerda tem prioridade)
          let torchSide: -1 | 1 | 0 = 0;
          if ((tile.x + tile.y) % 3 === 0) {
            if (!isWallAt(tile.x, tile.y + 1)) torchSide = -1;
            else if (!isWallAt(tile.x + 1, tile.y)) torchSide = 1;
          }
          renderables.push({
            yOrder: tile.x + tile.y,
            render: () => {
              ctx.drawImage(getWallBlock(tile), sx - halfTW, sy - WALL_PX);
              if (torchSide !== 0) {
                const tx = sx + torchSide * 30;
                const ty = sy + 24;
                ctx.fillStyle = '#17101F';
                ctx.fillRect(tx - 6, ty - 2, 12, 20);
                ctx.fillStyle = '#5A3416';
                ctx.fillRect(tx - 3, ty, 6, 16);
                ctx.fillStyle = '#3A3346';
                ctx.fillRect(tx - 6, ty - 2, 12, 4);
                drawTorchFlame(ctx, tx, ty - 2, tick, tile.x + tile.y, 3);
                glows.push({ x: tx, y: ty - 14, r: 78 + Math.sin(tick * 0.28 + tile.x) * 5, color: 'rgba(249, 150, 40, 0.30)' });
              }
            }
          });
        } else if (tile.type === 'pillar') {
          renderables.push({
            yOrder: tile.x + tile.y,
            render: () => {
              ctx.save();
              ctx.translate(sx, sy + tileHeight / 2);
              shadow(30, 11, 0.45);
              ctx.restore();
              ctx.drawImage(getPillar(), sx - halfTW, sy + tileHeight / 2 - PILLAR_FLOOR_Y * 4);
            }
          });
        } else if (tile.type === 'dungeon_portal') {
          renderables.push({
            yOrder: tile.x + tile.y - 0.4,
            render: () => {
              const arch = getPortalArch(Math.floor(tick / 8) % 4);
              // base do arco fica no fundo do tile; (15,39) é o ponto de apoio dentro do sprite
              ctx.drawImage(arch, sx - 60, sy + 20 - 156);
              glows.push({ x: sx, y: sy - 44, r: 70, color: 'rgba(34, 211, 238, 0.16)' });
            }
          });
        } else if (tile.type === 'chest') {
          renderables.push({
            yOrder: tile.x + tile.y,
            render: () => {
              const cy = sy + tileHeight / 2 + 6;
              ctx.save();
              ctx.translate(sx, cy);
              shadow(26, 9, 0.5);
              ctx.restore();
              const bounce = tile.isOpened ? 0 : Math.round(Math.sin(tick * 0.08 + tile.x) * 1.4);
              ctx.drawImage(getChest(!!tile.isOpened), sx - 36, cy - 64 + bounce);
              if (!tile.isOpened) {
                // brilho cintilante
                const tw = Math.floor((tick + tile.x * 13) / 22) % 4;
                if (tw < 2) {
                  const gx = sx + (tw === 0 ? -16 : 12);
                  const gy = cy - 50 + (tw === 0 ? 0 : -6);
                  ctx.fillStyle = '#FFFFFF';
                  ctx.fillRect(gx - 2, gy, 12, 4);
                  ctx.fillRect(gx + 2, gy - 4, 4, 12);
                }
                glows.push({ x: sx, y: cy - 28, r: 56, color: 'rgba(250, 204, 21, 0.14)' });
              }
            }
          });
        }
      });

      // Props de cenário (lousas e pranchetas)
      [
        { x: 5, y: 5, type: 'chalkboard' },
        { x: 15, y: 5, type: 'drafting_table' },
        { x: 5, y: 15, type: 'drafting_table' },
        { x: 19, y: 19, type: 'chalkboard' }
      ].forEach(prop => {
        renderables.push({
          yOrder: prop.x + prop.y,
          render: () => {
            const iso = worldToIso(prop.x, prop.y);
            const sx = Math.round(iso.x + cameraX);
            const sy = Math.round(iso.y + cameraY + tileHeight / 2);
            ctx.save();
            ctx.translate(sx, sy);
            shadow(34, 11, 0.5);
            ctx.restore();
            if (prop.type === 'chalkboard') ctx.drawImage(getChalkboard(), sx - 48, sy - 112);
            else ctx.drawImage(getDraftingTable(), sx - 56, sy - 76);
          }
        });
      });

      // NPCs (respiram; acenam quando o herói se aproxima)
      npcs.forEach(npc => {
        renderables.push({
          yOrder: npc.isoX + npc.isoY,
          render: () => {
            const iso = worldToIso(npc.isoX, npc.isoY);
            const sx = Math.round(iso.x + cameraX);
            const sy = Math.round(iso.y + cameraY + tileHeight / 2);

            const near = Math.hypot(px - npc.isoX, py - npc.isoY) < 4;
            const frame = near ? 4 + (Math.floor(tick / 10) % 4) : Math.floor(tick / 18) % 4;
            const spr = getNpcFrame(npc.id, npc.avatarColor, frame, 3);

            ctx.save();
            ctx.translate(sx, sy);
            shadow(26, 10, 0.55);
            ctx.restore();
            ctx.drawImage(spr.canvas, sx - spr.ax, sy - spr.ay);

            // marcador + nome
            const bob = Math.round(Math.sin(tick * 0.12) * 3);
            ctx.fillStyle = '#17101F';
            ctx.fillRect(sx - 14, sy - 124 + bob, 28, 24);
            ctx.fillStyle = '#F59E0B';
            ctx.fillRect(sx - 11, sy - 121 + bob, 22, 18);
            ctx.fillStyle = '#FDE68A';
            ctx.fillRect(sx - 11, sy - 121 + bob, 22, 3);
            ctx.fillStyle = '#17101F';
            ctx.font = '10px "Press Start 2P", monospace';
            ctx.textAlign = 'center';
            ctx.fillText('Aa', sx, sy - 106 + bob);

            ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
            ctx.lineWidth = 4;
            ctx.strokeStyle = 'rgba(8,5,11,0.95)';
            ctx.strokeText(npc.name, sx, sy - 132 + bob);
            ctx.fillStyle = '#FFFFFF';
            ctx.fillText(npc.name, sx, sy - 132 + bob);
          }
        });
      });

      // Imagens residuais do dash
      dashGhostsRef.current.forEach(ghost => {
        ghost.alpha -= 0.05;
        if (ghost.alpha > 0) {
          renderables.push({
            yOrder: ghost.x + ghost.y - 0.01,
            render: () => {
              const iso = worldToIso(ghost.x, ghost.y);
              const sx = Math.round(iso.x + cameraX);
              const sy = Math.round(iso.y + cameraY + tileHeight / 2);
              const spr = getHeroFrame({ view: ghost.view, action: 'dash', frame: ghost.frame }, 3);
              ctx.save();
              ctx.translate(sx, sy);
              ctx.globalAlpha = ghost.alpha * 0.6;
              if (ghost.isFlipped) ctx.scale(-1, 1);
              ctx.drawImage(spr.canvas, -spr.ax, -spr.ay);
              ctx.restore();
            }
          });
        }
      });
      dashGhostsRef.current = dashGhostsRef.current.filter(g => g.alpha > 0);

      // HERÓI — quadros de animação reais
      renderables.push({
        yOrder: posRef.current.x + posRef.current.y,
        render: () => {
          const iso = worldToIso(posRef.current.x, posRef.current.y);
          let sx = Math.round(iso.x + cameraX);
          const sy = Math.round(iso.y + cameraY + tileHeight / 2);
          const flip = isFlippedRef.current;

          let action: HeroAction = 'idle';
          let frame = Math.floor(tick / 30) % 2;
          let attackProgress = 0;
          if (isAttackingRef.current) {
            action = 'attack';
            const elapsed = 24 - attackTimerRef.current;
            frame = Math.min(3, Math.floor(elapsed / 6));
            attackProgress = (elapsed - 5) / 14;
            // investida curta para frente durante o golpe
            sx += [-1, 2, 6, 4][frame] * 3 * (flip ? -1 : 1);
          } else if (isDashingRef.current) {
            action = 'dash';
            frame = Math.floor(animFrameRef.current) % 2;
          } else if (isMovingRef.current) {
            action = 'walk';
            frame = Math.floor(animFrameRef.current) % 4;
          }

          const spr = getHeroFrame({ view: viewRef.current, action, frame }, 3);

          ctx.save();
          ctx.translate(sx, sy);
          shadow(action === 'dash' ? 30 : 26, 10, 0.6);
          if (flip) ctx.scale(-1, 1);
          ctx.drawImage(spr.canvas, -spr.ax, -spr.ay);

          // rastro de energia no cajado
          if (action === 'attack' && attackProgress > 0) {
            drawSlashFx(ctx, 18 * 3, -spr.ay + 22 * 3, 1, attackProgress, 3, 17);
          }
          ctx.restore();

          glows.push({ x: sx, y: sy - 40, r: 150, color: 'rgba(255, 196, 120, 0.13)' });
        }
      });

      renderables.sort((a, b) => a.yOrder - b.yOrder);
      renderables.forEach(r => r.render());

      // --- 3. PARTÍCULAS ---
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.z = (p.z ?? 0) + (p.vz ?? 0);
        p.alpha -= p.decay;
        if (p.alpha <= 0) {
          particlesRef.current.splice(i, 1);
          continue;
        }
        const iso = worldToIso(p.x, p.y);
        const size = Math.max(2, Math.round(p.size / 2) * 2);
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.fillRect(
          Math.round(iso.x + cameraX - size / 2),
          Math.round(iso.y + cameraY + tileHeight / 2 - (p.z ?? 0)),
          size,
          size
        );
        ctx.restore();
      }

      // Pontinhos de luz flutuando
      ambientMotesRef.current.forEach(m => {
        m.x = (m.x + m.vx + 26) % 26;
        m.y = (m.y + m.vy + 26) % 26;
        const iso = worldToIso(m.x, m.y);
        ctx.save();
        ctx.globalAlpha = m.alpha * (0.6 + Math.sin(tick * 0.05 + m.x) * 0.4);
        ctx.fillStyle = m.color;
        const ms = Math.max(2, Math.round(m.size / 2) * 2);
        ctx.fillRect(Math.round(iso.x + cameraX), Math.round(iso.y + cameraY - 20), ms, ms);
        ctx.restore();
      });

      // --- 4. ILUMINAÇÃO ---
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      glows.forEach(g => {
        if (g.x < -g.r || g.x > w + g.r || g.y < -g.r || g.y > h + g.r) return;
        const grad = ctx.createRadialGradient(g.x, g.y, 2, g.x, g.y, g.r);
        grad.addColorStop(0, g.color);
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(g.x - g.r, g.y - g.r, g.r * 2, g.r * 2);
      });
      ctx.restore();

      // Vinheta escura nas bordas
      const vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.32, w / 2, h / 2, Math.max(w, h) * 0.78);
      vg.addColorStop(0, 'rgba(8, 5, 11, 0)');
      vg.addColorStop(1, 'rgba(8, 5, 11, 0.78)');
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, w, h);

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [worldTiles, tileMap, npcs, isPaused, onMove, onEnterDungeon, onOpenChest, onTriggerWildBattle, tileWidth, tileHeight, worldToIso]);

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden bg-slate-950 select-none">
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Action Controls Hints Badge */}
      <div className="absolute top-4 right-4 z-20 pointer-events-none hidden sm:flex items-center gap-2 bg-slate-950/80 border border-amber-500/50 rounded-xl px-3 py-1.5 backdrop-blur-md">
        <span className="text-[10px] font-pixel text-amber-300">[WASD / Setas] Andar</span>
        <span className="text-slate-600">•</span>
        <span className="text-[10px] font-pixel text-cyan-300">[Espaço] Dash</span>
        <span className="text-slate-600">•</span>
        <span className="text-[10px] font-pixel text-emerald-300">[F] Atacar</span>
        <span className="text-slate-600">•</span>
        <span className="text-[10px] font-pixel text-amber-400">[E] Interagir / Encostar</span>
      </div>

      {/* Interaction prompt banner */}
      {nearbyInteraction && (
        <div className="absolute bottom-24 inset-x-0 flex justify-center pointer-events-none z-30 animate-bounce">
          <div className="bg-slate-950/95 border-2 border-amber-500 rounded-xl px-5 py-2.5 shadow-2xl backdrop-blur-md flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-amber-400 animate-ping" />
            <span className="font-pixel text-amber-300 text-xs tracking-wider">
              {nearbyInteraction.label}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
