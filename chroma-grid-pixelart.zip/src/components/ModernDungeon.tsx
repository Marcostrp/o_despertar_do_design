/**
 * Dungeon of Design - Workshop & Simplified Puzzle Chambers
 * Features:
 * - Ultra-intuitive, visual and fun design challenges (1-click/1-slider instant feedback)
 * - Live Workshop Scene Canvas always visible with the animated Hero Sprite
 * - Compact and elegant bottom console with instant reward triggers
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { DungeonRoom, InventoryItem, SpecialAttack } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import confetti from 'canvas-confetti';
import { Sparkles, ArrowLeft, CheckCircle2, Sliders, Type, Grid, Eye, Award, HelpCircle } from 'lucide-react';
import { loadTransparentSprite } from '../utils/spriteLoader';

interface ModernDungeonProps {
  room: DungeonRoom;
  inventory: InventoryItem[];
  onSolvePuzzle: (rewardItem: InventoryItem, rewardAttackId?: string) => void;
  onExitDungeon: () => void;
  unlockedAttacks: SpecialAttack[];
}

export const ModernDungeon: React.FC<ModernDungeonProps> = ({
  room,
  inventory,
  onSolvePuzzle,
  onExitDungeon,
  unlockedAttacks
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isSolved, setIsSolved] = useState<boolean>(room.isCompleted);
  const [activeTab, setActiveTab] = useState<'puzzle' | 'theory'>('puzzle');

  // Sprites for Live Scene
  const heroSpriteRef = useRef<HTMLCanvasElement | null>(null);
  const bgImageRef = useRef<HTMLImageElement | null>(null);

  // --- SIMPLIFIED PUZZLE 1: COLOR HARMONY (Pick Complementary Color) ---
  const [selectedColorOption, setSelectedColorOption] = useState<string | null>(null);
  const isColorSolved = selectedColorOption === 'purple';

  // --- SIMPLIFIED PUZZLE 2: TYPOGRAPHY KERNING (Single Intuitive Slider) ---
  const [kerningSpacing, setKerningSpacing] = useState<number>(20);
  const isKerningBalanced = kerningSpacing <= -6 && kerningSpacing >= -16;

  // --- SIMPLIFIED PUZZLE 3: GESTALT (Rotate 1 Misaligned Piece) ---
  const [gestaltPieceAngle, setGestaltPieceAngle] = useState<number>(90);
  const isGestaltSolved = gestaltPieceAngle % 360 === 0;

  // --- SIMPLIFIED PUZZLE 4: SWISS GRID (1-Click Snap to Golden Column) ---
  const [selectedGridCol, setSelectedGridCol] = useState<'left' | 'center' | 'right' | null>(null);
  const isGridAligned = selectedGridCol === 'center';

  // Load Sprites for Live Scene
  useEffect(() => {
    let isMounted = true;
    soundEngine.playMusic('dungeon');
    soundEngine.playWarp();

    const loadAssets = async () => {
      const hero = await loadTransparentSprite('/src/assets/images/hero_battle_action_sprite_1790870776858.jpg', { threshold: 30 });
      if (!isMounted) return;
      heroSpriteRef.current = hero;

      const bg = new Image();
      bg.src = '/src/assets/images/dungeon_puzzle_slate_1790813253324.jpg';
      bg.onload = () => {
        if (!isMounted) return;
        bgImageRef.current = bg;
      };
    };

    loadAssets();

    return () => {
      isMounted = false;
      soundEngine.playMusic('overworld');
    };
  }, []);

  // 60 FPS Canvas Rendering for Live Dungeon Scene & Hero Sprite
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const render = () => {
      tick++;

      if (containerRef.current) {
        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight;
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
      }

      const w = canvas.width;
      const h = canvas.height;

      ctx.imageSmoothingEnabled = false;

      // 1. Draw Workshop Stone Slate Background
      if (bgImageRef.current && bgImageRef.current.complete && bgImageRef.current.naturalWidth > 0) {
        ctx.drawImage(bgImageRef.current, 0, 0, w, h);
      } else {
        ctx.fillStyle = '#100B16';
        ctx.fillRect(0, 0, w, h);
      }

      // Dynamic Torchlight Glow Overlays
      [Math.round(w * 0.18), Math.round(w * 0.82)].forEach(tx => {
        const flicker = Math.sin(tick * 0.25 + tx) * 6;
        const torchLight = ctx.createRadialGradient(tx, Math.round(h * 0.22), 4, tx, Math.round(h * 0.22), 110 + flicker);
        torchLight.addColorStop(0, 'rgba(249, 115, 22, 0.45)');
        torchLight.addColorStop(0.5, 'rgba(245, 158, 11, 0.15)');
        torchLight.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = torchLight;
        ctx.beginPath();
        ctx.arc(tx, Math.round(h * 0.22), 110 + flicker, 0, Math.PI * 2);
        ctx.fill();
      });

      // 2. Render Hero Sprite in the Workshop
      const heroX = Math.round(w * 0.22);
      const heroY = Math.round(h * 0.42);
      const heroIdleBob = Math.sin(tick * 0.1) * 3;
      const staffAngle = isSolved ? Math.sin(tick * 0.2) * 20 : 0;

      ctx.save();
      ctx.translate(heroX, heroY + heroIdleBob);

      // Hero Shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      ctx.beginPath();
      ctx.ellipse(0, 6, 32, 13, 0, 0, Math.PI * 2);
      ctx.fill();

      // Draw Hero Sprite
      if (heroSpriteRef.current) {
        const spriteSize = 120;
        ctx.drawImage(
          heroSpriteRef.current,
          -spriteSize / 2,
          -spriteSize + 20,
          spriteSize,
          spriteSize
        );
      }

      // Sparkle on pencil staff
      const sparkleRot = tick * 0.18;
      ctx.save();
      ctx.translate(32, -75 + staffAngle);
      ctx.rotate(sparkleRot);
      ctx.fillStyle = '#38BDF8';
      ctx.fillRect(-7, -2, 14, 4);
      ctx.fillRect(-2, -7, 4, 14);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(-2.5, -2.5, 5, 5);
      ctx.restore();

      // Solved Aura
      if (isSolved) {
        ctx.save();
        ctx.strokeStyle = '#FBBF24';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, -50, 58 + Math.sin(tick * 0.15) * 4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isSolved]);

  const handleCompleteRoom = useCallback(() => {
    if (isSolved) return;
    setIsSolved(true);
    soundEngine.playPuzzleSolve();

    confetti({
      particleCount: 90,
      spread: 80,
      origin: { y: 0.6 },
      colors: ['#F59E0B', '#38BDF8', '#E11D48', '#10B981', '#FFFFFF']
    });

    onSolvePuzzle(room.rewardItem, room.rewardAttackId);
  }, [isSolved, room, onSolvePuzzle]);

  return (
    <div ref={containerRef} className="relative w-full h-full bg-slate-950 flex flex-col justify-between overflow-hidden select-none font-sans">
      {/* 1. LIVE WORKSHOP SCENE CANVAS (Always Visible) */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full z-10" />

      {/* 2. TOP HUD BAR */}
      <div className="relative z-20 p-4 flex justify-between items-center bg-slate-950/80 backdrop-blur-md border-b border-amber-600/50">
        <button
          onClick={onExitDungeon}
          className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-amber-500/60 hover:bg-slate-800 text-amber-300 rounded-xl text-xs font-pixel shadow cursor-pointer transition-all active:scale-95"
        >
          <ArrowLeft size={14} />
          <span>SAIR DA CÂMARA</span>
        </button>

        <div className="text-center">
          <div className="font-pixel text-amber-300 text-xs sm:text-sm tracking-wider flex items-center gap-2 justify-center">
            <Sparkles className="w-4 h-4 text-amber-400" />
            {room.name}
          </div>
          <div className="text-[10px] text-cyan-400 font-mono-code">{room.subtitle}</div>
        </div>

        <div className="flex items-center gap-2">
          {isSolved ? (
            <span className="flex items-center gap-1 text-[11px] font-pixel text-emerald-400 bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-500/60 shadow">
              <CheckCircle2 size={14} /> RESOLVIDO
            </span>
          ) : (
            <span className="text-[11px] font-pixel text-amber-400/90 bg-amber-950/80 px-3 py-1.5 rounded-xl border border-amber-500/40">
              EM ANDAMENTO
            </span>
          )}
        </div>
      </div>

      {/* 3. SIMPLIFIED & VISUAL INTERACTIVE PUZZLE CONSOLE */}
      <div className="relative z-20 mt-auto p-4 flex justify-center pointer-events-none">
        <div className="pointer-events-auto max-w-xl w-full bg-[#120D15]/92 border-2 border-amber-600/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md flex flex-col gap-3">
          {/* Tabs */}
          <div className="flex justify-between items-center pb-2 border-b border-amber-900/60">
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setActiveTab('puzzle');
                  soundEngine.playInteract();
                }}
                className={`px-3 py-1 rounded-lg text-xs font-pixel transition-all cursor-pointer ${
                  activeTab === 'puzzle'
                    ? 'bg-amber-500 text-slate-950 font-bold shadow'
                    : 'text-amber-200/60 hover:text-amber-100 bg-slate-900/50'
                }`}
              >
                DESAFIO VISUAL
              </button>
              <button
                onClick={() => {
                  setActiveTab('theory');
                  soundEngine.playInteract();
                }}
                className={`px-3 py-1 rounded-lg text-xs font-pixel transition-all cursor-pointer ${
                  activeTab === 'theory'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                    : 'text-cyan-200/60 hover:text-cyan-100 bg-slate-900/50'
                }`}
              >
                GUIA RÁPIDO
              </button>
            </div>

            <div className="text-[10px] font-mono-code text-amber-300/80">
              {room.theme.toUpperCase()}
            </div>
          </div>

          {/* Tab 1: Simplified Visual Challenge */}
          {activeTab === 'puzzle' && (
            <div className="space-y-3 text-xs">
              {/* THEME 1: COLOR HARMONY (1-Click Color Choice) */}
              {room.theme === 'color_theory' && (
                <div className="space-y-3">
                  <p className="text-amber-200 font-pixel text-[11px]">
                    Toque na cor <span className="text-purple-400 font-bold">Complementar (180°)</span> que neutraliza a escuridão do portal ao lado do Amarelo Dourado:
                  </p>

                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => {
                        setSelectedColorOption('purple');
                        soundEngine.playInteract();
                      }}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center gap-2 transition-all cursor-pointer ${
                        selectedColorOption === 'purple'
                          ? 'border-purple-400 bg-purple-950/80 scale-105 shadow-lg shadow-purple-500/30'
                          : 'border-slate-700 bg-slate-900/80 hover:border-purple-500'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-purple-500 shadow-md animate-pulse" />
                      <span className="font-pixel text-[10px] text-purple-300">Roxo Real (180°)</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedColorOption('red');
                        soundEngine.playHit();
                      }}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center gap-2 transition-all cursor-pointer ${
                        selectedColorOption === 'red'
                          ? 'border-rose-400 bg-rose-950/80'
                          : 'border-slate-700 bg-slate-900/80 hover:border-rose-500'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-rose-500 shadow-md" />
                      <span className="font-pixel text-[10px] text-rose-300">Vermelho</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedColorOption('green');
                        soundEngine.playHit();
                      }}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center gap-2 transition-all cursor-pointer ${
                        selectedColorOption === 'green'
                          ? 'border-emerald-400 bg-emerald-950/80'
                          : 'border-slate-700 bg-slate-900/80 hover:border-emerald-500'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-emerald-500 shadow-md" />
                      <span className="font-pixel text-[10px] text-emerald-300">Verde</span>
                    </button>
                  </div>

                  {isColorSolved && !isSolved && (
                    <button
                      onClick={handleCompleteRoom}
                      className="w-full py-2.5 bg-gradient-to-r from-purple-500 to-amber-500 hover:from-purple-400 hover:to-amber-400 text-slate-950 font-pixel font-bold rounded-xl shadow-lg transition-all animate-pulse cursor-pointer mt-2"
                    >
                      ✨ HARMONIA PERFEITA! (CONCLUIR)
                    </button>
                  )}
                </div>
              )}

              {/* THEME 2: TYPOGRAPHY & KERNING (1 Simple Slider with Snap) */}
              {room.theme === 'typography_kerning' && (
                <div className="space-y-3">
                  <p className="text-amber-200 font-pixel text-[11px]">
                    Deslize para aproximar as letras <span className="text-cyan-400">A</span> e <span className="text-cyan-400">V</span> até o espaçamento óptico perfeito:
                  </p>

                  <div className="bg-black/90 rounded-xl p-4 border border-amber-500/40 flex flex-col items-center justify-center min-h-[80px]">
                    <div className="text-3xl font-bold font-mono tracking-normal text-amber-100 flex items-center">
                      <span>A</span>
                      <span style={{ marginLeft: `${kerningSpacing}px` }}>V</span>
                    </div>
                    <div className={`text-[10px] font-pixel mt-2 ${isKerningBalanced ? 'text-emerald-400' : 'text-slate-400'}`}>
                      {isKerningBalanced ? '✨ ESPAÇAMENTO ÓPTICO EQUILIBRADO!' : '↔️ Letras muito afastadas ou sobrepostas'}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setKerningSpacing(prev => Math.max(-25, prev - 4))}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-pixel text-[10px] rounded-lg border border-slate-700 cursor-pointer"
                    >
                      ◀ Aproximar
                    </button>
                    <input
                      type="range"
                      min="-25"
                      max="30"
                      value={kerningSpacing}
                      onChange={e => setKerningSpacing(Number(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                    <button
                      onClick={() => setKerningSpacing(prev => Math.min(30, prev + 4))}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-pixel text-[10px] rounded-lg border border-slate-700 cursor-pointer"
                    >
                      Afastar ▶
                    </button>
                  </div>

                  {isKerningBalanced && !isSolved && (
                    <button
                      onClick={handleCompleteRoom}
                      className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-cyan-500 hover:from-amber-400 hover:to-cyan-400 text-slate-950 font-pixel font-bold rounded-xl shadow-lg transition-all animate-pulse cursor-pointer mt-1"
                    >
                      ✨ CANALIZAR KERNING PERFEITO (CONCLUIR)
                    </button>
                  )}
                </div>
              )}

              {/* THEME 3: GESTALT (1-Tap to Rotate Piece) */}
              {room.theme === 'gestalt_negative_space' && (
                <div className="space-y-3">
                  <p className="text-amber-200 font-pixel text-[11px]">
                    Toque na peça de baixo para girá-la até fechar a forma no espaço em branco:
                  </p>

                  <div className="grid grid-cols-2 gap-2 max-w-xs mx-auto bg-black/90 p-3 rounded-xl border border-amber-500/40">
                    <div className="h-16 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-tr-full bg-cyan-400" />
                    </div>
                    <div className="h-16 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-tl-full bg-cyan-400" />
                    </div>
                    <div className="h-16 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-br-full bg-cyan-400" />
                    </div>
                    <button
                      onClick={() => {
                        setGestaltPieceAngle(prev => (prev + 90) % 360);
                        soundEngine.playInteract();
                      }}
                      className="h-16 rounded-lg bg-slate-900 border-2 border-amber-400 hover:border-cyan-400 flex flex-col items-center justify-center transition-all cursor-pointer"
                    >
                      <div
                        className="w-8 h-8 rounded-bl-full bg-amber-400 transition-transform duration-300"
                        style={{ transform: `rotate(${gestaltPieceAngle}deg)` }}
                      />
                      <span className="text-[9px] text-amber-300 font-pixel mt-1">Girar (Toque)</span>
                    </button>
                  </div>

                  {isGestaltSolved && !isSolved && (
                    <button
                      onClick={handleCompleteRoom}
                      className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-cyan-500 hover:from-amber-400 hover:to-cyan-400 text-slate-950 font-pixel font-bold rounded-xl shadow-lg transition-all animate-pulse cursor-pointer"
                    >
                      ✨ FORMA FECHADA COM SUCESSO! (CONCLUIR)
                    </button>
                  )}
                </div>
              )}

              {/* THEME 4: SWISS GRID (1-Click Grid Alignment) */}
              {room.theme === 'swiss_grid' && (
                <div className="space-y-3">
                  <p className="text-amber-200 font-pixel text-[11px]">
                    Toque no ponto ideal do Grid de 8 pontos para centralizar o layout com harmonia:
                  </p>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => {
                        setSelectedGridCol('left');
                        soundEngine.playHit();
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        selectedGridCol === 'left' ? 'border-rose-400 bg-rose-950/80' : 'border-slate-700 bg-slate-900/80'
                      }`}
                    >
                      <div className="w-full h-4 bg-slate-700 rounded" />
                      <span className="text-[10px] font-pixel text-slate-300">Esquerda</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedGridCol('center');
                        soundEngine.playInteract();
                      }}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        selectedGridCol === 'center'
                          ? 'border-emerald-400 bg-emerald-950/80 scale-105 shadow-lg shadow-emerald-500/30'
                          : 'border-slate-700 bg-slate-900/80 hover:border-emerald-500'
                      }`}
                    >
                      <div className="w-full h-4 bg-emerald-400 rounded shadow animate-pulse" />
                      <span className="text-[10px] font-pixel text-emerald-300 font-bold">Centro Áureo (8pt)</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedGridCol('right');
                        soundEngine.playHit();
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        selectedGridCol === 'right' ? 'border-rose-400 bg-rose-950/80' : 'border-slate-700 bg-slate-900/80'
                      }`}
                    >
                      <div className="w-full h-4 bg-slate-700 rounded" />
                      <span className="text-[10px] font-pixel text-slate-300">Direita</span>
                    </button>
                  </div>

                  {isGridAligned && !isSolved && (
                    <button
                      onClick={handleCompleteRoom}
                      className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-pixel font-bold rounded-xl shadow-lg transition-all animate-pulse cursor-pointer mt-1"
                    >
                      ✨ GRID PERFEITAMENTE ALINHADO! (CONCLUIR)
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Theory & Principles Lore */}
          {activeTab === 'theory' && (
            <div className="space-y-2 bg-slate-950/80 p-3 rounded-xl border border-amber-900/60 text-amber-100/90 text-xs">
              <div className="text-amber-300 font-pixel text-[11px] mb-1 flex items-center gap-1.5">
                <HelpCircle size={14} /> Fundamentos do Princípio
              </div>
              <p className="leading-relaxed font-sans">{room.principleGuide}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
