/**
 * NPC Dialogue & Story Modal - Dungeon of Design
 */

import React, { useState } from 'react';
import { NPC } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import { ArrowRight, X } from 'lucide-react';

interface NPCModalProps {
  npc: NPC;
  onClose: () => void;
  onAcceptQuest?: (questId: string) => void;
}

export const NPCModal: React.FC<NPCModalProps> = ({ npc, onClose, onAcceptQuest }) => {
  const [dialogIndex, setDialogIndex] = useState(0);

  const handleNext = () => {
    soundEngine.playInteract();
    if (dialogIndex < npc.dialogue.length - 1) {
      setDialogIndex(dialogIndex + 1);
    } else {
      if (npc.questId && onAcceptQuest) {
        onAcceptQuest(npc.questId);
      }
      onClose();
    }
  };

  const portraitSrc =
    npc.id === 'npc_jan'
      ? '/src/assets/images/npc_master_jan_1790813232141.jpg'
      : npc.id === 'npc_paula'
      ? '/src/assets/images/npc_sage_paula_1790813243187.jpg'
      : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#120D15] border-2 border-amber-600/80 rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/60 pb-3">
          <div className="flex items-center gap-3">
            {portraitSrc ? (
              <div className="w-12 h-12 rounded-xl overflow-hidden border-2 border-amber-400/80 bg-black shadow">
                <img
                  src={portraitSrc}
                  alt={npc.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center font-pixel text-slate-950 font-bold text-sm border-2 border-amber-400/80"
                style={{ backgroundColor: npc.avatarColor }}
              >
                {npc.name[0]}
              </div>
            )}
            <div>
              <h3 className="text-xs sm:text-sm font-pixel font-bold text-amber-300">{npc.name}</h3>
              <p className="text-[10px] text-cyan-400 font-mono-code">{npc.title}</p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playInteract();
              onClose();
            }}
            className="text-amber-200/60 hover:text-white p-1"
          >
            <X size={18} />
          </button>
        </div>

        {/* Dialogue Body */}
        <div className="min-h-[100px] bg-slate-950/90 border border-amber-900/80 rounded-xl p-4 flex items-center shadow-inner">
          <p className="text-xs sm:text-sm text-amber-100 leading-relaxed font-sans">
            "{npc.dialogue[dialogIndex]}"
          </p>
        </div>

        {/* Action Button */}
        <div className="flex justify-between items-center pt-1">
          <span className="text-[10px] font-mono-code text-amber-300/60">
            {dialogIndex + 1} / {npc.dialogue.length}
          </span>

          <button
            onClick={handleNext}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-pixel font-bold text-[11px] rounded-xl transition-all shadow cursor-pointer"
          >
            <span>{dialogIndex < npc.dialogue.length - 1 ? 'Continuar' : 'Entendido'}</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
