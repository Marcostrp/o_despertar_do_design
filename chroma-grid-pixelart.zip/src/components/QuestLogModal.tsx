/**
 * Quest Log Modal - Dungeon of Design
 */

import React from 'react';
import { Quest } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import { Compass, X, CheckCircle2 } from 'lucide-react';

interface QuestLogModalProps {
  quests: Quest[];
  onClose: () => void;
}

export const QuestLogModal: React.FC<QuestLogModalProps> = ({ quests, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#120D15] border-2 border-amber-600/80 rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b-2 border-amber-900/80 pb-3">
          <div className="flex items-center gap-2 text-amber-400">
            <Compass size={18} />
            <h3 className="text-xs sm:text-sm font-pixel font-bold text-amber-300">Missões da Masmorra</h3>
          </div>
          <button
            onClick={() => {
              soundEngine.playInteract();
              onClose();
            }}
            className="text-amber-200/60 hover:text-white p-1"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-3 max-h-[380px] overflow-y-auto">
          {quests.map((q) => (
            <div
              key={q.id}
              className={`p-4 rounded-xl border-2 ${
                q.completed
                  ? 'bg-emerald-950/30 border-emerald-500/50'
                  : 'bg-slate-950/80 border-amber-900/60'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-pixel font-bold text-amber-200 flex items-center gap-1.5">
                  <span>{q.title}</span>
                  {q.completed && <CheckCircle2 size={14} className="text-emerald-400" />}
                </h4>
                <span className="text-[10px] font-mono-code text-cyan-400">
                  {q.progress} / {q.maxProgress}
                </span>
              </div>
              <p className="text-xs text-amber-100/80 mt-1 font-sans">{q.description}</p>
              <div className="mt-2 text-[10px] font-mono-code text-amber-300/70">
                Lorde / Mestre: <span className="text-amber-200">{q.giver}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
