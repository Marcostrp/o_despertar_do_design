/**
 * Title Screen & Start Menu - Dungeon of Design
 * Faithful 16-bit retro CRT arcade aesthetic matching the Dungeon of Design hero and dungeon visual.
 */

import React, { useState } from 'react';
import { soundEngine } from '../audio/soundEngine';
import { Play, HelpCircle, BookOpen, Volume2, Sparkles, Compass, Shield } from 'lucide-react';

interface TitleScreenProps {
  onStartGame: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({ onStartGame }) => {
  const [showHelp, setShowHelp] = useState(false);
  const [showPhilosophy, setShowPhilosophy] = useState(false);

  const handleStart = () => {
    soundEngine.init();
    soundEngine.playLevelUp();
    soundEngine.playMusic('overworld');
    onStartGame();
  };

  return (
    <div className="relative w-full h-full bg-[#0a0709] text-slate-100 flex flex-col justify-between p-4 sm:p-6 select-none overflow-hidden">
      {/* Background Hero Splash Illustration */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_dungeon_cover_1790813064512.jpg"
          alt="Dungeon of Design Hero"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center filter brightness-[0.65] contrast-[1.15]"
        />
        {/* Warm Torchlight & Vignette Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0709] via-black/40 to-[#0a0709]/80" />
      </div>

      {/* Top Bar Contract */}
      <header className="relative z-10 flex items-center justify-between max-w-5xl w-full mx-auto">
        <div className="flex items-center gap-2.5 bg-black/60 px-3 py-1.5 rounded-lg border border-amber-900/40 backdrop-blur-sm">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shadow-sm shadow-amber-400"></span>
          <span className="text-xs font-pixel font-bold text-amber-300 tracking-wider">DUNGEON OF DESIGN</span>
        </div>

        <div className="hidden sm:flex items-center gap-3 text-xs font-mono-code text-amber-200/80 bg-black/60 px-3 py-1.5 rounded-lg border border-amber-900/40 backdrop-blur-sm">
          <span>16-BIT RETRO CONSOLE</span>
          <span>·</span>
          <span>PIXEL ART RPG</span>
        </div>
      </header>

      {/* Hero Title Lockup & Thematic Chalkboard Frame */}
      <div className="relative z-10 max-w-2xl mx-auto text-center space-y-4 my-auto">
        {/* Chalkboard Graphic Badge */}
        <div className="inline-flex items-center gap-3 px-4 py-1.5 bg-slate-950/85 border-2 border-amber-500/60 rounded-xl shadow-2xl backdrop-blur-md">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-cyan-400 via-rose-500 to-amber-400 border border-white/40 shadow-inner" />
          <span className="text-xs font-pixel text-amber-300 font-bold">Aa · COLOR · KERNING · GRID</span>
        </div>

        {/* Grand Title */}
        <div className="space-y-1">
          <h1 className="text-4xl sm:text-6xl font-pixel font-black text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-400 to-orange-600 tracking-wider drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
            DUNGEON OF DESIGN
          </h1>
          <p className="text-xs sm:text-sm font-semibold text-amber-100/90 max-w-lg mx-auto leading-relaxed drop-shadow bg-black/50 px-4 py-2 rounded-lg border border-amber-900/50">
            Aventure-se com o Herói do Design, empunhando o Cajado de Régua e o Escudo Cromático para restaurar a harmonia visual em masmorras repletas de quebra-cabeças!
          </p>
        </div>

        {/* Action Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={handleStart}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-pixel font-bold text-xs uppercase tracking-wider rounded-xl transition-all duration-200 transform hover:scale-105 active:scale-95 shadow-2xl shadow-orange-500/40 border-2 border-amber-300 flex items-center justify-center gap-3 cursor-pointer"
          >
            <Play size={16} className="fill-slate-950" />
            <span>Pressione Start / Iniciar Jogo</span>
          </button>
        </div>

        {/* Secondary Buttons */}
        <div className="flex justify-center gap-3 pt-1">
          <button
            onClick={() => {
              soundEngine.playInteract();
              setShowHelp(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-amber-200 hover:text-white bg-slate-950/80 hover:bg-slate-900 border border-amber-800/60 rounded-lg transition-colors shadow"
          >
            <HelpCircle size={14} />
            <span>Controles & Dicas</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playInteract();
              setShowPhilosophy(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-amber-200 hover:text-white bg-slate-950/80 hover:bg-slate-900 border border-amber-800/60 rounded-lg transition-colors shadow"
          >
            <BookOpen size={14} />
            <span>Princípios de Design</span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 flex items-center justify-between max-w-5xl w-full mx-auto text-[11px] text-amber-200/60 font-mono-code pt-3 border-t border-amber-950/80 bg-black/40 px-4 py-2 rounded-lg">
        <div>Controles: Teclado [WASD + Espaço + E] / Touch Gamepad</div>
        <div>Dungeon of Design © 2026</div>
      </footer>

      {/* Help Modal */}
      {showHelp && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#120D15] border-2 border-amber-600/70 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-sm font-pixel font-bold text-amber-300 flex items-center gap-2">
              <HelpCircle size={16} className="text-amber-400" />
              <span>Controles do Herói</span>
            </h3>
            <div className="space-y-2 text-xs text-slate-300 font-sans">
              <div className="flex justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
                <span className="font-bold text-white">Movimentação Isométrica:</span>
                <span className="font-mono-code text-cyan-400">WASD ou Setas</span>
              </div>
              <div className="flex justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
                <span className="font-bold text-white">Dash Rápido do Herói:</span>
                <span className="font-mono-code text-cyan-400">Espaço (Spacebar)</span>
              </div>
              <div className="flex justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
                <span className="font-bold text-white">Interagir & Entrar em Portais:</span>
                <span className="font-mono-code text-cyan-400">Tecla E ou Enter</span>
              </div>
              <div className="flex justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
                <span className="font-bold text-white">Inventário de Peças:</span>
                <span className="font-mono-code text-cyan-400">Tecla I</span>
              </div>
              <div className="flex justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
                <span className="font-bold text-white">Codex de Princípios:</span>
                <span className="font-mono-code text-cyan-400">Tecla C</span>
              </div>
            </div>
            <button
              onClick={() => setShowHelp(false)}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider"
            >
              Fechar Manual
            </button>
          </div>
        </div>
      )}

      {/* Philosophy Modal */}
      {showPhilosophy && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#120D15] border-2 border-amber-600/70 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-sm font-pixel font-bold text-amber-300 flex items-center gap-2">
              <BookOpen size={16} className="text-amber-400" />
              <span>A Lenda de Dungeon of Design</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              No coração de Vectoria, as antigas catacumbas do bom gosto guardam os segredos de Kerning, Teoria das Cores, Gestalt e Sistemas de Grid.
            </p>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Armado com o <strong>Cajado Mágico de Régua e Lápis</strong> e o <strong>Escudo do Espectro Cromático</strong>, seu papel é explorar as masmorras, solucionar quebra-cabeças e banir as aberrações visuais.
            </p>
            <button
              onClick={() => setShowPhilosophy(false)}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
