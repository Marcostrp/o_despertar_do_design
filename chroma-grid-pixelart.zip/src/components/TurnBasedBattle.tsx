/**
 * Pure 16-Bit Pixel-Art Turn-Based Battle Engine
 * Sprites pixel art com animação por quadros (gerados em código):
 * - Herói: idle, corrida (dash), golpe em 4 quadros, magia em 4 quadros e recuo de dano
 * - Monstro: respiração, agachar/avançar/morder/recuar e quadro de dor
 * - Cenário de masmorra em pixel art com tochas animadas
 * - Full Console RPG Battle Flow with Design Principles Mechanics
 */

import React, { useState, useEffect, useRef } from 'react';
import { Enemy, PlayerStats, SpecialAttack, InventoryItem, CombatLog } from '../types/game';
import { soundEngine } from '../audio/soundEngine';
import confetti from 'canvas-confetti';
import { Sword, Shield, Sparkles, Heart, Zap, Coffee, ChevronRight } from 'lucide-react';
import {
  getHeroFrame, getMonsterFrame, getBattleBackdrop, drawSlashFx, drawTorchFlame, HeroAction, MonsterAction
} from '../utils/pixelCharacters';

interface TurnBasedBattleProps {
  playerStats: PlayerStats;
  enemy: Enemy;
  attacks: SpecialAttack[];
  inventory: InventoryItem[];
  onBattleEnd: (result: 'win' | 'lose', updatedPlayerStats: PlayerStats, rewardItems: InventoryItem[], earnedXp: number) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
}

export const TurnBasedBattle: React.FC<TurnBasedBattleProps> = ({
  playerStats,
  enemy,
  attacks,
  inventory,
  onBattleEnd
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [playerHp, setPlayerHp] = useState<number>(playerStats.hp);
  const [playerInspiration, setPlayerInspiration] = useState<number>(playerStats.inspiration);
  const [enemyHp, setEnemyHp] = useState<number>(enemy.hp);
  const [isPlayerShielded, setIsPlayerShielded] = useState<boolean>(false);

  const [currentTurn, setCurrentTurn] = useState<'player' | 'enemy' | 'animating' | 'ended'>('player');
  const [activeMenu, setActiveMenu] = useState<'root' | 'skills' | 'items'>('root');

  // Combat animation state
  const heroStateRef = useRef<'idle' | 'dash_attack' | 'cast' | 'hurt'>('idle');
  const heroAnimTimerRef = useRef<number>(0);
  const enemyStateRef = useRef<'idle' | 'dash_attack' | 'cast' | 'hurt'>('idle');
  const enemyAnimTimerRef = useRef<number>(0);

  const heroXRef = useRef<number>(180);
  const enemyXRef = useRef<number>(620);
  const particlesRef = useRef<Particle[]>([]);
  const shakeRef = useRef<number>(0);
  const slashArcRef = useRef<{ x: number; y: number; progress: number; color: string } | null>(null);

  const [floatingDamage, setFloatingDamage] = useState<{ text: string; x: number; y: number; type: 'crit' | 'enemy' | 'player' | 'heal' } | null>(null);
  const [combatLogs, setCombatLogs] = useState<CombatLog[]>([
    { id: '1', text: `⚔️ O terrível [${enemy.name}] surge nas masmorras de pedra!`, type: 'system' }
  ]);

  useEffect(() => {
    soundEngine.playMusic('battle');
    return () => {
      soundEngine.playMusic('overworld');
    };
  }, []);

  const addLog = (text: string, type: CombatLog['type']) => {
    setCombatLogs(prev => [{ id: Date.now().toString() + Math.random(), text, type }, ...prev.slice(0, 4)]);
  };

  const spawnParticles = (x: number, y: number, color: string, count = 20, speed = 5) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = Math.random() * speed + 1.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        color,
        size: Math.random() * 4 + 2,
        alpha: 1,
        decay: 0.035 + Math.random() * 0.03
      });
    }
  };

  // --- 60 FPS SPRITE-BASED CANVAS BATTLE LOOP ---
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const render = () => {
      tick++;

      // Canvas auto-size
      if (containerRef.current) {
        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight;
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
          heroXRef.current = Math.round(w * 0.28);
          enemyXRef.current = Math.round(w * 0.72);
        }
      }

      const w = canvas.width;
      const h = canvas.height;
      const groundY = Math.round(h * 0.68);

      ctx.imageSmoothingEnabled = false;

      // Screen Shake
      ctx.save();
      if (shakeRef.current > 0) {
        shakeRef.current -= 0.8;
        const sx = (Math.random() - 0.5) * shakeRef.current * 2;
        const sy = (Math.random() - 0.5) * shakeRef.current * 2;
        ctx.translate(sx, sy);
      }

      // 1. CENÁRIO PIXEL ART DA MASMORRA
      const artScale = Math.max(3, Math.min(5, Math.round(h / 105)));
      ctx.drawImage(getBattleBackdrop(w, h, groundY), 0, 0);

      // Tochas animadas (chama em pixels + luz quente)
      const lwLow = Math.ceil(w / 4);
      [0.2, 0.8].forEach((fx, ti) => {
        const tx = Math.round(lwLow * fx) * 4 + 2;
        const ty = Math.round(Math.ceil(h / 4) * 0.25) * 4;
        const flicker = Math.sin(tick * 0.25 + tx) * 6;
        const torchLight = ctx.createRadialGradient(tx, ty, 5, tx, ty, 150 + flicker);
        torchLight.addColorStop(0, 'rgba(249, 115, 22, 0.38)');
        torchLight.addColorStop(0.5, 'rgba(245, 158, 11, 0.12)');
        torchLight.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = torchLight;
        ctx.fillRect(tx - 160, ty - 160, 320, 320);
        drawTorchFlame(ctx, tx, ty + 2, tick, ti * 3, 4);
      });

      // 2. HERÓI — quadros de animação de verdade (lateral, virado para a direita)
      let heroDrawX = heroXRef.current;
      const feetY = groundY + 8;
      let heroAction: HeroAction = 'idle';
      let heroFrame = Math.floor(tick / 22) % 2;
      let heroFlip = false;
      let heroSlashProgress = 0;

      if (heroStateRef.current === 'dash_attack') {
        heroAnimTimerRef.current++;
        const t = heroAnimTimerRef.current;
        const progress = t / 30;
        if (progress < 0.4) {
          heroAction = 'dash';
          heroFrame = Math.floor(t / 3) % 2;
          heroDrawX += (enemyXRef.current - heroXRef.current - 90) * (progress / 0.4);
        } else if (progress < 0.7) {
          heroAction = 'attack';
          const k = (progress - 0.4) / 0.3;
          heroFrame = Math.min(3, Math.floor(k * 4));
          heroSlashProgress = k * 1.1;
          heroDrawX = enemyXRef.current - 90;
        } else if (progress <= 1.0) {
          heroAction = 'dash';
          heroFlip = true; // volta correndo para a posição inicial
          heroFrame = Math.floor(t / 3) % 2;
          heroDrawX = (enemyXRef.current - 90) + (heroXRef.current - (enemyXRef.current - 90)) * ((progress - 0.7) / 0.3);
        } else {
          heroStateRef.current = 'idle';
          heroAnimTimerRef.current = 0;
        }
      } else if (heroStateRef.current === 'cast') {
        heroAnimTimerRef.current++;
        heroAction = 'cast';
        heroFrame = Math.min(3, Math.floor(heroAnimTimerRef.current / 8));
        if (heroAnimTimerRef.current > 30) {
          heroStateRef.current = 'idle';
          heroAnimTimerRef.current = 0;
        }
      } else if (heroStateRef.current === 'hurt') {
        heroAnimTimerRef.current++;
        heroAction = 'hurt';
        heroFrame = Math.floor(heroAnimTimerRef.current / 4);
        heroDrawX -= Math.sin(heroAnimTimerRef.current * 0.8) * 8;
        if (heroAnimTimerRef.current > 20) {
          heroStateRef.current = 'idle';
          heroAnimTimerRef.current = 0;
        }
      }

      heroDrawX = Math.round(heroDrawX);
      const heroSpr = getHeroFrame({ view: 'side', action: heroAction, frame: heroFrame }, artScale);

      // Sombra do herói
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.beginPath();
      ctx.ellipse(heroDrawX, groundY + 6, 46, 14, 0, 0, Math.PI * 2);
      ctx.fill();

      // Aura de escudo
      if (isPlayerShielded) {
        ctx.save();
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#FBBF24';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(heroDrawX, feetY - 60, 68 + Math.sin(tick * 0.2) * 5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      ctx.save();
      ctx.translate(heroDrawX, feetY);
      if (heroFlip) ctx.scale(-1, 1);
      ctx.drawImage(heroSpr.canvas, -heroSpr.ax, -heroSpr.ay);
      if (heroSlashProgress > 0) {
        drawSlashFx(ctx, 18 * artScale, -heroSpr.ay + 20 * artScale, 1, heroSlashProgress, artScale, 18);
      }
      ctx.restore();

      // Faíscas mágicas saindo do cajado durante a magia
      if (heroAction === 'cast' && heroFrame >= 1 && tick % 2 === 0) {
        const tipWorldX = heroDrawX - heroSpr.ax + heroSpr.tipX;
        const tipWorldY = feetY - heroSpr.ay + heroSpr.tipY;
        spawnParticles(tipWorldX, tipWorldY, tick % 4 === 0 ? '#FFFFFF' : '#67E8F9', 2, 2.5);
      }

      // 3. MONSTRO — idle (respira), ataque (agacha, avança, morde, recua) e dor
      let enemyDrawX = enemyXRef.current;
      let monAction: MonsterAction = 'idle';
      let monFrame = Math.floor(tick / 11) % 4;

      if (enemyStateRef.current === 'dash_attack') {
        enemyAnimTimerRef.current++;
        const t = enemyAnimTimerRef.current;
        const progress = t / 30;
        monAction = 'attack';
        if (progress < 0.4) {
          monFrame = progress < 0.15 ? 0 : 1;
          enemyDrawX -= (enemyXRef.current - heroXRef.current - 90) * (progress / 0.4);
        } else if (progress < 0.7) {
          monFrame = 2;
          enemyDrawX = heroXRef.current + 90;
        } else if (progress <= 1.0) {
          monFrame = 3;
          enemyDrawX = (heroXRef.current + 90) + (enemyXRef.current - (heroXRef.current + 90)) * ((progress - 0.7) / 0.3);
        } else {
          enemyStateRef.current = 'idle';
          enemyAnimTimerRef.current = 0;
        }
      } else if (enemyStateRef.current === 'hurt') {
        enemyAnimTimerRef.current++;
        monAction = 'hurt';
        monFrame = Math.floor(enemyAnimTimerRef.current / 4);
        enemyDrawX += Math.sin(enemyAnimTimerRef.current * 0.8) * 8;
        if (enemyAnimTimerRef.current > 20) {
          enemyStateRef.current = 'idle';
          enemyAnimTimerRef.current = 0;
        }
      }

      enemyDrawX = Math.round(enemyDrawX);
      const monScale = enemy.spriteType === 'logo_boss' ? artScale + 1 : artScale;
      const monSpr = getMonsterFrame(enemy.spriteType, enemy.color, monAction, monFrame, monScale);

      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.beginPath();
      ctx.ellipse(enemyDrawX, groundY + 6, enemy.spriteType === 'logo_boss' ? 70 : 52, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.drawImage(monSpr.canvas, enemyDrawX - monSpr.ax, feetY - monSpr.ay);


      // 4. ANIMATED SLASH ARC / IMPACT VISUALS
      if (slashArcRef.current) {
        const slash = slashArcRef.current;
        slash.progress += 0.08;
        ctx.save();
        ctx.strokeStyle = slash.color;
        ctx.lineWidth = 6;
        ctx.lineCap = 'round';
        ctx.beginPath();
        const radius = 60;
        const startAngle = -Math.PI * 0.6 + slash.progress * Math.PI;
        ctx.arc(slash.x, slash.y, radius, startAngle, startAngle + Math.PI * 0.5);
        ctx.stroke();
        ctx.restore();

        if (slash.progress >= 1) {
          slashArcRef.current = null;
        }
      }

      // 5. COMBAT PARTICLES
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;
        if (p.alpha <= 0) {
          particlesRef.current.splice(i, 1);
          continue;
        }
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
        ctx.restore();
      }

      ctx.restore(); // Restore shake

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [enemy, isPlayerShielded]);

  // Handle Player Basic Attack
  const handlePlayerAttack = () => {
    if (currentTurn !== 'player') return;
    setCurrentTurn('animating');
    setActiveMenu('root');

    soundEngine.playDash();
    heroStateRef.current = 'dash_attack';
    heroAnimTimerRef.current = 0;

    setTimeout(() => {
      soundEngine.playHit();
      shakeRef.current = 10;
      enemyStateRef.current = 'hurt';
      enemyAnimTimerRef.current = 0;

      slashArcRef.current = {
        x: enemyXRef.current,
        y: Math.round(canvasRef.current!.height * 0.68) - 70,
        progress: 0,
        color: '#38BDF8'
      };

      spawnParticles(enemyXRef.current, Math.round(canvasRef.current!.height * 0.68) - 70, '#38BDF8', 24, 6);

      const baseDmg = 18 + Math.floor(Math.random() * 8);
      const isCrit = Math.random() > 0.75;
      const totalDmg = isCrit ? Math.round(baseDmg * 1.6) : baseDmg;

      setEnemyHp(prev => Math.max(0, prev - totalDmg));

      setFloatingDamage({
        text: isCrit ? `CRÍTICO! -${totalDmg}` : `-${totalDmg}`,
        x: enemyXRef.current,
        y: Math.round(canvasRef.current!.height * 0.68) - 120,
        type: isCrit ? 'crit' : 'player'
      });

      addLog(
        isCrit
          ? `💥 CRÍTICO! Golpe com Régua Mágica causou ${totalDmg} de dano!`
          : `⚔️ Golpe básico com Régua Mágica causou ${totalDmg} de dano!`,
        'player'
      );

      if (enemyHp - totalDmg <= 0) {
        handleBattleWin();
        return;
      }

      setTimeout(() => {
        setFloatingDamage(null);
        setCurrentTurn('enemy');
        handleEnemyTurn();
      }, 1000);
    }, 400);
  };

  // Handle Player Special Graphic Design Skill
  const handlePlayerSkill = (skill: SpecialAttack) => {
    if (currentTurn !== 'player') return;
    if (playerInspiration < skill.cost) {
      soundEngine.playHit();
      addLog(`⚠️ Inspiração insuficiente para [${skill.name}]! Requer ${skill.cost} MP.`, 'system');
      return;
    }

    setCurrentTurn('animating');
    setActiveMenu('root');
    setPlayerInspiration(prev => Math.max(0, prev - skill.cost));

    soundEngine.playDesignAttack(skill.animationType);
    heroStateRef.current = 'cast';
    heroAnimTimerRef.current = 0;

    setTimeout(() => {
      soundEngine.playHit();
      shakeRef.current = 14;
      enemyStateRef.current = 'hurt';
      enemyAnimTimerRef.current = 0;

      const effectColor = skill.animationType === 'kerning' ? '#38BDF8' : skill.animationType === 'chromatic' ? '#EC4899' : '#F59E0B';

      slashArcRef.current = {
        x: enemyXRef.current,
        y: Math.round(canvasRef.current!.height * 0.68) - 70,
        progress: 0,
        color: effectColor
      };

      spawnParticles(enemyXRef.current, Math.round(canvasRef.current!.height * 0.68) - 70, effectColor, 35, 8);

      if (skill.effectType === 'shield' || skill.id === 'golden_ratio_shield') {
        setIsPlayerShielded(true);
      }

      const totalDmg = Math.round(playerStats.hierarchy * skill.damageMultiplier) + Math.floor(Math.random() * 10);

      setEnemyHp(prev => Math.max(0, prev - totalDmg));

      setFloatingDamage({
        text: `✨ ${skill.name}! -${totalDmg}`,
        x: enemyXRef.current,
        y: Math.round(canvasRef.current!.height * 0.68) - 130,
        type: 'crit'
      });

      addLog(`✨ [${skill.name}] atingiu com perfeição de design causando ${totalDmg} de dano! (${skill.principle})`, 'player');

      if (enemyHp - totalDmg <= 0) {
        handleBattleWin();
        return;
      }

      setTimeout(() => {
        setFloatingDamage(null);
        setCurrentTurn('enemy');
        handleEnemyTurn();
      }, 1200);
    }, 450);
  };

  // Handle Player Consumable Item
  const handleUseItem = (item: InventoryItem) => {
    if (currentTurn !== 'player') return;
    setCurrentTurn('animating');
    setActiveMenu('root');

    soundEngine.playItemPickup();

    if (item.category === 'consumable' || item.id.includes('potion')) {
      const healAmt = item.statsEffect?.healHp || 35;
      const mpAmt = item.statsEffect?.healInspiration || 25;

      setPlayerHp(prev => Math.min(playerStats.maxHp, prev + healAmt));
      setPlayerInspiration(prev => Math.min(playerStats.maxInspiration, prev + mpAmt));

      spawnParticles(heroXRef.current, Math.round(canvasRef.current!.height * 0.68) - 70, '#10B981', 25, 5);

      setFloatingDamage({
        text: `+${healAmt} HP / +${mpAmt} MP`,
        x: heroXRef.current,
        y: Math.round(canvasRef.current!.height * 0.68) - 120,
        type: 'heal'
      });

      addLog(`🧪 Usou [${item.name}] e recuperou ${healAmt} HP e ${mpAmt} MP!`, 'player');
    }

    setTimeout(() => {
      setFloatingDamage(null);
      setCurrentTurn('enemy');
      handleEnemyTurn();
    }, 900);
  };

  // Handle Enemy Turn AI
  const handleEnemyTurn = () => {
    setTimeout(() => {
      enemyStateRef.current = 'dash_attack';
      enemyAnimTimerRef.current = 0;
      soundEngine.playDash();

      setTimeout(() => {
        soundEngine.playHit();
        shakeRef.current = 12;
        heroStateRef.current = 'hurt';
        heroAnimTimerRef.current = 0;

        spawnParticles(heroXRef.current, Math.round(canvasRef.current!.height * 0.68) - 70, '#EF4444', 22, 5);

        let dmg = enemy.atk + Math.floor(Math.random() * 6);
        if (isPlayerShielded) {
          dmg = Math.round(dmg * 0.4);
          setIsPlayerShielded(false);
          addLog(`🛡️ O Escudo Áureo absorveu a maior parte do impacto!`, 'system');
        }

        setPlayerHp(prev => Math.max(0, prev - dmg));

        setFloatingDamage({
          text: `-${dmg}`,
          x: heroXRef.current,
          y: Math.round(canvasRef.current!.height * 0.68) - 110,
          type: 'enemy'
        });

        const chosenAttack = enemy.attacks[Math.floor(Math.random() * enemy.attacks.length)];
        addLog(`👹 [${enemy.name}] atacou com [${chosenAttack.name}] causando ${dmg} de dano!`, 'enemy');

        if (playerHp - dmg <= 0) {
          setTimeout(() => {
            soundEngine.playHit();
            addLog(`💀 Você sucumbiu ao caos visual...`, 'system');
            setCurrentTurn('ended');
            setTimeout(() => {
              onBattleEnd('lose', { ...playerStats, hp: 0 }, [], 0);
            }, 1800);
          }, 800);
          return;
        }

        setTimeout(() => {
          setFloatingDamage(null);
          setCurrentTurn('player');
          setPlayerInspiration(prev => Math.min(playerStats.maxInspiration, prev + 10));
        }, 900);
      }, 400);
    }, 500);
  };

  // Handle Battle Win
  const handleBattleWin = () => {
    setCurrentTurn('ended');
    soundEngine.playVictory();
    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.6 }
    });

    addLog(`🏆 VITÓRIA! [${enemy.name}] foi derrotado com maestria em design!`, 'system');

    setTimeout(() => {
      onBattleEnd(
        'win',
        {
          ...playerStats,
          hp: playerHp,
          inspiration: playerInspiration,
          xp: playerStats.xp + enemy.rewards.xp
        },
        enemy.rewards.items,
        enemy.rewards.xp
      );
    }, 2400);
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-slate-950 flex flex-col justify-between overflow-hidden font-sans select-none">
      {/* 1. TOP HEADER & HEALTH BARS (Authentic Retro Console HUD) */}
      <div className="absolute top-4 inset-x-4 z-20 flex justify-between items-start pointer-events-none">
        {/* Player Status Card */}
        <div className="bg-slate-900/90 border-2 border-amber-500/80 rounded-xl p-3 shadow-2xl backdrop-blur-md w-72">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-lg border-2 border-cyan-400 overflow-hidden bg-slate-950 flex-shrink-0">
              <img
                src="/src/assets/images/hero_battle_portrait_1790813077853.jpg"
                alt="Herói do Design"
                className="w-full h-full object-cover"
                style={{ imageRendering: 'pixelated' }}
              />
            </div>
            <div>
              <div className="text-amber-400 font-pixel text-xs tracking-wider">HERÓI DO DESIGN</div>
              <div className="text-slate-300 text-xs font-semibold">Nível {playerStats.level} • {playerStats.title}</div>
            </div>
          </div>

          {/* HP Bar */}
          <div className="space-y-1 mb-2">
            <div className="flex justify-between text-[11px] font-pixel text-slate-300">
              <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5 text-rose-500" /> HP</span>
              <span>{playerHp} / {playerStats.maxHp}</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-rose-600 to-rose-400 transition-all duration-300"
                style={{ width: `${Math.max(0, (playerHp / playerStats.maxHp) * 100)}%` }}
              />
            </div>
          </div>

          {/* Inspiration (MP) Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-pixel text-slate-300">
              <span className="flex items-center gap-1"><Zap className="w-3.5 h-3.5 text-cyan-400" /> INSPIRAÇÃO</span>
              <span>{playerInspiration} / {playerStats.maxInspiration}</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 transition-all duration-300"
                style={{ width: `${Math.max(0, (playerInspiration / playerStats.maxInspiration) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Enemy Status Card */}
        <div className="bg-slate-900/90 border-2 border-rose-500/80 rounded-xl p-3 shadow-2xl backdrop-blur-md w-72 text-right">
          <div className="text-rose-400 font-pixel text-xs tracking-wider mb-1">{enemy.name}</div>
          <div className="text-slate-400 text-xs mb-2">Pecado: {enemy.flaw}</div>

          {/* Enemy HP Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-pixel text-slate-300">
              <span>{enemyHp} / {enemy.maxHp}</span>
              <span className="flex items-center gap-1">HP INIMIGO <Heart className="w-3.5 h-3.5 text-rose-500" /></span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-rose-600 to-amber-500 transition-all duration-300 ml-auto"
                style={{ width: `${Math.max(0, (enemyHp / enemy.maxHp) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 2. FLOATING DAMAGE TEXT */}
      {floatingDamage && (
        <div
          className="absolute z-30 font-pixel text-xl font-bold tracking-wider pointer-events-none transform -translate-x-1/2 animate-bounce"
          style={{
            left: floatingDamage.x,
            top: floatingDamage.y,
            color:
              floatingDamage.type === 'crit'
                ? '#FEF08A'
                : floatingDamage.type === 'heal'
                ? '#34D399'
                : floatingDamage.type === 'player'
                ? '#38BDF8'
                : '#F87171',
            textShadow: '0 2px 10px rgba(0,0,0,0.9), 0 0 16px rgba(0,0,0,0.9)'
          }}
        >
          {floatingDamage.text}
        </div>
      )}

      {/* 3. CANVAS ARENA */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full z-10" />

      {/* 4. BOTTOM COMMAND & ACTION CONTROLLER (SNES Console Style) */}
      <div className="relative z-20 mt-auto w-full p-4 bg-slate-950/95 border-t-2 border-amber-500/60 backdrop-blur-lg flex flex-col md:flex-row gap-4">
        {/* Left: Action Buttons Menu */}
        <div className="w-full md:w-1/2 flex flex-col gap-2">
          {activeMenu === 'root' && (
            <div className="grid grid-cols-2 gap-2">
              <button
                disabled={currentTurn !== 'player'}
                onClick={handlePlayerAttack}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-pixel text-xs font-bold shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95 cursor-pointer"
              >
                <Sword className="w-4 h-4" /> GOLPE COM RÉGUA
              </button>
              <button
                disabled={currentTurn !== 'player'}
                onClick={() => setActiveMenu('skills')}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-slate-950 font-pixel text-xs font-bold shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" /> PRINCÍPIOS (MAGIA)
              </button>
              <button
                disabled={currentTurn !== 'player'}
                onClick={() => setActiveMenu('items')}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-pixel text-xs font-bold shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95 cursor-pointer"
              >
                <Coffee className="w-4 h-4" /> ITENS / POÇÕES
              </button>
              <button
                disabled={currentTurn !== 'player'}
                onClick={() => {
                  soundEngine.playDash();
                  addLog('🏃 Você recuou estrategicamente da batalha!', 'system');
                  setTimeout(() => {
                    onBattleEnd('lose', playerStats, [], 0);
                  }, 800);
                }}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-pixel text-xs font-bold border border-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95 cursor-pointer"
              >
                <Shield className="w-4 h-4" /> FUGIR
              </button>
            </div>
          )}

          {activeMenu === 'skills' && (
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center text-xs font-pixel text-amber-400 pb-1 border-b border-slate-800">
                <span>HABILIDADES DE DESIGN</span>
                <button
                  onClick={() => setActiveMenu('root')}
                  className="text-slate-400 hover:text-slate-200 underline text-[10px] cursor-pointer"
                >
                  VOLTAR (ESC)
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                {attacks.map(skill => {
                  const hasMana = playerInspiration >= skill.cost;
                  return (
                    <button
                      key={skill.id}
                      disabled={!hasMana || currentTurn !== 'player'}
                      onClick={() => handlePlayerSkill(skill)}
                      className={`text-left p-2.5 rounded-lg border transition-all cursor-pointer ${
                        hasMana
                          ? 'bg-slate-900 border-cyan-500/50 hover:border-cyan-400 hover:bg-slate-800'
                          : 'bg-slate-950/60 border-slate-800 opacity-40 cursor-not-allowed'
                      }`}
                    >
                      <div className="text-cyan-300 font-pixel text-[11px] flex justify-between">
                        <span>{skill.name}</span>
                        <span className="text-amber-400">{skill.cost} MP</span>
                      </div>
                      <div className="text-slate-400 text-[10px] mt-0.5">{skill.principle}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {activeMenu === 'items' && (
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center text-xs font-pixel text-emerald-400 pb-1 border-b border-slate-800">
                <span>INVENTÁRIO DE BATALHA</span>
                <button
                  onClick={() => setActiveMenu('root')}
                  className="text-slate-400 hover:text-slate-200 underline text-[10px] cursor-pointer"
                >
                  VOLTAR (ESC)
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                {inventory.filter(i => i.category === 'consumable' || i.id.includes('potion')).length === 0 ? (
                  <div className="col-span-2 text-center text-slate-500 text-xs py-4">Nenhum item consumível no inventário.</div>
                ) : (
                  inventory
                    .filter(i => i.category === 'consumable' || i.id.includes('potion'))
                    .map(item => (
                      <button
                        key={item.id}
                        onClick={() => handleUseItem(item)}
                        className="text-left p-2.5 rounded-lg border bg-slate-900 border-emerald-500/50 hover:border-emerald-400 hover:bg-slate-800 transition-all cursor-pointer"
                      >
                        <div className="text-emerald-300 font-pixel text-[11px] flex justify-between">
                          <span>{item.name}</span>
                          <span className="text-slate-400">x{item.quantity}</span>
                        </div>
                        <div className="text-slate-400 text-[10px] mt-0.5 truncate">{item.description}</div>
                      </button>
                    ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right: Real-time Combat Log Window */}
        <div className="w-full md:w-1/2 bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between">
          <div className="text-[10px] font-pixel text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1">
            <ChevronRight className="w-3 h-3 text-amber-500" /> Registro de Combate
          </div>
          <div className="space-y-1 overflow-y-auto max-h-24 pr-1 text-xs">
            {combatLogs.map(log => (
              <div
                key={log.id}
                className={`${
                  log.type === 'player'
                    ? 'text-cyan-300'
                    : log.type === 'enemy'
                    ? 'text-rose-300'
                    : 'text-amber-300/90 font-medium'
                }`}
              >
                {log.text}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
