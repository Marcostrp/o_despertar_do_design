/**
 * Virtual Console Gamepad for on-screen controls
 */

import React from 'react';
import { soundEngine } from '../audio/soundEngine';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Zap, Play, Layers, BookOpen } from 'lucide-react';

interface VirtualGamepadProps {
  onDirectionPress: (dir: 'up' | 'down' | 'left' | 'right') => void;
  onActionA: () => void; // Interact / Confirm
  onActionB: () => void; // Dash / Cancel
  onActionX: () => void; // Inventory
  onActionY: () => void; // Codex
}

export const VirtualGamepad: React.FC<VirtualGamepadProps> = ({
  onDirectionPress,
  onActionA,
  onActionB,
  onActionX,
  onActionY
}) => {
  return (
    <div className="md:hidden fixed bottom-16 left-0 right-0 z-30 px-6 flex justify-between items-end pointer-events-none select-none">
      {/* Retro D-Pad */}
      <div className="pointer-events-auto relative w-32 h-32 bg-slate-900/80 border-2 border-slate-700/80 rounded-full shadow-2xl p-2 backdrop-blur-md">
        {/* UP */}
        <button
          onClick={() => onDirectionPress('up')}
          className="absolute top-1 left-1/2 -translate-x-1/2 w-10 h-10 bg-slate-800 active:bg-cyan-500 active:text-slate-950 text-slate-300 rounded-t flex items-center justify-center border border-slate-600"
        >
          <ChevronUp size={20} />
        </button>
        {/* DOWN */}
        <button
          onClick={() => onDirectionPress('down')}
          className="absolute bottom-1 left-1/2 -translate-x-1/2 w-10 h-10 bg-slate-800 active:bg-cyan-500 active:text-slate-950 text-slate-300 rounded-b flex items-center justify-center border border-slate-600"
        >
          <ChevronDown size={20} />
        </button>
        {/* LEFT */}
        <button
          onClick={() => onDirectionPress('left')}
          className="absolute left-1 top-1/2 -translate-y-1/2 w-10 h-10 bg-slate-800 active:bg-cyan-500 active:text-slate-950 text-slate-300 rounded-l flex items-center justify-center border border-slate-600"
        >
          <ChevronLeft size={20} />
        </button>
        {/* RIGHT */}
        <button
          onClick={() => onDirectionPress('right')}
          className="absolute right-1 top-1/2 -translate-y-1/2 w-10 h-10 bg-slate-800 active:bg-cyan-500 active:text-slate-950 text-slate-300 rounded-r flex items-center justify-center border border-slate-600"
        >
          <ChevronRight size={20} />
        </button>
        {/* Center Pivot */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-slate-950 rounded-full border border-slate-800"></div>
      </div>

      {/* Retro Action Buttons (A, B, X, Y) */}
      <div className="pointer-events-auto relative w-32 h-32">
        {/* Y Button (Codex) */}
        <button
          onClick={() => {
            soundEngine.playInteract();
            onActionY();
          }}
          className="absolute top-0 left-1/2 -translate-x-1/2 w-10 h-10 bg-amber-600/90 active:bg-amber-400 text-white rounded-full flex items-center justify-center shadow-lg font-pixel text-xs font-bold border border-amber-400"
        >
          Y
        </button>

        {/* X Button (Inventory) */}
        <button
          onClick={() => {
            soundEngine.playInteract();
            onActionX();
          }}
          className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-cyan-600/90 active:bg-cyan-400 text-white rounded-full flex items-center justify-center shadow-lg font-pixel text-xs font-bold border border-cyan-400"
        >
          X
        </button>

        {/* B Button (Dash) */}
        <button
          onClick={() => {
            onActionB();
          }}
          className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-rose-600/90 active:bg-rose-400 text-white rounded-full flex items-center justify-center shadow-lg font-pixel text-xs font-bold border border-rose-400"
        >
          B
        </button>

        {/* A Button (Interact) */}
        <button
          onClick={() => {
            soundEngine.playInteract();
            onActionA();
          }}
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-10 h-10 bg-emerald-600/90 active:bg-emerald-400 text-white rounded-full flex items-center justify-center shadow-lg font-pixel text-xs font-bold border border-emerald-400"
        >
          A
        </button>
      </div>
    </div>
  );
};
