/**
 * Game Data & Design Lore for Chroma & Grid: Dungeon of Design
 * Rich lore, tactical attack descriptions with graphic design principles, and organic dungeon map.
 */

import { InventoryItem, SpecialAttack, Enemy, DungeonRoom, Achievement, Quest, NPC, WorldTile } from '../types/game';

export const INITIAL_PLAYER_STATS = {
  level: 1,
  xp: 0,
  nextLevelXp: 100,
  hp: 120,
  maxHp: 120,
  inspiration: 60,
  maxInspiration: 60,
  hierarchy: 20,
  contrast: 18,
  harmony: 15,
  flow: 14,
  title: 'Aprendiz do Cajado',
};

export const INITIAL_SPECIAL_ATTACKS: SpecialAttack[] = [
  {
    id: 'kerning_strike',
    name: 'Golpe de Kerning',
    principle: 'Microtipografia & Espaçamento Óptico',
    description: 'Calcula a distância óptica ideal entre os tipos. O corte milimétrico atinge o ponto fraco de espaçamento do inimigo com 140% de dano e +50% de chance de Acerto Crítico.',
    cost: 15,
    damageMultiplier: 1.4,
    effectType: 'crit_boost',
    animationType: 'kerning',
    unlocked: true,
    levelReq: 1,
  },
  {
    id: 'triadic_blast',
    name: 'Disparo Triádico',
    principle: 'Harmonia Cromática a 120°',
    description: 'Combina 3 frequências equidistantes da roda de cores (Ex: Ciano, Magenta e Amarelo). O feixe de harmonia quebra a defesa inimiga e causa 160% de dano espectral contínuo.',
    cost: 20,
    damageMultiplier: 1.6,
    effectType: 'damage',
    animationType: 'chromatic',
    unlocked: true,
    levelReq: 1,
  },
  {
    id: 'rule_of_thirds',
    name: 'Regra dos Terços',
    principle: 'Composição Visual & Pontos Áureos',
    description: 'Projeta uma grade 3x3 no campo de batalha e desfere 3 ataques consecutivos nos quatro pontos de interseção de maior impacto visual.',
    cost: 25,
    damageMultiplier: 1.9,
    effectType: 'aoe',
    animationType: 'thirds',
    unlocked: false,
    levelReq: 2,
  },
  {
    id: 'golden_barrier',
    name: 'Escudo da Proporção Áurea',
    principle: 'Número de Ouro (Phi = 1.618)',
    description: 'Canaliza a harmonia da espiral de Fibonacci para formar um escudo impenetrável que reduz o dano em 65% e restaura +20 de Inspiração.',
    cost: 20,
    damageMultiplier: 0.5,
    effectType: 'shield',
    animationType: 'golden_ratio',
    unlocked: false,
    levelReq: 3,
  },
  {
    id: 'negative_space_void',
    name: 'Vácuo do Espaço Negativo',
    principle: 'Psicologia de Gestalt (Figura e Fundo)',
    description: 'Inverte a polaridade do palco de batalha, utilizando o espaço em branco para anular as defesas e buffs do oponente, causando 220% de dano conceitual puro.',
    cost: 30,
    damageMultiplier: 2.2,
    effectType: 'purge',
    animationType: 'negative_space',
    unlocked: false,
    levelReq: 4,
  },
  {
    id: 'grid_cleave',
    name: 'Corte do Grid 8pt',
    principle: 'Sistemas Modulares da Escola Suíça',
    description: 'Alinha todas as linhas de base vertical e horizontalmente em múltiplos de 8px, desferindo uma rajada ortogonal devastadora de 250% de dano.',
    cost: 35,
    damageMultiplier: 2.5,
    effectType: 'damage',
    animationType: 'grid_cleave',
    unlocked: false,
    levelReq: 5,
  }
];

export const INITIAL_ITEMS: InventoryItem[] = [
  {
    id: 'item_coffee',
    name: 'Café de Prensa Francesa',
    category: 'consumable',
    description: 'Infusão aromática de café recém-moído. Recupera 60 de Vida (HP) e 30 de Inspiração (MP).',
    principle: 'Combustível Criativo',
    icon: '☕',
    quantity: 3,
    usableInBattle: true,
    rarity: 'common',
    statsEffect: { healHp: 60, healInspiration: 30 },
  },
  {
    id: 'item_pantone_swatch',
    name: 'Amostra Pantone Ciano 100%',
    category: 'color_swatch',
    description: 'Fórmula padronizada de cor pura. Essencial para equilibrar o contraste em quebra-cabeças e potencializar feitiços cromáticos.',
    principle: 'Teoria da Cor & Fidelidade de Impressão',
    icon: '🎨',
    quantity: 2,
    usableInDungeon: true,
    colorValue: '#00F0FF',
    rarity: 'rare',
  },
  {
    id: 'item_kerning_gauge',
    name: 'Calibrador de Kerning',
    category: 'tool',
    description: 'Instrumento óptico para medir o espaçamento entre pares de glifos rebeldes.',
    principle: 'Microtipografia',
    icon: '📏',
    quantity: 1,
    usableInDungeon: true,
    rarity: 'rare',
  },
  {
    id: 'item_vector_anchor',
    name: 'Âncora de Bézier Dourada',
    category: 'glyph',
    description: 'Ponto vetorial de controle infinito. Peça de quebra-cabeça que define curvas perfeitas.',
    principle: 'Vetores Matemáticos',
    icon: '⚓',
    quantity: 1,
    usableInDungeon: true,
    rarity: 'epic',
  }
];

export const DUNGEON_ROOMS: DungeonRoom[] = [
  {
    id: 'room_color',
    dungeonId: 'dungeon_1',
    name: 'Câmara Cromática: Harmonia e Contraste',
    subtitle: 'Santuário do Espectro Visual',
    theme: 'color_theory',
    description: 'O guardião corrompeu o equilíbrio de matiz e saturação. Calibre as cores complementares e alcance uma taxa de contraste WCAG superior a 4.5:1 para purificar a câmara.',
    principleGuide: 'Princípio do Contraste: Cores complementares (opostas na roda de cores) geram energia e legibilidade quando a luminosidade é balanceada.',
    isCompleted: false,
    rewardAttackId: 'triadic_blast',
    rewardItem: {
      id: 'prism_cmyk_reward',
      name: 'Lente de Polarização Cromática',
      category: 'tool',
      description: 'Lente que permite visualizar o espectro puro de qualquer composição.',
      principle: 'Física da Luz & Percepção Humana',
      icon: '🔮',
      quantity: 1,
      rarity: 'epic'
    }
  },
  {
    id: 'room_typography',
    dungeonId: 'dungeon_2',
    name: 'Ateliê dos Tipos: Kerning & Escala Modular',
    subtitle: 'Santuário da Hierarquia Textual',
    theme: 'typography_kerning',
    description: 'Os tipos móveis desta sala perderam o alinhamento óptico e a escala de leitura. Corrija o kerning dos pares críticos e ajuste o peso visual da hierarquia.',
    principleGuide: 'Princípio da Hierarquia & Kerning: O espaçamento proporcional cria ritmo de leitura contínuo sem solavancos visuais.',
    isCompleted: false,
    rewardAttackId: 'rule_of_thirds',
    rewardItem: {
      id: 'type_golden_font',
      name: 'Matriz Tipográfica em Chumbo',
      category: 'glyph',
      description: 'Um tipo clássico esculpido segundo as proporções da Renascença.',
      principle: 'História da Tipografia',
      icon: '🔤',
      quantity: 1,
      rarity: 'epic'
    }
  },
  {
    id: 'room_gestalt',
    dungeonId: 'dungeon_3',
    name: 'Câmara de Gestalt: O Segredo do Espaço Negativo',
    subtitle: 'Santuário da Percepção',
    theme: 'gestalt_negative_space',
    description: 'Fragmentos geométricos flutuam desordenados. Posicione e rotacione as peças para aplicar a Lei do Fechamento (Closure) e revelar a forma oculta no espaço em branco.',
    principleGuide: 'Princípio de Gestalt (Fechamento e Figura/Fundo): O cérebro humano busca completar formas incompletas através do espaço negativo.',
    isCompleted: false,
    rewardAttackId: 'negative_space_void',
    rewardItem: {
      id: 'gestalt_totem',
      name: 'Totem do Olho de Gestalt',
      category: 'puzzle_piece',
      description: 'Permite ao portador enxergar a silhueta oculta em qualquer design caótico.',
      principle: 'Psicologia da Gestalt',
      icon: '👁️',
      quantity: 1,
      rarity: 'legendary'
    }
  },
  {
    id: 'room_grid',
    dungeonId: 'dungeon_4',
    name: 'Cúpula Suíça: O Grid de 8 Pontos',
    subtitle: 'Santuário da Ordem Estrutural',
    theme: 'swiss_grid',
    description: 'O layout do templo desmoronou em desalinhamento. Encaixe os módulos no grid de 12 colunas respeitando margens, gutter e a cadência de 8px.',
    principleGuide: 'Princípio do Grid Suíço: Estruturas modulares conferem ordem, consistência e harmonia matemática à composição gráfica.',
    isCompleted: false,
    rewardAttackId: 'grid_cleave',
    rewardItem: {
      id: 'swiss_ruler',
      name: 'Régua Tipográfica de Picas e Pontos',
      category: 'tool',
      description: 'A régua definitiva dos mestres da Escola de Ulm e Bauhaus.',
      principle: 'Design Internacional / Suíço',
      icon: '📐',
      quantity: 1,
      rarity: 'legendary'
    }
  }
];

export const ENEMIES_DATABASE: Enemy[] = [
  {
    id: 'comic_sans_behemoth',
    name: 'Besta do Comic Sans',
    flaw: 'Tipografia Inadequada & Falta de Seriedade',
    hp: 120,
    maxHp: 120,
    atk: 18,
    def: 8,
    speed: 10,
    spriteType: 'comic_sans',
    color: '#FF6B6B',
    attacks: [
      { name: 'Desalinhamento Irresponsável', damage: 16, desc: 'Ataca sem qualquer respeito pela linha de base do texto.' },
      { name: 'Grito em Negrito Falso', damage: 22, desc: 'Simula negrito distorcendo o contorno original do glifo.' }
    ],
    rewards: {
      xp: 50,
      items: [
        {
          id: 'item_coffee',
          name: 'Café de Prensa Francesa',
          category: 'consumable',
          description: 'Recupera 60 de Vida e 30 de Inspiração.',
          principle: 'Combustível Criativo',
          icon: '☕',
          quantity: 1,
          usableInBattle: true,
          rarity: 'common',
          statsEffect: { healHp: 60, healInspiration: 30 },
        }
      ]
    }
  },
  {
    id: 'null_contrast_wraith',
    name: 'Espectro do Contraste Nulo',
    flaw: 'Texto Cinza Claro em Fundo Branco (WCAG Fail)',
    hp: 100,
    maxHp: 100,
    atk: 22,
    def: 12,
    speed: 15,
    spriteType: 'null_contrast',
    color: '#94A3B8',
    attacks: [
      { name: 'Invisibilidade Inacessível', damage: 20, desc: 'Fica quase invisível e causa fadiga ocular ao herói.' },
      { name: 'Dreno de Legibilidade', damage: 18, desc: 'Reduz a precisão do herói para o próximo turno.' }
    ],
    rewards: {
      xp: 60,
      items: [
        {
          id: 'item_pantone_swatch',
          name: 'Guia de Cores Pantone',
          category: 'color_swatch',
          description: 'Amostra padronizada de cor.',
          principle: 'Teoria da Cor',
          icon: '🎨',
          quantity: 1,
          colorValue: '#10B981',
          rarity: 'rare'
        }
      ]
    }
  },
  {
    id: 'broken_gradient_golem',
    name: 'Golém do Gradiente Quebrado',
    flaw: 'Banding Excessivo & Cores Sujas',
    hp: 150,
    maxHp: 150,
    atk: 24,
    def: 16,
    speed: 8,
    spriteType: 'broken_gradient',
    color: '#A855F7',
    attacks: [
      { name: 'Degradê Tóxico', damage: 25, desc: 'Transição suja de cores primárias sem interpolação cromática.' },
      { name: 'Esmagamento de Banding', damage: 30, desc: 'Golpe pesado que quebra a suavidade visual.' }
    ],
    rewards: {
      xp: 80,
      items: [
        {
          id: 'item_vector_anchor',
          name: 'Âncora de Bézier Dourada',
          category: 'glyph',
          description: 'Ponto vetorial para curvas perfeitas.',
          principle: 'Vetores Matemáticos',
          icon: '⚓',
          quantity: 1,
          rarity: 'epic'
        }
      ]
    }
  },
  {
    id: 'boss_logo_tyrant',
    name: 'Soberano do "Aumenta Minha Logo"',
    flaw: 'Poluição Visual & Obliteração do Respiro',
    hp: 260,
    maxHp: 260,
    atk: 32,
    def: 20,
    speed: 14,
    spriteType: 'logo_boss',
    color: '#F59E0B',
    attacks: [
      { name: 'Logo Gigante com Sombra Projetada', damage: 35, desc: 'Cobre todo o layout e oblitera o espaço em branco.' },
      { name: 'Feedback de Sexta-feira às 18h', damage: 38, desc: 'Solicita 47 alterações conflitantes de uma só vez.' }
    ],
    rewards: {
      xp: 220,
      items: [
        {
          id: 'item_swiss_ruler',
          name: 'Régua Tipográfica de Picas e Pontos',
          category: 'tool',
          description: 'A régua suprema dos deuses do design.',
          principle: 'Bauhaus & Estilo Suíço',
          icon: '📐',
          quantity: 1,
          rarity: 'legendary'
        }
      ]
    }
  }
];

export const NPCS: NPC[] = [
  {
    id: 'npc_jan',
    name: 'Mestre Jan (Tschichold)',
    title: 'Guardião da Nova Tipografia',
    isoX: 7,
    isoY: 6,
    dialogue: [
      'Bem-vindo aos salões ancestrais de Dungeon of Design!',
      'As antigas câmaras de Vectoria guardam os segredos de Kerning, Cores, Gestalt e Grids.',
      'Derrote os monstros nas rotas de pedra e complete as 4 câmaras de desafio para consagrar suas habilidades!',
      'Lembre-se: O espaço em branco é a estrutura invisível que dá respiração a toda grande obra.'
    ],
    avatarColor: '#38BDF8',
    questId: 'quest_main'
  },
  {
    id: 'npc_paula',
    name: 'Sábia Paula (Scher)',
    title: 'Mestra do Espectro Cromático',
    isoX: 18,
    isoY: 7,
    dialogue: [
      'A cor é a emoção visual de um projeto!',
      'Na Câmara Cromática ao norte, você deverá calibrar matiz e saturação com precisão de mestre.',
      'Utilize o Golpe de Kerning e o Disparo Triádico quando enfrentar os espectros de poluição visual!'
    ],
    avatarColor: '#F43F5E'
  },
  {
    id: 'npc_dieter',
    name: 'Guardião Dieter (Rams)',
    title: 'Filósofo da Ordem e Utilidade',
    isoX: 18,
    isoY: 18,
    dialogue: [
      'Bom design é o mínimo de design necessário.',
      'Na Cúpula Suíça, a harmonia matemática do Grid de 8 pontos trará clareza ao caos.',
      'Empunhe seu Cajado de Régua e restaure o equilíbrio!'
    ],
    avatarColor: '#10B981'
  },
  {
    id: 'npc_helvetica',
    name: 'Aprendiz Max (Miedinger)',
    title: 'Artífice das Letras Sem Serifa',
    isoX: 6,
    isoY: 18,
    dialogue: [
      'Cuidado! A Besta do Comic Sans ronda os corredores leste!',
      'Se você vencer monstros na masmorra, acumulará café e ferramentas no seu baú.',
      'Pressione "I" para abrir o baú a qualquer momento!'
    ],
    avatarColor: '#EAB308'
  }
];

export const INITIAL_QUESTS: Quest[] = [
  {
    id: 'quest_main',
    title: 'A Restauração das 4 Câmaras do Design',
    giver: 'Mestre Jan Tschichold',
    description: 'Explore a masmorra de pedra e resolva os desafios nas 4 Câmaras de Design.',
    objective: 'Purifique as 4 câmaras de desafio e aprenda os feitiços ancestrais',
    progress: 0,
    maxProgress: 4,
    completed: false,
    rewardTitle: 'Mestre Arquiteto do Design'
  },
  {
    id: 'quest_comic_sans',
    title: 'A Caçada ao Comic Sans',
    giver: 'Aprendiz Max',
    description: 'Derrote a Besta do Comic Sans que aterroriza a biblioteca de tipografia.',
    objective: 'Derrote a Besta do Comic Sans em combate tático por turnos',
    progress: 0,
    maxProgress: 1,
    completed: false,
    rewardTitle: 'Guardião da Boa Tipografia'
  }
];

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_first_dungeon',
    title: 'Primeiro Alinhamento',
    description: 'Complete sua primeira câmara de desafio na Masmorra do Design.',
    principle: 'Iniciação Metodológica',
    icon: '✨',
    unlocked: false,
  },
  {
    id: 'ach_color_master',
    title: 'Harmonia Espectral',
    description: 'Resolva o desafio de Teoria das Cores com WCAG AA superior a 4.5:1.',
    principle: 'Contraste & Acessibilidade',
    icon: '🌈',
    unlocked: false,
  },
  {
    id: 'ach_kerning_god',
    title: 'Mestre do Kerning Óptico',
    description: 'Ajuste todos os pares de letras sem erros de espaçamento.',
    principle: 'Microtipografia',
    icon: '🔠',
    unlocked: false,
  },
  {
    id: 'ach_gestalt_vision',
    title: 'Olho de Gestalt',
    description: 'Desbloqueie a figura oculta pelo fechamento no espaço negativo.',
    principle: 'Psicologia da Forma',
    icon: '👁️',
    unlocked: false,
  },
  {
    id: 'ach_swiss_grid',
    title: 'Ordem de Ulm e Zurique',
    description: 'Alinhe a estrutura modular no Grid de 8 pontos com perfeição.',
    principle: 'Sistemas de Grid',
    icon: '📐',
    unlocked: false,
  },
  {
    id: 'ach_first_battle',
    title: 'Defensor da Estética',
    description: 'Vença sua primeira batalha por turnos contra um monstro de design.',
    principle: 'Crítica Construtiva',
    icon: '⚔️',
    unlocked: false,
  },
  {
    id: 'ach_boss_defeat',
    title: 'O Fim da Logo Gigante',
    description: 'Derrote o temido Soberano do "Aumenta Minha Logo".',
    principle: 'Respeito ao Espaço em Branco',
    icon: '👑',
    unlocked: false,
  }
];

export const DESIGN_CODEX = [
  {
    title: '1. O Princípio do Contraste & WCAG',
    subtitle: 'Direcionamento de Atenção & Acessibilidade',
    category: 'Fundamentos',
    summary: 'O contraste não é apenas sobre claro e escuro; é a diferença calculada de tamanho, peso e luminosidade entre elementos que cria pontos de foco e garante leitura sem esforço para todos os olhos humanos.',
    ruleOfThumb: 'Para texto comum, exija no mínimo uma taxa de contraste 4.5:1 (WCAG AA). Se dois itens são diferentes, faça-os visivelmente distintos.'
  },
  {
    title: '2. Microtipografia, Kerning & Escala',
    subtitle: 'O Ritmo Óptico da Palavra Impressa e Digital',
    category: 'Tipografia',
    summary: 'O Kerning calibra a distância óptica entre pares de glifos específicos (como A-V, T-o, W-A) para que a densidade do texto flua naturalmente. A escala modular (1.25, 1.618) cria proporções harmônicas entre títulos e parágrafos.',
    ruleOfThumb: 'Espaçamento consistente cria velocidade e conforto de leitura.'
  },
  {
    title: '3. As Leis de Gestalt & Espaço Negativo',
    subtitle: 'A Psicologia da Percepção Visual',
    category: 'Percepção',
    summary: 'Fechamento, Continuidade, Proximidade e Figura/Fundo. O espaço negativo não é ausência de design; é o suporte arquitetônico que permite ao cérebro completar formas e focar no essencial.',
    ruleOfThumb: 'O espaço em branco define a forma tanto quanto a tinta aplicada.'
  },
  {
    title: '4. Sistemas de Grid (8pt Grid Modular)',
    subtitle: 'A Geometria da Escola Suíça de Ulm e Bauhaus',
    category: 'Estrutura',
    summary: 'O alinhamento em grades modulares e múltiplos de 8px traz previsibilidade matemática, ritmo e equilíbrio a qualquer composição gráfica.',
    ruleOfThumb: 'Alinhe cada componente a uma guia mestra. A coerência gera confiança imediata.'
  },
  {
    title: '5. A Roda de Cores & Relações Harmônicas',
    subtitle: 'Cores Complementares, Análogas e Triádicas',
    category: 'Cromática',
    summary: 'Relações triádicas (120°) distribuem peso cromático dinâmico; relações complementares (180°) criam vibração e destaque. A regra 60-30-10 mantém a elegância: 60% neutros, 30% estrutura e 10% cor de ação.',
    ruleOfThumb: 'Use a cor para comunicar intenção, hierarquia e estado, nunca apenas como ornamento aleatório.'
  }
];

// Rich, Organic Dungeon Generator: Diverse rooms, corridors, carpets, easels, bookcases, potion vats, torch radius
export function generateWorldMap(): WorldTile[] {
  const size = 26;
  const tiles: WorldTile[] = [];

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let biome: WorldTile['biome'] = 'typography_plaza';
      let type: WorldTile['type'] = 'marble';
      let height = 0;
      let dungeonId: string | undefined;
      let chestId: string | undefined;

      // Determine Room Regions
      if (x < 13 && y < 13) {
        biome = 'typography_plaza'; // Great Hall of Types
        type = (x === 6 || y === 6) ? 'golden_path' : (x + y) % 3 === 0 ? 'marble' : 'grass';
      } else if (x >= 13 && y < 13) {
        biome = 'chromatic_forest'; // Alchemist's Chromatic Garden
        type = (x * 7 + y * 13) % 4 === 0 ? 'flower' : 'grass';
      } else if (x < 13 && y >= 13) {
        biome = 'golden_vista'; // Gallery of Golden Geometry
        type = (x + y) % 2 === 0 ? 'golden_path' : 'marble';
      } else {
        biome = 'grid_citadel'; // Swiss Grid Vault
        type = (x % 3 === 0 && y % 3 === 0) ? 'grid_neon' : 'marble';
      }

      // Outer Fortress Walls
      if (x === 0 || y === 0 || x === size - 1 || y === size - 1) {
        type = 'stone_wall';
        height = 1;
      }

      // Stone Wall Partitions creating organic corridors and archways
      if ((x === 12 || x === 13) && (y >= 2 && y <= 23) && !(y >= 5 && y <= 8) && !(y >= 17 && y <= 20)) {
        type = 'stone_wall';
        height = 1;
      }
      if ((y === 12 || y === 13) && (x >= 2 && x <= 23) && !(x >= 5 && x <= 8) && !(x >= 17 && x <= 20)) {
        type = 'stone_wall';
        height = 1;
      }

      // Central Ink Fountain
      if ((x === 12 || x === 13) && (y === 12 || y === 13)) {
        type = 'ink_water';
      }

      // Pillars & Statues
      if ((x === 4 && y === 4) || (x === 8 && y === 4) || (x === 4 && y === 8) || (x === 8 && y === 8)) {
        type = 'pillar';
        height = 1;
      }
      if ((x === 17 && y === 4) || (x === 21 && y === 4) || (x === 17 && y === 8) || (x === 21 && y === 8)) {
        type = 'pillar';
        height = 1;
      }

      // Dungeon Portals
      if (x === 6 && y === 2) {
        type = 'dungeon_portal';
        dungeonId = 'dungeon_1'; // Color Sanctum
      } else if (x === 2 && y === 6) {
        type = 'dungeon_portal';
        dungeonId = 'dungeon_2'; // Typography Studio
      } else if (x === 6 && y === 22) {
        type = 'dungeon_portal';
        dungeonId = 'dungeon_3'; // Gestalt Chamber
      } else if (x === 22 && y === 22) {
        type = 'dungeon_portal';
        dungeonId = 'dungeon_4'; // Swiss Grid Vault
      }

      // Treasure Chests
      if (x === 22 && y === 4) {
        type = 'chest';
        chestId = 'chest_cmyk';
      } else if (x === 4 && y === 22) {
        type = 'chest';
        chestId = 'chest_kerning';
      } else if (x === 22 && y === 16) {
        type = 'chest';
        chestId = 'chest_coffee';
      }

      tiles.push({
        x,
        y,
        type,
        biome,
        height,
        dungeonId,
        chestId,
        isOpened: false
      });
    }
  }

  return tiles;
}
