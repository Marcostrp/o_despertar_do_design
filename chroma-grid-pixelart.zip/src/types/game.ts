/**
 * Type definitions for Chroma & Grid: Design Odyssey
 */

export type GameView = 
  | 'TITLE'
  | 'OVERWORLD'
  | 'DUNGEON'
  | 'BATTLE'
  | 'INVENTORY'
  | 'CODEX'
  | 'ACHIEVEMENTS'
  | 'QUEST_LOG'
  | 'GAME_OVER'
  | 'VICTORY';

export type BiomeType = 'typography_plaza' | 'chromatic_forest' | 'grid_citadel' | 'golden_vista';

export interface Position2D {
  x: number;
  y: number;
}

export interface PlayerStats {
  level: number;
  xp: number;
  nextLevelXp: number;
  hp: number;
  maxHp: number;
  inspiration: number; // MP for special design attacks
  maxInspiration: number;
  hierarchy: number; // Base attack/impact
  contrast: number;  // Critical rate & precision
  harmony: number;   // Defense & resistance
  flow: number;      // Speed & evasion
  title: string;
}

export type ItemCategory = 'puzzle_piece' | 'tool' | 'color_swatch' | 'glyph' | 'consumable';

export interface InventoryItem {
  id: string;
  name: string;
  category: ItemCategory;
  description: string;
  principle: string; // The Design Principle it represents
  icon: string;
  quantity: number;
  usableInBattle?: boolean;
  usableInDungeon?: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  statsEffect?: {
    healHp?: number;
    healInspiration?: number;
    boostStat?: 'hierarchy' | 'contrast' | 'harmony' | 'flow';
    boostAmount?: number;
  };
  colorValue?: string; // For swatches
  puzzleId?: string; // Associated puzzle
}

export interface SpecialAttack {
  id: string;
  name: string;
  principle: string; // e.g. "Kerning & Espaçamento", "Harmonia Triádica", "Regra dos Terços"
  description: string;
  cost: number; // Inspiration cost
  damageMultiplier: number;
  effectType: 'damage' | 'aoe' | 'shield' | 'stun' | 'crit_boost' | 'purge';
  animationType: 'kerning' | 'chromatic' | 'golden_ratio' | 'thirds' | 'negative_space' | 'vector_anchor' | 'grid_cleave' | 'contrast_flash';
  unlocked: boolean;
  levelReq: number;
}

export interface Enemy {
  id: string;
  name: string;
  flaw: string; // The graphic design sin (e.g., "Espaçamento Caótico", "Falta de Contraste")
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  speed: number;
  spriteType: 'comic_sans' | 'null_contrast' | 'broken_gradient' | 'stretched_ratio' | 'logo_boss';
  color: string;
  attacks: {
    name: string;
    damage: number;
    desc: string;
    statusEffect?: string;
  }[];
  rewards: {
    xp: number;
    items: InventoryItem[];
  };
}

export interface DungeonRoom {
  id: string;
  dungeonId: string;
  name: string;
  subtitle: string;
  theme: 'color_theory' | 'typography_kerning' | 'gestalt_negative_space' | 'swiss_grid';
  description: string;
  principleGuide: string;
  isCompleted: boolean;
  requiredItem?: string;
  rewardAttackId?: string;
  rewardItem: InventoryItem;
}

export interface ColorPuzzleState {
  targetHue: number;
  targetSat: number;
  targetLight: number;
  currentHue: number;
  currentSat: number;
  currentLight: number;
  contrastRatio: number;
  harmonyMode: 'complementary' | 'triadic' | 'analogous';
  slottedSwatches: (string | null)[];
}

export interface KerningLetterPair {
  id: string;
  charLeft: string;
  charRight: string;
  currentSpacing: number; // -50 to 50
  targetSpacing: number;
  isCalibrated: boolean;
}

export interface TypographyPuzzleState {
  pairs: KerningLetterPair[];
  headingScale: number; // Target 1.618 or 1.25
  targetScale: number;
  subheadingScale: number;
  targetSubScale: number;
  isHierarchyBalanced: boolean;
}

export interface GestaltPiece {
  id: string;
  shape: 'arc' | 'triangle' | 'wedge' | 'spiral_segment' | 'pen_nib' | 'negative_cut';
  x: number;
  y: number;
  rotation: number; // in degrees
  targetX: number;
  targetY: number;
  targetRotation: number;
  isPlaced: boolean;
}

export interface GestaltPuzzleState {
  targetSilhouette: 'golden_spiral' | 'designer_pen' | 'optical_eye';
  pieces: GestaltPiece[];
  closurePercentage: number;
}

export interface GridModule {
  id: string;
  title: string;
  colSpan: number; // 1 to 4
  rowSpan: number; // 1 to 3
  currentCol: number;
  currentRow: number;
  targetCol: number;
  targetRow: number;
  isAligned: boolean;
}

export interface GridPuzzleState {
  modules: GridModule[];
  gridAlignmentScore: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  principle: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface Quest {
  id: string;
  title: string;
  giver: string;
  description: string;
  objective: string;
  progress: number;
  maxProgress: number;
  completed: boolean;
  rewardTitle: string;
}

export interface NPC {
  id: string;
  name: string;
  title: string;
  isoX: number;
  isoY: number;
  dialogue: string[];
  questId?: string;
  avatarColor: string;
}

export interface WorldTile {
  x: number;
  y: number;
  type: 'grass' | 'marble' | 'ink_water' | 'grid_neon' | 'golden_path' | 'stone_wall' | 'flower' | 'pillar' | 'statue' | 'dungeon_portal' | 'chest';
  dungeonId?: string;
  chestId?: string;
  isOpened?: boolean;
  biome: BiomeType;
  height: number;
}

export interface CombatLog {
  id: string;
  text: string;
  type: 'player' | 'enemy' | 'system' | 'crit' | 'heal';
}
