/**
 * Utilitários de Pixel Art
 * Tudo é desenhado em baixa resolução (1 "pixel de arte" = 1 pixel do canvas pequeno)
 * e depois ampliado com vizinho-mais-próximo, para manter o visual 16-bit nítido.
 */

export type Ctx = CanvasRenderingContext2D;

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  return c;
}

export function ctx2d(c: HTMLCanvasElement): Ctx {
  const x = c.getContext('2d', { willReadFrequently: true }) as Ctx;
  x.imageSmoothingEnabled = false;
  return x;
}

/** Ruído determinístico 0..1 a partir de coordenadas inteiras */
export function hash2(x: number, y: number, seed = 0): number {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

export function hexToRgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`;
}

export function mix(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

/** amt > 0 clareia, amt < 0 escurece */
export function shade(hex: string, amt: number): string {
  return amt >= 0 ? mix(hex, '#ffffff', amt) : mix(hex, '#000000', -amt);
}

export function rect(c: Ctx, x: number, y: number, w: number, h: number, color: string) {
  c.fillStyle = color;
  c.fillRect(Math.round(x), Math.round(y), w, h);
}

export function dot(c: Ctx, x: number, y: number, color: string) {
  c.fillStyle = color;
  c.fillRect(Math.round(x), Math.round(y), 1, 1);
}

/** Linha de Bresenham em pixels de arte */
export function line(c: Ctx, x0: number, y0: number, x1: number, y1: number, color: string, thick = 1) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  const dx = Math.abs(x1 - x0);
  const dy = -Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  c.fillStyle = color;
  for (let guard = 0; guard < 400; guard++) {
    c.fillRect(x0, y0, thick, thick);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

/** Contorno de 1px (4 vizinhos) ao redor de tudo que é opaco. Precisa de 1px de borda livre. */
export function addOutline(canvas: HTMLCanvasElement, color: string): HTMLCanvasElement {
  const c = ctx2d(canvas);
  const { width: w, height: h } = canvas;
  const src = c.getImageData(0, 0, w, h);
  const out = c.getImageData(0, 0, w, h);
  const [r, g, b] = hexToRgb(color);
  const a = (x: number, y: number) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : src.data[(y * w + x) * 4 + 3]);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (a(x, y) > 0) continue;
      if (a(x - 1, y) > 0 || a(x + 1, y) > 0 || a(x, y - 1) > 0 || a(x, y + 1) > 0) {
        const i = (y * w + x) * 4;
        out.data[i] = r; out.data[i + 1] = g; out.data[i + 2] = b; out.data[i + 3] = 255;
      }
    }
  }
  c.putImageData(out, 0, 0);
  return canvas;
}

/** Amplia sem suavizar */
export function scaleCanvas(src: HTMLCanvasElement, k: number): HTMLCanvasElement {
  const out = makeCanvas(src.width * k, src.height * k);
  const c = ctx2d(out);
  c.drawImage(src, 0, 0, out.width, out.height);
  return out;
}

/** Cópia com todos os pixels opacos pintados de uma cor (flash de dano) */
export function tintCanvas(src: HTMLCanvasElement, color: string, amount = 1): HTMLCanvasElement {
  const out = makeCanvas(src.width, src.height);
  const c = ctx2d(out);
  c.drawImage(src, 0, 0);
  const img = c.getImageData(0, 0, out.width, out.height);
  const [r, g, b] = hexToRgb(color);
  for (let i = 0; i < img.data.length; i += 4) {
    if (img.data[i + 3] === 0) continue;
    img.data[i] = img.data[i] + (r - img.data[i]) * amount;
    img.data[i + 1] = img.data[i + 1] + (g - img.data[i + 1]) * amount;
    img.data[i + 2] = img.data[i + 2] + (b - img.data[i + 2]) * amount;
  }
  c.putImageData(img, 0, 0);
  return out;
}
