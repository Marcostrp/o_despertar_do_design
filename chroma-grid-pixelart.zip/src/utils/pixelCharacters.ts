/**
 * Personagens em Pixel Art com animação real por quadros.
 * Herói: idle (respirando), walk (4 quadros), dash, attack (4 quadros), cast (4 quadros), hurt.
 * NPCs: idle com respiração e aceno. Monstros: idle, attack, hurt.
 * Cada quadro é desenhado em baixa resolução, recebe contorno e é ampliado sem suavização.
 */

import {
  makeCanvas, ctx2d, hash2, mix, shade, rect, dot, line, addOutline, scaleCanvas, tintCanvas, Ctx
} from './pixelArt';

const OUTLINE = '#17101f';

export interface SpriteFrame {
  canvas: HTMLCanvasElement;
  /** ponto de apoio (pés) em pixels da imagem ampliada */
  ax: number;
  ay: number;
  /** ponta do cajado em pixels da imagem ampliada (relativo ao canto da imagem) */
  tipX: number;
  tipY: number;
}

const frameCache = new Map<string, SpriteFrame>();

/* ====================================================================== */
/*  HERÓI                                                                  */
/* ====================================================================== */

export type HeroView = 'front' | 'back' | 'side';
export type HeroAction = 'idle' | 'walk' | 'dash' | 'attack' | 'cast' | 'hurt';
export interface HeroPose {
  view: HeroView;
  action: HeroAction;
  frame: number;
}

const HW = 44;
const HH = 40;
const OX = 8;
const OY = 5;

const C = {
  skin: '#f2c9a0', skinD: '#d9a577',
  hair: '#b45f1f', hairD: '#8a4413', hairL: '#d8812f',
  tunic: '#3fa24a', tunicD: '#2d7a37', tunicL: '#63c46c',
  belt: '#6b3f1d', buckle: '#f5c542',
  pants: '#5a4a3a', boot: '#2b1d14',
  cape: '#2e5fd0', capeD: '#1e3f96', capeL: '#5a8df5',
  staff: '#a0642c', staffL: '#d08a45',
  eye: '#2b1d14'
};

interface Rig {
  bob: number; lLift: number; rLift: number; lArm: number; rArm: number;
  lean: number; ang: number; flare: number; mouth: 0 | 1 | 2; eyes: 'open' | 'x';
  stride: number; orb: number; armUp: boolean;
}

function rigFor(p: HeroPose): Rig {
  const r: Rig = {
    bob: 0, lLift: 0, rLift: 0, lArm: 0, rArm: 0, lean: 0, ang: -1.45, flare: 0,
    mouth: 0, eyes: 'open', stride: 0, orb: 1, armUp: false
  };
  const f = Math.max(0, Math.floor(p.frame));
  switch (p.action) {
    case 'idle': {
      const k = f % 2;
      r.bob = k ? 1 : 0;
      r.lArm = k ? 1 : 0;
      r.ang = -1.45 + (k ? 0.05 : 0);
      break;
    }
    case 'walk': {
      const k = f % 4;
      r.bob = [0, -1, 0, -1][k];
      r.lLift = [0, 2, 0, 0][k];
      r.rLift = [0, 0, 0, 2][k];
      r.lArm = [0, 1, 0, -1][k];
      r.rArm = -r.lArm;
      r.stride = [0, 2, 0, -2][k];
      r.ang = -1.35 + [0, 0.1, 0, -0.1][k];
      r.flare = 1;
      break;
    }
    case 'dash': {
      const k = f % 2;
      r.bob = -1;
      r.lLift = k ? 3 : 0;
      r.rLift = k ? 0 : 3;
      r.lean = 3;
      r.flare = 4;
      r.stride = k ? 3 : -3;
      r.ang = -0.35;
      r.rArm = -1;
      r.lArm = 1;
      break;
    }
    case 'attack': {
      const k = Math.min(3, f);
      r.ang = [-2.55, -1.05, 0.12, 0.95][k];
      r.lean = [-2, 1, 4, 3][k];
      r.bob = [0, 0, -1, 0][k];
      r.stride = [-1, 1, 3, 2][k];
      r.rArm = [-2, 0, 1, 1][k];
      r.mouth = k >= 1 ? 1 : 0;
      r.flare = k >= 2 ? 3 : 0;
      r.orb = k === 2 ? 2 : 1;
      break;
    }
    case 'cast': {
      const k = Math.min(3, f);
      r.ang = -1.57;
      r.armUp = true;
      r.bob = [0, -1, -1, 0][k];
      r.lean = [0, -1, -1, 1][k];
      r.orb = [1, 2, 3, 2][k];
      r.mouth = k >= 2 ? 1 : 0;
      r.flare = k >= 2 ? 2 : 0;
      r.lArm = -1;
      break;
    }
    case 'hurt': {
      const k = f % 2;
      r.lean = -3 + k;
      r.bob = k ? 0 : -1;
      r.eyes = 'x';
      r.mouth = 2;
      r.ang = -2.3;
      r.lLift = 1;
      r.lArm = -2;
      r.rArm = -2;
      break;
    }
  }
  return r;
}

function drawHeroBase(c: Ctx, view: HeroView, rig: Rig) {
  const R = (x: number, y: number, w: number, h: number, col: string) => rect(c, x + OX, y + OY, w, h, col);
  const L = view === 'side' ? rig.lean : Math.round(rig.lean / 2);
  const bob = rig.bob;
  const U = (x: number, y: number, w: number, h: number, col: string) => R(x + L, y + bob, w, h, col);

  // ---- mão e cajado ----
  const handX = (view === 'side' ? 18 : 20) + L;
  let handY = (view === 'side' ? 20 : 21) + bob + rig.rArm;
  if (rig.armUp) handY = 10 + bob;
  const shoulderY = 16 + bob;

  const drawArm = (x: number, hy: number, sleeve: string, sleeveD: string) => {
    const top = Math.min(shoulderY, hy);
    const bottom = Math.max(shoulderY, hy);
    R(x, top, 2, bottom - top + 1, sleeve);
    R(x + 1, top, 1, bottom - top + 1, sleeveD);
    const handTop = hy <= shoulderY ? hy - 1 : hy;
    R(x, handTop, 2, 2, C.skin);
  };

  const drawStaff = () => {
    const ca = Math.cos(rig.ang);
    const sa = Math.sin(rig.ang);
    const bx = handX - ca * 4;
    const by = handY + 1 - sa * 4;
    const tx = handX + ca * 12;
    const ty = handY + 1 + sa * 12;
    line(c, bx + OX, by + OY, tx + OX, ty + OY, C.staff);
    line(c, bx + OX - 1, by + OY, tx + OX - 1, ty + OY, C.staffL);
    // orbe mágico
    const ox = Math.round(tx + OX);
    const oy = Math.round(ty + OY);
    if (rig.orb >= 3) rect(c, ox - 4, oy - 4, 9, 9, 'rgba(255,255,255,0.28)');
    if (rig.orb >= 2) rect(c, ox - 3, oy - 3, 7, 7, 'rgba(103,232,249,0.4)');
    rect(c, ox - 1, oy - 1, 3, 3, '#22d3ee');
    dot(c, ox, oy, '#ffffff');
    return { x: tx + OX, y: ty + OY };
  };

  const drawLegs = () => {
    if (view === 'side') {
      // perna de trás (mais escura) e da frente
      const back = 11 - rig.stride;
      const front = 14 + rig.stride;
      const bl = 29 - rig.lLift;
      const fl = 29 - rig.rLift;
      R(back, 24, 3, bl - 24 + 1, shade(C.pants, -0.15));
      R(back, bl - 1, 4, 2, shade(C.boot, 0.0));
      R(front, 24, 3, fl - 24 + 1, C.pants);
      R(front, fl - 1, 4, 2, C.boot);
      R(front + 3, fl - 1, 1, 1, '#4a3526');
    } else {
      const lb = 29 - rig.lLift;
      const rb = 29 - rig.rLift;
      R(10, 24, 3, lb - 24 + 1, C.pants);
      R(10, lb - 1, 3, 2, C.boot);
      R(15, 24, 3, rb - 24 + 1, C.pants);
      R(15, rb - 1, 3, 2, C.boot);
    }
  };

  const hairSpikes = (x0: number, x1: number, baseY: number) => {
    const hs = [2, 3, 2, 3, 2, 3, 2];
    let i = 0;
    for (let x = x0; x <= x1; x += 2) {
      const h = hs[i++ % hs.length];
      U(x, baseY - h, 2, h, C.hair);
      U(x, baseY - h, 1, 1, C.hairL);
    }
  };

  const mouthPx = (mx: number, my: number) => {
    if (rig.mouth === 1) { U(mx, my, 2, 1, '#8a2f1d'); }
    if (rig.mouth === 2) { U(mx, my, 2, 2, '#8a2f1d'); }
  };

  const eyePx = (ex: number, ey: number) => {
    if (rig.eyes === 'x') {
      U(ex, ey, 1, 1, C.eye); U(ex + 1, ey + 1, 1, 1, C.eye);
      U(ex + 1, ey, 1, 1, C.eye); U(ex, ey + 1, 1, 1, C.eye);
    } else {
      U(ex, ey, 1, 2, C.eye);
    }
  };

  if (view === 'front') {
    // capa por trás
    const fl = rig.flare;
    U(7 - fl, 15, 14 + fl * 2, 10, C.cape);
    U(7 - fl, 22, 14 + fl * 2, 3, C.capeD);
    U(7 - fl, 15, 2, 9, C.capeL);
    drawLegs();
    // tronco
    U(9, 15, 10, 8, C.tunic);
    U(9, 15, 2, 8, C.tunicL);
    U(17, 15, 2, 8, C.tunicD);
    U(9, 20, 10, 1, C.belt);
    U(13, 20, 2, 1, C.buckle);
    U(9, 22, 10, 1, C.tunicD);
    // cachecol
    U(9, 14, 10, 2, C.cape);
    U(9, 14, 10, 1, C.capeL);
    // braço esquerdo
    const lh = 21 + bob + rig.lArm;
    drawArm(7 + L, lh, C.tunic, C.tunicD);
    // cabeça
    U(9, 4, 10, 10, C.skin);
    U(17, 4, 2, 10, C.skinD);
    U(8, 5, 1, 5, C.hair);
    U(19, 5, 1, 5, C.hairD);
    U(9, 4, 10, 3, C.hair);
    U(9, 7, 2, 1, C.hair);
    U(17, 7, 2, 1, C.hair);
    U(11, 7, 2, 1, C.hairD);
    U(15, 7, 3, 1, C.hairD);
    hairSpikes(8, 18, 4);
    eyePx(11, 9);
    eyePx(16, 9);
    mouthPx(13, 12);
    drawArm(19 + L, handY, C.tunic, C.tunicD);
  } else if (view === 'back') {
    drawLegs();
    const fl = rig.flare;
    U(8 - fl, 14, 12 + fl * 2, 12, C.cape);
    U(8 - fl, 23, 12 + fl * 2, 3, C.capeD);
    U(9 - fl, 14, 2, 11, C.capeL);
    U(13, 15, 1, 10, C.capeD);
    U(17, 15, 1, 10, C.capeD);
    U(11, 14, 6, 1, C.capeL);
    // braços
    drawArm(7 + L, 21 + bob + rig.lArm, C.tunic, C.tunicD);
    drawArm(19 + L, handY, C.tunic, C.tunicD);
    // cabeça (cabelo)
    U(12, 12, 4, 2, C.skin);
    U(8, 4, 12, 9, C.hair);
    U(8, 10, 12, 3, C.hairD);
    U(9, 5, 3, 2, C.hairL);
    hairSpikes(8, 18, 4);
  } else {
    // ---- lateral (virado para a direita) ----
    const fl = rig.flare;
    // capa balançando para trás
    U(5 - fl, 15, 7 + fl, 10, C.cape);
    U(4 - fl, 20, 7 + fl, 5, C.capeD);
    U(5 - fl, 15, 7 + fl, 1, C.capeL);
    drawLegs();
    // tronco
    U(11, 15, 7, 8, C.tunic);
    U(11, 15, 2, 8, C.tunicL);
    U(16, 15, 2, 8, C.tunicD);
    U(11, 20, 7, 1, C.belt);
    U(14, 20, 2, 1, C.buckle);
    U(11, 22, 7, 1, C.tunicD);
    U(10, 14, 8, 2, C.cape);
    U(10, 14, 8, 1, C.capeL);
    // braço de trás (cinza escuro)
    const bh = 20 + bob + rig.lArm;
    R(12 + L - 1, 16 + bob, 2, bh - (16 + bob) + 1, C.tunicD);
    // cabeça
    U(10, 4, 9, 10, C.skin);
    U(18, 10, 2, 2, C.skin); // nariz
    U(10, 4, 9, 3, C.hair);
    U(9, 5, 3, 7, C.hair);
    U(9, 10, 3, 2, C.hairD);
    U(15, 7, 3, 1, C.hairD);
    hairSpikes(9, 17, 4);
    eyePx(16, 9);
    mouthPx(16, 12);
    // braço da frente
    drawArm(14 + L, handY, C.tunic, C.tunicD);
  }

  // cajado sempre por cima do braço
  return drawStaff();
}

export function getHeroFrame(pose: HeroPose, scale = 3): SpriteFrame {
  const key = `hero_${pose.view}_${pose.action}_${Math.floor(pose.frame)}_${scale}`;
  const hit = frameCache.get(key);
  if (hit) return hit;

  const rig = rigFor(pose);
  const cv = makeCanvas(HW, HH);
  const c = ctx2d(cv);
  const tip = drawHeroBase(c, pose.view, rig);
  addOutline(cv, OUTLINE);

  let out = scaleCanvas(cv, scale);
  if (pose.action === 'hurt' && Math.floor(pose.frame) % 2 === 0) {
    out = tintCanvas(out, '#ffffff', 0.6);
  }
  const fr: SpriteFrame = {
    canvas: out,
    ax: (14 + OX) * scale,
    ay: (30 + OY) * scale,
    tipX: tip.x * scale,
    tipY: tip.y * scale
  };
  frameCache.set(key, fr);
  return fr;
}

/** Arco de corte pixelado (efeito do golpe) */
export function drawSlashFx(
  ctx: CanvasRenderingContext2D,
  cx: number, cy: number, dir: 1 | -1, progress: number, px: number, radius = 16
) {
  if (progress <= 0 || progress > 1.2) return;
  const sweep = Math.min(1, progress);
  const a0 = -2.2;
  const a1 = a0 + sweep * 2.9;
  const fade = progress > 1 ? Math.max(0, 1 - (progress - 1) * 5) : 1;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  for (let a = a0; a <= a1; a += 0.07) {
    const t = (a - a0) / (a1 - a0 || 1);
    const thick = Math.max(1, Math.round(1 + t * 3));
    for (let k = 0; k < thick; k++) {
      const rr = radius + k - thick / 2;
      const x = Math.round(Math.cos(a) * rr) * dir;
      const y = Math.round(Math.sin(a) * rr * 0.9);
      ctx.globalAlpha = fade * (0.35 + t * 0.65);
      ctx.fillStyle = k === Math.floor(thick / 2) ? '#ffffff' : k % 2 ? '#67e8f9' : '#22d3ee';
      ctx.fillRect(cx + x * px, cy + y * px, px, px);
    }
  }
  ctx.restore();
}

/* ====================================================================== */
/*  NPCs                                                                   */
/* ====================================================================== */

interface NpcLook {
  robe: string; trim: string; skin: string; hair: string;
  kind: 'elder' | 'long' | 'crew' | 'cap';
}

const NPC_LOOKS: Record<string, NpcLook> = {
  npc_jan: { robe: '#2b7fb8', trim: '#f5c542', skin: '#efc6a0', hair: '#e5e7eb', kind: 'elder' },
  npc_paula: { robe: '#be2a48', trim: '#fde68a', skin: '#e9b48f', hair: '#3b2418', kind: 'long' },
  npc_dieter: { robe: '#1f9d6e', trim: '#e5e7eb', skin: '#efc6a0', hair: '#9ca3af', kind: 'crew' },
  npc_helvetica: { robe: '#c9981a', trim: '#ffffff', skin: '#f2c9a0', hair: '#7c4a1d', kind: 'cap' }
};

export function getNpcFrame(id: string, avatarColor: string, frame: number, scale = 3): SpriteFrame {
  const f = ((Math.floor(frame) % 8) + 8) % 8;
  const key = `npc_${id}_${f}_${scale}`;
  const hit = frameCache.get(key);
  if (hit) return hit;

  const look = NPC_LOOKS[id] ?? { robe: avatarColor, trim: '#f5c542', skin: '#efc6a0', hair: '#4b2e1a', kind: 'crew' as const };
  const cv = makeCanvas(HW, HH);
  const c = ctx2d(cv);
  const R = (x: number, y: number, w: number, h: number, col: string) => rect(c, x + OX, y + OY, w, h, col);
  const bob = [0, 0, -1, -1, 0, 0, -1, -1][f];
  const wave = f >= 4; // aceno na 2ª metade do ciclo
  const robeL = shade(look.robe, 0.2);
  const robeD = shade(look.robe, -0.3);

  // pés
  R(10, 29, 3, 2, C.boot);
  R(15, 29, 3, 2, C.boot);
  // túnica em formato de sino
  for (let y = 15; y <= 29; y++) {
    const hw = 5 + Math.floor((y - 15) / 4);
    const yy = y + (y < 25 ? bob : 0);
    R(14 - hw, yy, hw * 2, 1, look.robe);
    R(14 - hw, yy, 2, 1, robeL);
    R(14 + hw - 2, yy, 2, 1, robeD);
  }
  R(9, 21 + bob, 10, 1, robeD);
  R(13, 21 + bob, 2, 1, look.trim);
  // gola
  R(9, 14 + bob, 10, 2, look.trim);
  // braços
  R(7, 16 + bob, 2, 6, look.robe);
  R(7, 22 + bob, 2, 2, look.skin);
  if (wave) {
    const wx = f % 2 === 0 ? 20 : 21;
    R(19, 13 + bob, 2, 4, look.robe);
    R(wx, 10 + bob, 2, 3, look.skin);
  } else {
    R(19, 16 + bob, 2, 6, look.robe);
    R(19, 22 + bob, 2, 2, look.skin);
  }
  // cabeça
  R(9, 4 + bob, 10, 10, look.skin);
  R(17, 4 + bob, 2, 10, shade(look.skin, -0.12));
  R(11, 9 + bob, 1, 2, C.eye);
  R(16, 9 + bob, 1, 2, C.eye);
  R(13, 12 + bob, 2, 1, '#b4533a');

  switch (look.kind) {
    case 'elder': {
      R(8, 3 + bob, 12, 4, look.hair);
      R(8, 5 + bob, 2, 7, look.hair);
      R(18, 5 + bob, 2, 7, look.hair);
      R(10, 12 + bob, 8, 5, look.hair); // barba
      R(12, 11 + bob, 4, 1, look.hair); // bigode
      R(13, 12 + bob, 2, 1, '#b4533a');
      R(10, 9 + bob, 3, 3, '#9ca3af');  // óculos redondos
      R(15, 9 + bob, 3, 3, '#9ca3af');
      R(11, 10 + bob, 1, 1, '#e0f2fe');
      R(16, 10 + bob, 1, 1, '#e0f2fe');
      break;
    }
    case 'long': {
      R(8, 3 + bob, 12, 5, look.hair);
      R(7, 5 + bob, 3, 14, look.hair);
      R(18, 5 + bob, 3, 14, look.hair);
      R(9, 7 + bob, 3, 1, look.hair);
      R(16, 7 + bob, 3, 1, look.hair);
      R(7, 14 + bob, 2, 1, look.trim); // brincos / fita
      R(19, 14 + bob, 2, 1, look.trim);
      break;
    }
    case 'crew': {
      R(9, 3 + bob, 10, 3, look.hair);
      R(8, 4 + bob, 1, 4, look.hair);
      R(19, 4 + bob, 1, 4, look.hair);
      R(10, 9 + bob, 4, 3, '#1f2937'); // óculos quadrados
      R(15, 9 + bob, 4, 3, '#1f2937');
      R(11, 10 + bob, 2, 1, '#bae6fd');
      R(16, 10 + bob, 2, 1, '#bae6fd');
      R(14, 10 + bob, 1, 1, '#1f2937');
      break;
    }
    case 'cap': {
      R(8, 2 + bob, 12, 4, '#ef4444');
      R(8, 2 + bob, 12, 1, '#fca5a5');
      R(15, 5 + bob, 7, 1, '#b91c1c'); // aba
      R(8, 6 + bob, 2, 4, look.hair);
      R(10, 11 + bob, 1, 1, '#b4533a'); // sardas
      R(17, 11 + bob, 1, 1, '#b4533a');
      break;
    }
  }

  addOutline(cv, OUTLINE);
  const fr: SpriteFrame = {
    canvas: scaleCanvas(cv, scale),
    ax: (14 + OX) * scale,
    ay: (31 + OY) * scale,
    tipX: 0,
    tipY: 0
  };
  frameCache.set(key, fr);
  return fr;
}

/* ====================================================================== */
/*  MONSTROS                                                               */
/* ====================================================================== */

export type MonsterType = 'comic_sans' | 'null_contrast' | 'broken_gradient' | 'stretched_ratio' | 'logo_boss';
export type MonsterAction = 'idle' | 'attack' | 'hurt';

const MW = 52;
const MH = 48;
const MOX = 4;
const MOY = 4;

export function getMonsterFrame(
  type: MonsterType, color: string, action: MonsterAction, frame: number, scale = 4
): SpriteFrame {
  const f = Math.max(0, Math.floor(frame));
  const key = `mon_${type}_${color}_${action}_${action === 'idle' ? f % 4 : Math.min(f, 3)}_${scale}`;
  const hit = frameCache.get(key);
  if (hit) return hit;

  const cv = makeCanvas(MW, MH);
  const c = ctx2d(cv);
  const cx = 22 + MOX;
  const baseY = 38 + MOY;

  let H = type === 'stretched_ratio' ? 32 : type === 'logo_boss' ? 28 : 24;
  let W = type === 'stretched_ratio' ? 20 : type === 'logo_boss' ? 38 : 30;
  let lean = 0;
  let mouth: 0 | 1 | 2 = 0;
  let eyesX = false;

  if (action === 'idle') {
    const k = f % 4;
    H += [0, 1, 2, 1][k];
    W -= [0, 1, 2, 1][k];
  } else if (action === 'attack') {
    const k = Math.min(f, 3);
    H += [-5, 4, 2, -1][k];
    W += [5, -3, -1, 1][k];
    lean = [3, -5, -7, -2][k];
    mouth = k >= 1 ? 2 : 1;
  } else {
    const k = f % 2;
    H += -4;
    W += 5;
    lean = 3 - k * 2;
    mouth = 2;
    eyesX = true;
  }

  const top = baseY - H;
  const mid = baseY - H / 2;
  const hl = { x: cx - W * 0.22, y: top + 6 };

  const bandCols = [color, mix(color, '#ec4899', 0.55), mix(color, '#3b82f6', 0.55), mix(color, '#22d3ee', 0.5)];

  for (let y = top; y <= baseY; y++) {
    const ny = (y + 0.5 - mid) / (H / 2);
    let hw = (W / 2) * Math.sqrt(Math.max(0, 1 - ny * ny));
    if (y >= baseY - 1) hw *= 0.92;
    if (hw < 1) continue;
    let rowShift = lean * ((baseY - y) / H);
    if (type === 'broken_gradient' && hash2(Math.floor(y), 3, 5) > 0.82) rowShift += hash2(Math.floor(y), 4, 5) > 0.5 ? 2 : -2;
    const x0 = Math.round(cx - hw + rowShift);
    const x1 = Math.round(cx + hw + rowShift);
    for (let x = x0; x < x1; x++) {
      let col = color;
      if (type === 'broken_gradient') col = bandCols[Math.min(3, Math.floor(((y - top) / H) * 4))];
      const d = Math.hypot(x - (hl.x + rowShift), y - hl.y);
      if (d < 4.5) col = shade(col, 0.38);
      else if (d < 9) col = shade(col, 0.18);
      if (x >= x1 - 3 || y >= baseY - 2) col = shade(col, -0.26);
      if (type === 'null_contrast') {
        col = mix(col, '#cbd5e1', 0.55);
        if ((x + y) % 2 === 0 && y > mid) col = mix(col, '#e2e8f0', 0.6);
      }
      dot(c, x, y, col);
    }
  }

  // ---- traços de cada tipo ----
  const sx = (x: number) => Math.round(x + lean * 0.7);
  if (type === 'comic_sans') {
    [-8, 0, 8].forEach((dx, i) => {
      const bx = sx(cx + dx);
      const by = Math.round(top) + 1;
      line(c, bx, by, bx + (i === 1 ? 1 : i === 0 ? -1 : 1), by - 4, '#d4a30a');
      rect(c, bx + (i === 1 ? 0 : i === 0 ? -2 : 1), by - 7, 3, 3, '#fde047');
    });
  } else if (type === 'logo_boss') {
    for (let i = 0; i < 5; i++) {
      const bx = sx(cx - 12 + i * 6);
      const h = i % 2 === 0 ? 6 : 4;
      rect(c, bx, Math.round(top) - h + 2, 3, h, '#f5c542');
      rect(c, bx, Math.round(top) - h + 2, 1, h, '#fff3b0');
    }
    rect(c, sx(cx - 12), Math.round(top) + 1, 26, 2, '#b8860b');
    // emblema (estrela) no peito
    const ex = sx(cx + 3);
    const ey = baseY - 9;
    rect(c, ex - 1, ey - 3, 3, 7, '#fde047');
    rect(c, ex - 3, ey - 1, 7, 3, '#fde047');
    rect(c, ex - 1, ey - 1, 3, 3, '#fff7d1');
  } else if (type === 'stretched_ratio') {
    const ay = Math.round(mid);
    line(c, sx(cx - 16), ay, sx(cx - 12), ay, '#fbbf24');
    line(c, sx(cx + 12), ay, sx(cx + 16), ay, '#fbbf24');
    dot(c, sx(cx - 16), ay - 1, '#fbbf24'); dot(c, sx(cx - 16), ay + 1, '#fbbf24');
    dot(c, sx(cx + 16), ay - 1, '#fbbf24'); dot(c, sx(cx + 16), ay + 1, '#fbbf24');
  }

  // ---- rosto (olhando para a esquerda, em direção ao herói) ----
  const eyeY = Math.round(top + H * 0.28);
  const eyeW = type === 'stretched_ratio' ? 4 : 5;
  const ex1 = sx(cx - 11 + (type === 'stretched_ratio' ? 3 : 0));
  const ex2 = sx(cx - 2 + (type === 'stretched_ratio' ? 1 : 0));
  const small = type === 'null_contrast';
  [ex1, ex2].forEach(ex => {
    if (eyesX) {
      line(c, ex, eyeY, ex + 4, eyeY + 4, '#17101f');
      line(c, ex + 4, eyeY, ex, eyeY + 4, '#17101f');
    } else {
      rect(c, ex, eyeY, eyeW, small ? 4 : 6, '#ffffff');
      rect(c, ex, eyeY, eyeW, 1, '#e2e8f0');
      rect(c, ex, eyeY + 1, 2, small ? 2 : 4, '#17101f'); // pupila olhando para a esquerda
      dot(c, ex, eyeY + 1, '#ffffff');
    }
  });
  if (!eyesX) {
    // sobrancelhas bravas
    line(c, ex1 - 1, eyeY - 3, ex1 + eyeW, eyeY - 1, '#17101f', 1);
    line(c, ex2 - 1, eyeY - 1, ex2 + eyeW, eyeY - 3, '#17101f', 1);
  }

  // boca
  const my = Math.round(top + H * 0.62);
  const mx0 = sx(cx - 13);
  if (mouth === 0) {
    for (let i = 0; i < 12; i++) dot(c, mx0 + i, my + (i % 2), '#17101f');
    for (let i = 1; i < 12; i += 3) dot(c, mx0 + i, my + 1, '#ffffff');
  } else if (mouth === 1) {
    rect(c, mx0, my, 12, 3, '#17101f');
    for (let i = 0; i < 12; i += 3) rect(c, mx0 + i, my, 2, 1, '#ffffff');
  } else {
    rect(c, mx0 - 1, my - 1, 14, 6, '#17101f');
    rect(c, mx0 + 2, my + 3, 8, 2, '#ef4444');
    for (let i = 0; i < 14; i += 3) {
      rect(c, mx0 - 1 + i, my - 1, 2, 2, '#ffffff');
      rect(c, mx0 + 1 + i, my + 3, 2, 2, '#ffffff');
    }
  }

  addOutline(cv, OUTLINE);
  let out = scaleCanvas(cv, scale);
  if (action === 'hurt' && f % 2 === 0) out = tintCanvas(out, '#ffffff', 0.6);
  const fr: SpriteFrame = { canvas: out, ax: cx * scale, ay: (baseY + 1) * scale, tipX: 0, tipY: 0 };
  frameCache.set(key, fr);
  return fr;
}

/* ====================================================================== */
/*  CENÁRIO DE BATALHA                                                     */
/* ====================================================================== */

const backdropCache = new Map<string, HTMLCanvasElement>();

export function getBattleBackdrop(w: number, h: number, groundY: number, scale = 4): HTMLCanvasElement {
  const key = `bd_${w}_${h}_${groundY}_${scale}`;
  const hit = backdropCache.get(key);
  if (hit) return hit;
  if (backdropCache.size > 6) backdropCache.clear();

  const lw = Math.ceil(w / scale);
  const lh = Math.ceil(h / scale);
  const g = Math.round(groundY / scale);
  const cv = makeCanvas(lw, lh);
  const c = ctx2d(cv);

  // --- parede de tijolos ---
  const wallPal = ['#2a2236', '#322a40', '#3a3148'];
  for (let y = 0; y < g; y++) {
    for (let x = 0; x < lw; x++) {
      const row = Math.floor(y / 5);
      const off = (row % 2) * 5;
      const col = Math.floor((x + off) / 10);
      let color = wallPal[Math.floor(hash2(col, row, 3) * 3) % 3];
      if (y % 5 === 4 || (x + off) % 10 === 9) color = '#171120';
      else if (y % 5 === 0) color = shade(color, 0.1);
      color = shade(color, -0.42 * Math.pow(1 - y / g, 1.5)); // escurece em direção ao teto
      dot(c, x, y, color);
    }
  }

  // --- colunas laterais ---
  [Math.round(lw * 0.06), Math.round(lw * 0.94) - 8].forEach(px => {
    const cols = ['#a79db8', '#8f85a2', '#766c88', '#5a5169'];
    for (let i = 0; i < 8; i++) rect(c, px + i, 0, 1, g, shade(cols[Math.min(3, Math.floor(i / 2))], -0.25));
    rect(c, px - 1, 0, 10, 3, '#4a4258');
    rect(c, px - 1, g - 4, 10, 4, '#4a4258');
    rect(c, px - 1, g - 4, 10, 1, '#8f85a2');
  });

  // --- tapeçaria central ---
  const bx = Math.round(lw / 2) - 9;
  rect(c, bx, 0, 18, 26, '#7c1f2d');
  rect(c, bx, 0, 18, 2, '#e9b93c');
  rect(c, bx + 1, 3, 1, 21, '#e9b93c');
  rect(c, bx + 16, 3, 1, 21, '#e9b93c');
  for (let i = 0; i < 6; i++) rect(c, bx + i * 3, 26 - (i % 2) * 2, 3, 2 + (i % 2) * 2, '#7c1f2d');
  const A = ['0011100', '0100010', '1000001', '1111111', '1000001', '1000001', '1000001'];
  A.forEach((row, y) => [...row].forEach((v, x) => v === '1' && rect(c, bx + 5 + x, 8 + y, 1, 1, '#fde68a')));
  rect(c, bx + 4, 18, 3, 2, '#ef4444');
  rect(c, bx + 8, 18, 3, 2, '#3b82f6');
  rect(c, bx + 12, 18, 3, 2, '#f59e0b');

  // --- suportes das tochas (a chama é animada em tempo real) ---
  [0.2, 0.8].forEach(fx => {
    const tx = Math.round(lw * fx);
    const ty = Math.round(lh * 0.25);
    rect(c, tx - 1, ty, 3, 8, '#5a3416');
    rect(c, tx - 3, ty + 6, 7, 2, '#3a3346');
  });

  // --- chão em perspectiva ---
  const floorPal = ['#3a3146', '#433a50', '#2f2839'];
  const rows: number[] = [];
  for (let i = 0; i < 9; i++) rows.push(g + Math.round(Math.pow(i / 8, 1.7) * (lh - g)));
  for (let y = g; y < lh; y++) {
    let r = 0;
    for (let i = 0; i < rows.length - 1; i++) if (y >= rows[i]) r = i;
    const depth = (y - g) / Math.max(1, lh - g);
    const tileW = 8 + Math.round(depth * 16);
    const off = (r % 2) * (tileW >> 1);
    for (let x = 0; x < lw; x++) {
      const col = Math.floor((x + off) / tileW);
      let color = floorPal[Math.floor(hash2(col, r, 7) * 3) % 3];
      color = shade(color, 0.05 + depth * 0.1);
      if (y === rows[r] || (x + off) % tileW === 0) color = '#171120';
      else if (y === rows[r] + 1) color = shade(color, 0.12);
      if (y < g + 2) color = '#171120';
      dot(c, x, y, color);
    }
  }

  // --- círculo rúnico no chão ---
  const rcx = Math.round(lw / 2);
  const rcy = g + Math.round((lh - g) * 0.5);
  const rrx = Math.round(lw * 0.28);
  const rry = Math.max(3, Math.round(rrx * 0.2));
  for (let a = 0; a < Math.PI * 2; a += 0.025) {
    const x = Math.round(rcx + Math.cos(a) * rrx);
    const y = Math.round(rcy + Math.sin(a) * rry);
    dot(c, x, y, Math.floor(a * 10) % 3 === 0 ? '#22d3ee' : '#0e7490');
  }

  const out = scaleCanvas(cv, scale);
  backdropCache.set(key, out);
  return out;
}

/** Chama de tocha em pixels (animada) */
export function drawTorchFlame(ctx: CanvasRenderingContext2D, x: number, y: number, tick: number, seed: number, px = 4) {
  const fl = Math.sin(tick * 0.28 + seed * 2);
  const fl2 = Math.sin(tick * 0.45 + seed);
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#dc2626';
  ctx.fillRect(x - 2 * px, y - 4 * px, 4 * px, 4 * px);
  ctx.fillStyle = '#f97316';
  ctx.fillRect(x - 2 * px + (fl > 0 ? px : 0), y - Math.round(6 + fl * 1.2) * px, 3 * px, 6 * px);
  ctx.fillStyle = '#fbbf24';
  ctx.fillRect(x - px, y - Math.round(5 + fl2) * px, 2 * px, 4 * px);
  ctx.fillStyle = '#fff7d1';
  ctx.fillRect(x - px / 2 * 0, y - 3 * px, px, 2 * px);
  ctx.restore();
}
