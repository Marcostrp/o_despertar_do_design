/**
 * Cenário Pixel Art do Tabuleiro Isométrico
 * Todos os tiles, paredes, pilares, portais, baús e props são desenhados em código
 * (baixa resolução 30x15 por losango) e ampliados 4x => tile final de 120x60.
 */

import { WorldTile } from '../types/game';
import { makeCanvas, ctx2d, hash2, mix, shade, scaleCanvas, rect, dot, addOutline, Ctx } from './pixelArt';

export const PX = 4;
export const TW = 30; // largura do losango em pixels de arte
export const TH = 15; // altura do losango em pixels de arte
export const WALL_DEPTH = 12; // altura do bloco de parede em pixels de arte (48px na tela)
export const OUTLINE = '#17101f';

const cache = new Map<string, HTMLCanvasElement>();
function memo(key: string, build: () => HTMLCanvasElement): HTMLCanvasElement {
  let v = cache.get(key);
  if (!v) {
    v = build();
    cache.set(key, v);
  }
  return v;
}

/* ---------- geometria do losango ---------- */
function metric(x: number, y: number) {
  const dx = (x + 0.5 - TW / 2) / (TW / 2);
  const dy = (y + 0.5 - TH / 2) / (TH / 2);
  return { dx, dy, m: Math.abs(dx) + Math.abs(dy) };
}
function inDiamond(x: number, y: number) {
  return x >= 0 && y >= 0 && x < TW && y < TH && metric(x, y).m <= 1;
}
function eachDiamondPixel(fn: (x: number, y: number, m: number, dx: number, dy: number) => void) {
  for (let y = 0; y < TH; y++) {
    for (let x = 0; x < TW; x++) {
      const k = metric(x, y);
      if (k.m <= 1) fn(x, y, k.m, k.dx, k.dy);
    }
  }
}
function lastDiamondRow(x: number) {
  let last = 0;
  for (let y = 0; y < TH; y++) if (inDiamond(x, y)) last = y;
  return last;
}

/* ---------- pedra / lajotas ---------- */
interface StoneOpts {
  palette: string[];
  crack: string;
  seed: number;
  rimLight?: string;
  rimDark?: string;
  speckle?: number;
  cells?: number;
}

function paintStone(c: Ctx, o: StoneOpts) {
  const n = o.cells ?? 5;
  const centers: [number, number][] = [];
  for (let k = 0; k < n; k++) centers.push([hash2(k, 11, o.seed) * TW, hash2(k, 23, o.seed) * TH]);

  eachDiamondPixel((x, y, m, _dx, dy) => {
    let d1 = 1e9, d2 = 1e9, id = 0;
    for (let k = 0; k < n; k++) {
      const ddx = x - centers[k][0];
      const ddy = (y - centers[k][1]) * 2;
      const d = Math.sqrt(ddx * ddx + ddy * ddy);
      if (d < d1) { d2 = d1; d1 = d; id = k; } else if (d < d2) d2 = d;
    }
    let col = o.palette[Math.floor(hash2(id, 5, o.seed) * o.palette.length) % o.palette.length];
    const sp = hash2(x, y, o.seed + 9);
    if (sp > 1 - (o.speckle ?? 0.1)) col = shade(col, 0.1);
    else if (sp < (o.speckle ?? 0.1) * 0.8) col = shade(col, -0.1);
    if (d2 - d1 < 1.15) col = o.crack;
    else if (d2 - d1 < 2.0 && hash2(x, y, o.seed + 3) > 0.5) col = shade(col, -0.06);
    if (m > 0.86) col = dy < 0 ? (o.rimLight ?? shade(col, 0.12)) : (o.rimDark ?? o.crack);
    dot(c, x, y, col);
  });
}

function buildFloor(draw: (c: Ctx) => void): HTMLCanvasElement {
  const cv = makeCanvas(TW, TH);
  draw(ctx2d(cv));
  return scaleCanvas(cv, PX);
}

/* ---------- paletas por bioma ---------- */
const STONE: Record<string, { palette: string[]; crack: string; light: string }> = {
  typography_plaza: { palette: ['#3b3445', '#433b4e', '#4b4357'], crack: '#1c1724', light: '#5d5470' },
  chromatic_forest: { palette: ['#3a3a44', '#42424d', '#4a4a56'], crack: '#1a1a22', light: '#5a5a68' },
  grid_citadel: { palette: ['#1c243a', '#232d47', '#2b3655'], crack: '#0a0f1d', light: '#3d4d78' },
  golden_vista: { palette: ['#4a3f3a', '#544843', '#5e514b'], crack: '#201915', light: '#7a6a60' }
};

function stoneTile(biome: string, variant: number, marble: boolean) {
  return memo(`stone_${biome}_${variant}_${marble ? 1 : 0}`, () => {
    const p = STONE[biome] ?? STONE.typography_plaza;
    return buildFloor(c => {
      paintStone(c, {
        palette: marble ? p.palette.map(h => shade(h, 0.16)) : p.palette,
        crack: p.crack,
        seed: variant * 17 + 3,
        rimLight: p.light,
        speckle: marble ? 0.06 : 0.12,
        cells: marble ? 3 : 5
      });
      if (marble) {
        // veios claros do mármore
        eachDiamondPixel((x, y, m) => {
          if (m < 0.8 && ((x * 2 + y * 3 + variant * 5) % 17 === 0)) dot(c, x, y, shade(p.palette[2], 0.32));
        });
      }
    });
  });
}

function mossTile(biome: string, variant: number) {
  return memo(`moss_${biome}_${variant}`, () => {
    const p = STONE[biome] ?? STONE.typography_plaza;
    return buildFloor(c => {
      paintStone(c, { palette: p.palette, crack: p.crack, seed: variant * 29 + 7, rimLight: p.light });
      eachDiamondPixel((x, y, m) => {
        const h = hash2(x, y, variant + 70);
        if (m < 0.9 && h > 0.84) dot(c, x, y, h > 0.93 ? '#4f9a4a' : '#2f6b34');
      });
    });
  });
}

const FLOWER_COLORS = ['#f472b6', '#38bdf8', '#fbbf24', '#fb923c', '#c084fc'];

function grassTile(variant: number, flowerColor?: string) {
  return memo(`grass_${variant}_${flowerColor ?? 'none'}`, () =>
    buildFloor(c => {
      eachDiamondPixel((x, y, m, _dx, dy) => {
        const h = hash2(x, y, variant + 400);
        let col = h < 0.33 ? '#2f6b34' : h < 0.7 ? '#3a7d3c' : '#47914a';
        if (hash2(x >> 1, y, variant + 5) > 0.88) col = '#5aa95a'; // fiapos de grama
        if (hash2(x, y >> 1, variant + 8) < 0.07) col = '#235a2c';
        if (m > 0.88) col = dy < 0 ? '#5aa95a' : '#1f4d27';
        dot(c, x, y, col);
      });
      if (flowerColor) {
        for (let k = 0; k < 3; k++) {
          const fx = 6 + Math.floor(hash2(k, variant, 91) * (TW - 12));
          const fy = 4 + Math.floor(hash2(k, variant, 92) * (TH - 8));
          if (!inDiamond(fx - 1, fy) || !inDiamond(fx + 1, fy) || !inDiamond(fx, fy - 1) || !inDiamond(fx, fy + 1)) continue;
          dot(c, fx, fy - 1, flowerColor);
          dot(c, fx - 1, fy, flowerColor);
          dot(c, fx + 1, fy, flowerColor);
          dot(c, fx, fy + 1, flowerColor);
          dot(c, fx, fy, '#fef08a');
        }
      }
    })
  );
}

function carpetTile(variant: number) {
  return memo(`carpet_${variant}`, () =>
    buildFloor(c => {
      eachDiamondPixel((x, y, m, _dx, dy) => {
        let col = (x + y) % 2 === 0 ? '#7c1f2d' : '#731a29';
        if (hash2(x, y, variant + 600) > 0.93) col = '#8f2a3a';
        if (m > 0.8 && m <= 0.9) col = '#e9b93c'; // friso dourado
        if (m > 0.9) col = dy < 0 ? '#f6d776' : '#4d0f1a';
        if (m > 0.2 && m < 0.34) col = '#e9b93c'; // losango central
        if (m <= 0.12) col = '#f6d776';
        dot(c, x, y, col);
      });
    })
  );
}

function goldTile(variant: number) {
  return memo(`gold_${variant}`, () =>
    buildFloor(c => {
      paintStone(c, {
        palette: ['#9a6b16', '#ab7a22', '#bc8b30'],
        crack: '#5a3b0c',
        seed: variant * 13 + 41,
        rimLight: '#f3d27a',
        rimDark: '#5a3b0c',
        speckle: 0.14,
        cells: 4
      });
      eachDiamondPixel((x, y, m) => {
        if (m < 0.75 && hash2(x, y, variant + 77) > 0.96) dot(c, x, y, '#fff3b0');
      });
    })
  );
}

function waterTile(wx: number, wy: number, frame: number, isWater: (x: number, y: number) => boolean) {
  const key = `water_${wx}_${wy}_${frame}`;
  return memo(key, () =>
    buildFloor(c => {
      eachDiamondPixel((x, y, m, dx, dy) => {
        const gx = (wx - wy) * (TW / 2) + x;
        const gy = (wx + wy) * (TH / 2) + y;
        const ph = (frame * Math.PI) / 2;
        const v = Math.sin(gx * 0.45 + gy * 0.9 + ph) + 0.6 * Math.sin(gx * 0.2 - gy * 0.7 - ph);
        let col = v > 1.2 ? '#7dd3fc' : v > 0.75 ? '#2563eb' : v > -0.2 ? '#122650' : '#0b1733';
        if (m > 0.8) {
          // borda de pedra (apenas onde não há mais água)
          let nx = wx, ny = wy;
          if (dx < 0 && dy < 0) nx = wx - 1;
          else if (dx > 0 && dy < 0) ny = wy - 1;
          else if (dx > 0 && dy > 0) nx = wx + 1;
          else ny = wy + 1;
          if (!isWater(nx, ny)) col = m > 0.92 ? '#1c1724' : dy < 0 ? '#6b6178' : '#4a4258';
        }
        dot(c, x, y, col);
      });
    })
  );
}

function neonTile(glow: boolean) {
  return memo(`neon_${glow ? 1 : 0}`, () => {
    const cv = makeCanvas(TW, TH);
    const c = ctx2d(cv);
    eachDiamondPixel((x, y, m) => {
      const line = m > 0.86 || (m > 0.42 && m < 0.5) || (Math.abs(x - 15) < 1 && Math.abs(y - 7) < 2);
      if (glow) {
        if (line) dot(c, x, y, '#a5f3fc');
      } else {
        const base = hash2(x, y, 33) > 0.9 ? '#0e1630' : '#0a1024';
        dot(c, x, y, line ? '#0e7490' : base);
      }
    });
    return scaleCanvas(cv, PX);
  });
}

function portalFloor(frame: number) {
  return memo(`portalfloor_${frame}`, () =>
    buildFloor(c => {
      paintStone(c, {
        palette: ['#1f3a40', '#254148', '#2b4a52'],
        crack: '#0c1b20',
        seed: 5,
        rimLight: '#3f6b74',
        cells: 4
      });
      eachDiamondPixel((x, y) => {
        const nx = (x + 0.5 - TW / 2) / 9.5;
        const ny = (y + 0.5 - TH / 2) / 4.75;
        const r = Math.sqrt(nx * nx + ny * ny);
        if (r < 0.45) dot(c, x, y, '#0b2a33');
        else if (Math.abs(r - 1) < 0.14) dot(c, x, y, frame % 2 === 0 ? '#22d3ee' : '#67e8f9');
        else if (Math.abs(r - 0.6) < 0.1) dot(c, x, y, '#0e7490');
      });
      for (let k = 0; k < 8; k++) {
        const a = (k * Math.PI) / 4 + (frame * Math.PI) / 16;
        const px = Math.round(TW / 2 + Math.cos(a) * 9.5 * 0.8 - 0.5);
        const py = Math.round(TH / 2 + Math.sin(a) * 4.75 * 0.8 - 0.5);
        dot(c, px, py, '#e0fbff');
      }
    })
  );
}

/* ---------- API de piso ---------- */
export interface FloorContext {
  isWater: (x: number, y: number) => boolean;
}

export function getFloorSprite(tile: WorldTile, tick: number, fc: FloorContext): HTMLCanvasElement {
  const biome = tile.biome;
  const variant = Math.floor(hash2(tile.x, tile.y, 1) * 4);
  switch (tile.type) {
    case 'grass':
      return biome === 'chromatic_forest' ? grassTile(variant) : mossTile(biome, variant);
    case 'flower':
      return grassTile(variant, FLOWER_COLORS[Math.floor(hash2(tile.x, tile.y, 2) * FLOWER_COLORS.length)]);
    case 'golden_path':
      return biome === 'golden_vista' ? goldTile(variant) : carpetTile(variant);
    case 'ink_water':
      return waterTile(tile.x, tile.y, Math.floor(tick / 11) % 4, fc.isWater);
    case 'grid_neon':
      return neonTile(false);
    case 'dungeon_portal':
      return portalFloor(Math.floor(tick / 9) % 4);
    case 'marble':
    case 'chest':
    case 'pillar':
    default:
      return stoneTile(biome, variant, tile.type !== 'chest');
  }
}

export function getNeonGlow() {
  return neonTile(true);
}

/* ---------- bloco de parede ---------- */
export function getWallBlock(tile: WorldTile): HTMLCanvasElement {
  const variant = Math.floor(hash2(tile.x, tile.y, 4) * 3);
  return memo(`wall_${variant}_${tile.biome}`, () => {
    const cv = makeCanvas(TW, TH + WALL_DEPTH);
    const c = ctx2d(cv);

    // topo
    paintStone(c, {
      palette: ['#5b5368', '#645b72', '#6d6479'],
      crack: '#2a2332',
      seed: variant * 7 + 21,
      rimLight: '#8a7fa0',
      rimDark: '#2a2332',
      cells: 3
    });

    const faces: Array<{ from: number; to: number; pal: string[]; mortar: string; mirror: boolean; moss: string }> = [
      { from: 0, to: TW / 2, pal: ['#4b4157', '#53495f', '#5b5167'], mortar: '#17121d', mirror: false, moss: '#3b7a3e' },
      { from: TW / 2, to: TW, pal: ['#2f2839', '#352d40', '#3b3347'], mortar: '#120e17', mirror: true, moss: '#285a2c' }
    ];

    faces.forEach(f => {
      for (let x = f.from; x < f.to; x++) {
        const start = lastDiamondRow(x) + 1;
        for (let k = 0; k < WALL_DEPTH; k++) {
          const y = start + k;
          const u = f.mirror ? TW - 1 - x : x;
          const row = Math.floor(k / 3);
          const off = (row % 2) * 3;
          const col = Math.floor((u + off) / 6);
          let color = f.pal[Math.floor(hash2(col, row, variant + 50 + (f.mirror ? 7 : 0)) * f.pal.length) % f.pal.length];
          if (k % 3 === 2 || (u + off) % 6 === 5) color = f.mortar;
          else if (k === 0) color = shade(color, 0.18);
          if (k >= WALL_DEPTH - 2) color = shade(color, -0.25);
          if (k >= WALL_DEPTH - 4 && hash2(x, k, variant + 80) > 0.82) color = f.moss;
          dot(c, x, y, color);
        }
      }
    });

    // junta vertical entre as duas faces do bloco
    for (let k = 0; k < WALL_DEPTH; k++) dot(c, TW / 2 - 1, TH + k, '#17121d');

    return scaleCanvas(cv, PX);
  });
}

/* ---------- pilar (coluna) ---------- */
export const PILLAR_H = 46;
export const PILLAR_FLOOR_Y = 38; // linha (arte) do centro do piso dentro do sprite

export function getPillar(): HTMLCanvasElement {
  return memo('pillar', () => {
    const cv = makeCanvas(TW, PILLAR_H);
    const c = ctx2d(cv);
    // base
    rect(c, 7, 36, 16, 4, '#6d6479');
    rect(c, 7, 36, 16, 1, '#a79db8');
    rect(c, 7, 39, 16, 1, '#3a3346');
    // fuste
    const shades = ['#c1b7d2', '#a79db8', '#a79db8', '#8f85a2', '#8f85a2', '#8f85a2', '#766c88', '#766c88', '#5a5169', '#5a5169'];
    shades.forEach((col, i) => rect(c, 10 + i, 11, 1, 25, col));
    for (let y = 12; y < 36; y += 4) rect(c, 10, y, 10, 1, 'rgba(40,30,60,0.25)');
    rect(c, 13, 11, 1, 25, '#7d7390');
    rect(c, 16, 11, 1, 25, '#6a607d');
    // gema ciano
    rect(c, 14, 21, 2, 3, '#22d3ee');
    dot(c, 14, 21, '#e0fbff');
    // capitel
    rect(c, 7, 7, 16, 4, '#8f85a2');
    rect(c, 7, 7, 16, 1, '#c1b7d2');
    rect(c, 7, 10, 16, 1, '#4a4258');
    rect(c, 9, 4, 12, 3, '#a79db8');
    rect(c, 9, 4, 12, 1, '#d4cbe3');
    addOutline(cv, OUTLINE);
    return scaleCanvas(cv, PX);
  });
}

/* ---------- arco do portal ---------- */
export const PORTAL_W = 28;
export const PORTAL_H = 38;

export function getPortalArch(frame: number): HTMLCanvasElement {
  return memo(`portal_${frame}`, () => {
    const cv = makeCanvas(PORTAL_W + 2, PORTAL_H + 2);
    const c = ctx2d(cv);
    const cx = PORTAL_W / 2;
    const cy = 18;
    const pal = ['#6d6479', '#5e566b', '#7a7088'];
    for (let y = 0; y < PORTAL_H; y++) {
      for (let x = 0; x < PORTAL_W; x++) {
        const ddx = x + 0.5 - cx;
        const ddy = y + 0.5 - cy;
        const outer = y <= cy ? Math.sqrt(ddx * ddx + ddy * ddy) <= 13.5 : Math.abs(ddx) <= 13.5;
        if (!outer) continue;
        const inner = y <= cy ? Math.sqrt(ddx * ddx + ddy * ddy) <= 8 : Math.abs(ddx) <= 8;
        if (!inner) {
          let col = pal[Math.floor(hash2(x >> 1, y >> 1, 9) * 3) % 3];
          if (ddx < 0) col = shade(col, 0.1);
          if ((x + (y >> 1)) % 5 === 0) col = shade(col, -0.18);
          dot(c, x + 1, y + 1, col);
        } else {
          // portal mágico animado
          const r = Math.sqrt(ddx * ddx + (y - 26) * (y - 26) * 0.6);
          const ang = Math.atan2(y - 26, ddx);
          const v = Math.sin(r * 0.9 - (frame * Math.PI) / 2 + ang * 2);
          let col = v > 0.6 ? '#67e8f9' : v > 0.15 ? '#0e7490' : '#0b1b2e';
          if (y > 31) col = shade(col, -0.2);
          dot(c, x + 1, y + 1, col);
        }
      }
    }
    // pedra-chave dourada
    rect(c, 12, 4, 4, 5, '#f5c542');
    rect(c, 12, 4, 4, 1, '#fff3b0');
    rect(c, 13, 6, 2, 2, '#7c4a03');
    addOutline(cv, OUTLINE);
    return scaleCanvas(cv, PX);
  });
}

/* ---------- baú ---------- */
export const CHEST_W = 18;
export const CHEST_H = 16;

export function getChest(open: boolean): HTMLCanvasElement {
  return memo(`chest_${open ? 1 : 0}`, () => {
    const cv = makeCanvas(CHEST_W, CHEST_H);
    const c = ctx2d(cv);
    // corpo
    rect(c, 2, 8, 14, 7, '#8a4b1a');
    rect(c, 2, 8, 14, 1, '#a35a22');
    for (let y = 10; y < 15; y += 2) rect(c, 2, y, 14, 1, '#6e3a14');
    rect(c, 2, 14, 14, 1, '#4a260c');
    if (!open) {
      // tampa arredondada
      rect(c, 4, 3, 10, 1, '#c47a38');
      rect(c, 3, 4, 12, 1, '#b86a2c');
      rect(c, 2, 5, 14, 3, '#a35a22');
      rect(c, 2, 7, 14, 1, '#7a3f15');
    } else {
      // tampa aberta (atrás) + brilho dourado
      rect(c, 3, 0, 12, 4, '#7a3f15');
      rect(c, 4, 1, 10, 2, '#4a260c');
      rect(c, 3, 4, 12, 4, '#fde68a');
      rect(c, 5, 5, 8, 2, '#fff7d1');
    }
    // ferragens douradas
    [4, 12].forEach(x => {
      rect(c, x, open ? 8 : 4, 2, open ? 7 : 11, '#f5c542');
      rect(c, x, open ? 8 : 4, 1, open ? 7 : 11, '#fff3b0');
    });
    rect(c, 8, 8, 2, 3, '#f5c542');
    rect(c, 9, 9, 1, 1, '#4a260c');
    addOutline(cv, OUTLINE);
    return scaleCanvas(cv, PX);
  });
}

/* ---------- props de cenário ---------- */
export const PROP_CHALK = { w: 24, h: 28 };
export const PROP_TABLE = { w: 28, h: 20 };

export function getChalkboard(): HTMLCanvasElement {
  return memo('prop_chalk', () => {
    const cv = makeCanvas(PROP_CHALK.w, PROP_CHALK.h);
    const c = ctx2d(cv);
    // pernas do cavalete
    rect(c, 5, 17, 2, 10, '#5a3416');
    rect(c, 17, 17, 2, 10, '#5a3416');
    rect(c, 3, 26, 18, 1, '#3a200c');
    // moldura e lousa
    rect(c, 2, 2, 20, 16, '#7a4a20');
    rect(c, 2, 2, 20, 1, '#a0642c');
    rect(c, 4, 4, 16, 12, '#1d2b22');
    rect(c, 4, 4, 16, 1, '#26382d');
    // "Aa" em giz
    const A = ['01110', '10001', '11111', '10001', '10001'];
    A.forEach((row, y) => [...row].forEach((v, x) => v === '1' && dot(c, 6 + x, 6 + y, '#fef9c3')));
    const a = ['111', '101', '111'];
    a.forEach((row, y) => [...row].forEach((v, x) => v === '1' && dot(c, 13 + x, 8 + y, '#fef9c3')));
    // amostras de cor
    rect(c, 6, 13, 3, 2, '#ef4444');
    rect(c, 10, 13, 3, 2, '#3b82f6');
    rect(c, 14, 13, 3, 2, '#f59e0b');
    rect(c, 3, 18, 18, 1, '#a0642c'); // bandeja do giz
    addOutline(cv, OUTLINE);
    return scaleCanvas(cv, PX);
  });
}

export function getDraftingTable(): HTMLCanvasElement {
  return memo('prop_table', () => {
    const cv = makeCanvas(PROP_TABLE.w, PROP_TABLE.h);
    const c = ctx2d(cv);
    rect(c, 3, 13, 2, 6, '#5a3416');
    rect(c, 23, 13, 2, 6, '#5a3416');
    rect(c, 2, 12, 24, 3, '#6e3a14'); // frente
    rect(c, 2, 12, 24, 1, '#a0642c');
    rect(c, 1, 4, 26, 8, '#92400e'); // tampo inclinado
    rect(c, 1, 4, 26, 1, '#c47a38');
    rect(c, 4, 5, 13, 6, '#bae6fd'); // planta
    rect(c, 4, 5, 13, 1, '#e0f2fe');
    for (let x = 6; x < 16; x += 3) rect(c, x, 6, 1, 4, '#38bdf8');
    rect(c, 5, 8, 11, 1, '#0ea5e9');
    rect(c, 20, 6, 5, 2, '#fbbf24'); // lápis
    rect(c, 25, 6, 1, 2, '#f87171');
    rect(c, 19, 6, 1, 2, '#1f2937');
    addOutline(cv, OUTLINE);
    return scaleCanvas(cv, PX);
  });
}
