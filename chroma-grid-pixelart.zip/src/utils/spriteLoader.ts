/**
 * Sprite Loader and Chroma-Key Preprocessor for 16-bit Pixel Art Sprites
 * Converts solid-background pixel art into transparent, pixelated sprite sheets & canvas buffers.
 */

export interface ProcessedSprite {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
}

const spriteCache = new Map<string, HTMLCanvasElement>();

/**
 * Loads an image and converts background (near-black or specified chroma) to alpha transparency.
 * Preserves crisp pixel art rendering.
 */
export function loadTransparentSprite(
  src: string,
  options?: {
    threshold?: number; // Darkness threshold for black background removal (0-255)
    targetKeyColor?: [number, number, number]; // Key color [r, g, b]
  }
): Promise<HTMLCanvasElement> {
  if (spriteCache.has(src)) {
    return Promise.resolve(spriteCache.get(src)!);
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = src;

    img.onload = () => {
      const offscreen = document.createElement('canvas');
      offscreen.width = img.naturalWidth || img.width;
      offscreen.height = img.naturalHeight || img.height;
      const ctx = offscreen.getContext('2d', { willReadFrequently: true });

      if (!ctx) {
        spriteCache.set(src, offscreen);
        resolve(offscreen);
        return;
      }

      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, 0, 0);

      try {
        const imgData = ctx.getImageData(0, 0, offscreen.width, offscreen.height);
        const data = imgData.data;
        const threshold = options?.threshold ?? 28;

        // Sample background from corners if target color not specified
        const cornerR = (data[0] + data[(offscreen.width - 1) * 4]) / 2;
        const cornerG = (data[1] + data[(offscreen.width - 1) * 4 + 1]) / 2;
        const cornerB = (data[2] + data[(offscreen.width - 1) * 4 + 2]) / 2;

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];

          // Check if pixel is dark background or matches corner background
          const distToCorner = Math.sqrt(
            Math.pow(r - cornerR, 2) + Math.pow(g - cornerG, 2) + Math.pow(b - cornerB, 2)
          );

          if ((r <= threshold && g <= threshold && b <= threshold) || distToCorner < threshold) {
            // Soft alpha edge for anti-aliased pixel boundaries
            if (distToCorner < threshold * 0.6 || (r <= threshold * 0.6 && g <= threshold * 0.6 && b <= threshold * 0.6)) {
              data[i + 3] = 0;
            } else {
              const alphaFactor = (distToCorner - threshold * 0.6) / (threshold * 0.4);
              data[i + 3] = Math.min(255, Math.max(0, Math.round(alphaFactor * 255)));
            }
          }
        }

        ctx.putImageData(imgData, 0, 0);
      } catch (e) {
        console.warn('Canvas pixel processing fallback', e);
      }

      spriteCache.set(src, offscreen);
      resolve(offscreen);
    };

    img.onerror = () => {
      console.warn('Failed to load sprite', src);
      const fallback = document.createElement('canvas');
      fallback.width = 64;
      fallback.height = 64;
      resolve(fallback);
    };
  });
}
